#ifdef __cplusplus
extern "C" {
#endif
extern DL_EXPORT(int) spam(void);
extern DL_EXPORT(void) grail(void);
extern DL_EXPORT(char *)tomato(void);
#ifdef __cplusplus
}
#endif

int spam(void) {return 0;}
void grail(void) {return;}
char *tomato(void) {return 0;}
