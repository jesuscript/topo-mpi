"""
Utility scripts for PyTables
============================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivilata@carabos.com
:Created:  2005-12-01
:License:  BSD
:Revision: $Id: __init__.py 1367 2005-12-01 16:12:35Z ivilata $

This package contains some modules which provide a ``main()`` function
(with no arguments), so that they can be used as scripts.
"""
