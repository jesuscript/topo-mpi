"""
Unit tests for special node behaviours
======================================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivilata@carabos.com
:Created:  2007-01-18
:License:  BSD
:Revision: $Id: __init__.py 2426 2007-02-23 12:37:49Z ivilata $
"""
