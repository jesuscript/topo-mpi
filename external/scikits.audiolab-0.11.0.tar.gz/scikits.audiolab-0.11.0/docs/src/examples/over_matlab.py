from audiolab import wavread

data, fs, enc = wavread('test.wav')
