
short_version='0.11.0'
version=short_version
dev=False
if dev:
    version += '.dev'
