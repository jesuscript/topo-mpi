
PKGNAME = "Gnosis_Utils"

# this gets bumped on every release
MAJOR = 1
MINOR = 3
SUBVER = 0
EXTRA = '-alpha-7'

VSTRING = "%d.%d.%d%s" % (MAJOR,MINOR,SUBVER,EXTRA)
