# import * gets you the caching object 'pyconfig'
from pyconfig import *
# want raw module too
import pyconfig as pyconf_mod

from time import time

NR = 200000

# don't use cache
t1 = time()
for i in range(NR):
    pyconf_mod.IsLegal_BaseClass('object')	

print "Non-cached: %.1f loops/sec" % (NR/(time()-t1))

# use cache
t1 = time()
for i in range(NR):
    pyconfig.IsLegal_BaseClass('object')	

print "Cached: %.1f loops/sec" % (NR/(time()-t1))


