"""
xml.pickle API

There are a variety of ways to use xml.pickle. Please have a look
at demo/basic.py first. The following docs are for reference and are 
probably not the easiest way to learn xml.pickle.

    Shorthand used below:
        DUMP_ARGS = (binary=0, allow_replicants=0, allow_rawpickles=0,
                     deepcopy=0, short_ids=1, sorted=0, prefer_cdata=0, 
                     version='1.3', comments=None, extensions=None,
                     break_hidden_refs=0, ext_basictypes=0)

        LOAD_ARGS = (class_search=SEARCH_STORE, allow_replicants=1,
                     allow_rawpickles=0, min_accept='1.3', extensions=None)

        Where:
            allow_rawpickles:
                dump: Allow fallback to cPickle if unpickleable data found.
                load: Allow loading a cPickle data embedded in pickle.
                
            allow_replicants:
                dump: Allow repickling of replicants created by load()
                load: Allow creating replicants if real classes can't be loaded.
                            
            binary: Use gzip to compress pickle.

            break_hidden_refs: **INTERNAL USE ONLY** Leave this set to zero.
            
            class_search: Where unpickler is allowed to load classes from.
                    SEARCH_NONE = Don't load any classes, create replicants.
                    SEARCH_STORE = Load only those classes explicitly registered
                                   with add_class_to_store().
                    SEARCH_NO_IMPORT = As above, plus any classes that are already imported.
                    SEARCH_ALL = As above, plus try importing the module.
                          
            comments: A list of strings to add as a comment. MUST BE XML-SAFE, or an exception
                      will be raised.
            
            deepcopy: Discard references and force copying of all data.
            
            extensions:
                dump: A list of Stackable or Class extensions to run, in addition to
                      any already registered.
                load: A list of LoadOnlyExtensions to run, in addition to any already registered.
            
            ext_basictypes: A flag specifying whether to pass basic types
                (int, float, dict, etc.) to extensions or not. By default it is off
                since this slows pickling down quite a bit and it likely only needed
                for specialized apps.
        
            min_accept: Minimum version of data to accept (
                        (valid choices: 1.1 = xml.pickle <= 1.2.x,  
                                        1.3 = xml.pickle 1.3.x)
            
            prefer_cdata: Tells pickler to use <!CDATA sections to preserve formatting
                          of string data.
                          
            short_ids: Use short 'id=' strings instead of real id() values.
                       Somewhat slower than just using the id() value, so set to zero
                       if that bothers you. short_ids make the pickle smaller.
            
            sorted: Create sorted pickle (names, dict keys, etc.)
            
            version: Version of pickle to create (1.1 = xml.pickle <= 1.2.x; 1.3 = xml.pickle 1.3.x)
            
            
    Dump/Load without statistics:
    -----------------------------
        dump(fileobj, obj, DUMP_ARGS) # pickle to file
        xml = dumps(obj, DUMP_ARGS)   # pickle to string

        obj = load(fileobj, LOAD_ARGS)  # unpickle from file
        obj = loads(xml, LOAD_ARGS)     # unpickle from string

    Dump/Load with statistics:
    --------------------------
        stats = dump_stats(fileobj, obj, DUMP_ARGS)
        xml, stats = dumps_stats(fileobj, obj, DUMP_ARGS)

  	    obj, stats = load_stats(fileobj, LOAD_ARGS)
        obj, stats = loads_stats(xml, LOAD_ARGS)

    The following are also accepted for compatibility:
    --------------------------------------------------
        # reversed args, like pickle API
        dump(obj, fileobj, binary=0)
        xml = dumps(obj, binary=0)

        # 'paranoia' concept from xml.pickle <= 1.2.0
        obj = load(fileobj, paranoia=None)
        obj = loads(xml, paranoia=None)
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import deprecation
# Get a usable StringIO
try: from cStringIO import StringIO
except: from StringIO import StringIO

# Note that 'class_search' and the deprecated 'paranoia' flag occupy the
# same position in load*(). The flags below are defined to not use the values
# -1,0,1 or 2 so it is possible to know what the user intended.

# OR-flags for the class_search parameter when unpickling
FL_DO_IMPORT = 4   # unpickler is allowed to import modules itself
FL_SYSMODULE = 8   # unpickler is allowed to get modules from sys.modules
FL_STACK = 16      # unpickled is allow to look in callers stack for modules
FL_STORE = 32      # unpickler is allowed to get classes from the CLASS_STORE
FL_NONE = 64       # only replicants allowed

# search using all methods (least secure)
SEARCH_ALL = FL_DO_IMPORT|FL_SYSMODULE|FL_STACK|FL_STORE
# only use sys.modules, stack & class store
SEARCH_NO_IMPORT = FL_SYSMODULE|FL_STACK|FL_STORE
# only use class store
SEARCH_STORE = FL_STORE
# search nowhere (use only replicants)
SEARCH_NONE = FL_NONE

# For routines that take (class_search, allow_replicants) args, the
# following are convenient for keyword-args use.
# These are equivalent to the "compound" PARANOIA definitions of
# xml.pickle <= 1.2.0 (Note: PARANOIA_M1 == PARANOIA -1)

PARANOIA_M1 = {'class_search': SEARCH_ALL, 'allow_replicants': 1}
PARANOIA_0 = {'class_search': SEARCH_NO_IMPORT, 'allow_replicants': 1}
PARANOIA_1 = {'class_search': SEARCH_STORE, 'allow_replicants': 1}
PARANOIA_2 = {'class_search': SEARCH_STORE, 'allow_replicants': 0}

class XMLPickleStats:
    "Stats returned to the user about the pickling/unpickling process."
    def __init__(self):
        # The pickle version as a string; "1.1", "1.3", etc.
        # (if "1.1", then no other stats below are valid)
        # When dumping, this will be set the same as the version=
        # argument. When loading, this tells you the pickle version
        # that was detected.
        self.pickle_version = None
        
        # Number of objects loaded/stored
        self.nr_objects = 0
        # Number of replicants loaded/stored
        self.nr_replicants = 0

    def __str__(self):
        s = "XMLPickleStats:\n\txml.pickle protocol: %s\nnr_objects: %d\n\tnr_replicants: %d" % (self.pickle_version,self.nr_objects,self.nr_replicants)
        return s
    
class XMLPickleOptions:
    """
    Internal use only. It will go away later.
    
    This is just for transitional use until DOM is removed and this same
    info can be stored in the SAX instance.
    """
    def __init__(self, class_search, allow_replicants, allow_rawpickles, unpickle_extensions):
        self.class_search = class_search
        self.allow_replicants = allow_replicants
        self.allow_rawpickles = allow_rawpickles
        self.unpickle_extensions = unpickle_extensions

class XMLPickleBaseError(Exception):
    """Baseclass for all xml.pickle errors so you can catch them as
    a group, if desired."""		
    def __init__(self,msg):
        Exception.__init__(self,msg)
        
class XMLPicklingError(XMLPickleBaseError):
    "Raised for errors that occur during pickling."		
    def __init__(self,msg):
        XMLPickleBaseError.__init__(self,msg)

class XMLUnpicklingError(XMLPickleBaseError):
    "Raised for errors that occur during unpickling."
    def __init__(self,msg):
        XMLPickleBaseError.__init__(self,msg)

class XMLPickleOtherError(XMLPickleBaseError):
    """Raised for errors that are not directly related to pickling or
    unpickling (API errors, internal errors, failed sanity checks, etc.). 
    
    May be further subclassed in the future."""
    def __init__(self,msg):
        XMLPickleBaseError.__init__(self,msg)		

#
# Notes about the API:
#
#   The *_stats functions show the true API.
#   The non-stats functions are somewhat oddly defined since they
#   have to maintain backward compatibility.
#
#   

def load_stats(fileobj, class_search=SEARCH_STORE, allow_replicants=1,
               allow_rawpickles=0, min_accept="1.3", extensions=None):

    # don't accept paranoia in place of class_search here, only in load/loads
    if class_search < FL_DO_IMPORT:
        raise XMLUnpicklingError("Bad class_search value (%d) - did you try to pass paranoia?" % class_search)
    
    # determine if it's a gzipped stream
    pos = fileobj.tell()
    magic = fileobj.read(2)
    fileobj.seek(pos)
    if magic == '\037\213':
        import gzip
        fileobj = gzip.GzipFile(None, 'rb', None, fileobj)

    e = ExpatParser()
    m = xmlpickle_meta_parser(class_search, allow_replicants, allow_rawpickles,
                              min_accept, extensions)
    e.setContentHandler(m)
    e.setErrorHandler(m)
    e.setEntityResolver(m)

    e.parse(fileobj)

    return m.get_object(), m.get_stats()

def loads_stats(xml, class_search=SEARCH_STORE, allow_replicants=1,
                allow_rawpickles=0, min_accept="1.3", extensions=None):			 
    sio = StringIO(xml)
    return load_stats(sio, class_search, allow_replicants,
                      allow_rawpickles, min_accept, extensions)

def dumps_stats( obj, binary=0, allow_replicants=0, allow_rawpickles=0,
                 deepcopy=0, short_ids=1, sorted=0, prefer_cdata=0, 
                 version="1.3", comments=None, extensions=None, break_hidden_refs=0,
                 ext_basictypes=0):
    """
    Dump an object to an XML string.
    Returns:
       (xml, stats)

    Where:
       xml = UTF-8 encoded XML string
       stats = XMLPickleStats giving statistics about pickling process.

       (If version == '1.1', stats will not be valid, except for .pickle_version)
    """
    sio = StringIO()
    stats = dump_stats(sio, obj, binary, allow_replicants, allow_rawpickles,
                       deepcopy, short_ids, sorted, prefer_cdata, version, 
                       comments, extensions, break_hidden_refs, ext_basictypes)		
    return (sio.getvalue(), stats)

def dump_stats( fileobj, obj, binary=0, allow_replicants=0, allow_rawpickles=0,
                deepcopy=0, short_ids=1, sorted=0, prefer_cdata=0, 
                version="1.3", comments=None, extensions=None, break_hidden_refs=0,
                ext_basictypes=0):
    """
    Dump object as XML to fileobj.
    Returns stats (XMLPickleStats).
    """
    if binary == 1:
        import gzip
        # using max compression (9) vs 'good-enough' (3) doesn't
        # make much difference in speed. write gets a small boost,
        # but parsing doesn't. so use max compression.
        fileobj = gzip.GzipFile(None, 'wb', 9, fileobj)
        
    if version == '1.3':
        import gnosis.xml.pickle.tagger as tagger
        stats = tagger.pickle_object(fileobj, obj, allow_replicants, allow_rawpickles,
                                     deepcopy, short_ids, sorted, prefer_cdata, 
                                     comments, extensions, break_hidden_refs,
                                     ext_basictypes)		
        stats.pickle_version = "1.3"		
    
    elif version == "1.1":
        import gnosis.xml.pickle.prev.ver_11 as pickle_v11
        pickle_v11.setDeepCopy(deepcopy)
        pickle_v11.dump( obj, fileobj, binary=binary )
        stats = XMLPickleStats()
        stats.pickle_version = "1.1"
        
    else:
        raise XMLPicklingError("Don't know how to make pickle version %s" % version)

    return stats

#-----------------------------------------------------------------------------------
#
# Backward-compatible API with a single 'paranoia' flag
#
#-----------------------------------------------------------------------------------

from gnosis.xml.pickle.flags import getParanoia

def map_paranoia( paranoia ):
    # convert paranoia flag to (class_search,allow_replicants)
    if paranoia is None:
        paranoia = getParanoia()

    if paranoia == -1:
        class_search = SEARCH_ALL
        allow_replicants = 1
    elif paranoia == 0:
        class_search = SEARCH_NO_IMPORT
        allow_replicants = 1			
    elif paranoia == 1:
        class_search = SEARCH_STORE
        allow_replicants = 1			
    elif paranoia == 2:
        class_search = SEARCH_STORE
        allow_replicants = 0

    return class_search, allow_replicants

def grok_load_args(arg1=None, arg2=None, **options):
    opts = options

    # Accept these forms:
    #   load(fileobj)
    #       -> use global paranoia (DEPRECATED)
    #   load(fileobj,[-1,0,1,2])
    #       -> use explicit paranoia, positional arg
    #   load(fileobj,paranoia=[-1,0,1,2])
    #       -> use explicit paranoia, keyword arg	
    #   load(fileobj,SEARCH_..,[0|1])
    #       -> use positional args for class_search & allow_replicants
    #   load(fileobj,class_search=..,allow_replicants=..)
    #       -> use keyword args for class_search & allow_replicants	

    # sanity
    if arg2 is not None and arg1 is None:
        raise XMLUnpicklingError("Bad value for class_search (or paranoia)")
        
    if (arg1,arg2) == (None,None):
        # either NO args were given, or only kwargs were given.

        # sanity
        if (opts.has_key('paranoia') and
            (opts.has_key('class_search') or opts.has_key('allow_replicants'))):
            raise XMLUnpicklingError("Cannot give paranoia AND class_search/allow_replicants")
        
        from gnosis.xml.pickle.flags import HAVE_SET_PARANOIA
        
        if opts.has_key('paranoia'):
            # paranoia given as kwarg
            class_search,allow_replicants = map_paranoia(opts['paranoia'])
            del opts['paranoia'] # for check below
            opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
            
        elif not (opts.has_key('class_search') or opts.has_key('allow_replicants')):
            # neither class_search or allow_replicants given, so assume
            # that 'paranoia' is the missing arg
            
            # if user has setParanoia(), assume they mean paranoia=None,
            # else, use defaults for class_search & allow_replicants
            if HAVE_SET_PARANOIA:
                class_search,allow_replicants = map_paranoia(None)
                deprecation("setParanoia() is going away. Please convert your code to use class_search & allow_replicants.")			
            else:
                class_search,allow_replicants = (SEARCH_STORE,1)

            opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
        
    # arg1 is either 'paranoia' or 'class_search'
    elif arg1 in [-1,0,1,2,None]:
        # arg1 is paranoia
        
        # sanity
        if opts.has_key('class_search') or opts.has_key('allow_replicants') or \
           arg2 != None:
            raise XMLUnpicklingError("Cannot give paranoia AND class_search/allow_replicants")
        # it's paranoia - translate
        class_search,allow_replicants = map_paranoia(arg1)
        opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
        
    else:
        # arg1 is class_search

        # sanity
        if opts.has_key('class_search'):
            raise XMLUnpicklingError("Cannot give class_search as both positional AND keyword arg")
        
        opts.update( {'class_search': arg1} )

        # was allow_replicants given as positional?
        if arg2 != None:
            # sanity
            if opts.has_key('allow_replicants'):
                raise XMLUnpicklingError("Cannot give allow_replicants as both positional AND keyword arg")
            
            opts.update( {'allow_replicants': arg2} )
            
    if opts.has_key('paranoia') and arg1 != None:
        # SOMETHING was passed for 'arg1', but user ALSO gave paranoia=
        raise XMLUnpicklingError("Cannot mix paranoia= with newstyle options in load()")

    return opts

##def grok_load_args(arg1, **options):
##	opts = options

##	# Accept these forms:
##	#   load(fileobj)
##	#       -> use global paranoia (DEPRECATED)
##	#   load(fileobj,[-1,0,1,2])
##	#       -> use explicit paranoia, positional arg
##	#   load(fileobj,paranoia=[-1,0,1,2])
##	#       -> use explicit paranoia, keyword arg	
##	#   load(fileobj,SEARCH_..,[0|1])
##	#       -> use positional args for class_search & allow_replicants
##	#   load(fileobj,class_search=..,allow_replicants=..)
##	#       -> use keyword args for class_search & allow_replicants	

##	if arg1 is None:
##		# it can be None either because NO args were given, or only
##		# kwargs were given.

##		# sanity
##		if (opts.has_key('paranoia') and
##			(opts.has_key('class_search') or opts.has_key('allow_replicants'))):
##			raise XMLUnpicklingError("Cannot give paranoia AND class_search/allow_replicants")
        
##		from gnosis.xml.pickle.flags import HAVE_SET_PARANOIA

##		if opts.has_key('paranoia'):
##			# paranoia given as kwarg
##			class_search,allow_replicants = map_paranoia(opts['paranoia'])
##			del opts['paranoia'] # for check below
##			opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
            
##		elif not (opts.has_key('class_search') or opts.has_key('allow_replicants')):
##			# neither class_search or allow_replicants given, so assume
##			# that 'paranoia' is the missing arg
            
##			# if user has setParanoia(), assume they mean paranoia=None,
##			# else, use defaults for class_search & allow_replicants
##			if HAVE_SET_PARANOIA:
##				class_search,allow_replicants = map_paranoia(None)
##				deprecation("setParanoia() is going away. Please convert your code to use class_search & allow_replicants.")			
##			else:
##				class_search,allow_replicants = (SEARCH_STORE,1)

##			opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
        
##	# arg1 is either 'paranoia' or 'class_search'
##	elif arg1 in [-1,0,1,2,None]:
##		# sanity
##		if opts.has_key('class_search') or opts.has_key('allow_replicants'):
##			raise XMLUnpicklingError("Cannot give paranoia AND class_search/allow_replicants")
##		# it's paranoia - translate
##		class_search,allow_replicants = map_paranoia(arg1)
##		opts.update( {'class_search': class_search, 'allow_replicants': allow_replicants} )
        
##	else:
##		# it's class_search
##		opts.update( {'class_search': arg1} )
    
##	if opts.has_key('paranoia'):
##		# SOMETHING was passed for 'arg1', but user ALSO gave paranoia=
##		raise XMLUnpicklingError("Cannot mix paranoia= with newstyle options in load()")

##	return opts

def load(fileobj, arg1=None, arg2=None, **options):
    "Takes same arguments as load_stats. Also accepts 1.2.0 parameters."
    opts = grok_load_args( arg1, arg2, **options )
    return load_stats(fileobj, **opts)[0]

def loads(xml, arg1=None, arg2=None, **options):
    sio = StringIO(xml)
    return load(sio, arg1, arg2, **options)

def is_filelike(obj):
    for attr in ['close','isatty','tell','seek','read','write','truncate']:
        if not hasattr(obj,attr) or not callable(getattr(obj,attr)):
            return 0

    return 1

def dump(arg1, arg2, binary=0, **options):
    "Accepts the same args as dump_stats, plus the binary= flag."

    # figure out which is the fileobj
    if1 = is_filelike(arg1)
    if2 = is_filelike(arg2)

    if not if1 and not if2:
        raise XMLPicklingError("No fileobj passed to dump()")

    if if1 and if2:
        raise XMLPicklingError("Cannot pickle fileobjects.")

    if if1:
        fileobj = arg1
        obj = arg2
    else:
        fileobj = arg2
        obj = arg1
        
    dump_stats(fileobj, obj, **options)

def dumps(obj, binary=0, **options):
    "Accepts the same args as dumps_stats, plus the binary= flag."
    xml,stats = dumps_stats(obj, binary=binary, **options)
    return xml

#
# The dump* API is the recommended way to use xml.pickle now,
# but the XML_Pickler class is still provided for backward compatibility.
#
class XML_Pickler:
    def __init__(self, py_obj=None):
        if py_obj != None:
            self.to_pickle = py_obj

    # retain same function signatures
    def dump(self, iohandle, obj=None, binary=0, deepcopy=0, version="1.3"):
        "Write the XML representation of obj to iohandle."
        # here are our three forms:
        if obj is not None:				# XML_Pickler().dumps(obj)
            return dump(obj, iohandle, binary, deepcopy=deepcopy, version=version)
        elif hasattr(self,'to_pickle'): # XML_Pickler(obj).dumps()
            return dump(self.to_pickle, iohandle, binary, deepcopy=deepcopy, version=version)
        else:							# myXML_Pickler().dumps()
            return dump(self, iohandle, binary, deepcopy=deepcopy, version=version)
    
    def dumps(self, obj=None, binary=0, deepcopy=0, iohandle=None, version="1.3"):
        "Create the XML representation as a string."
        if iohandle is not None:
            raise XMLPicklingError("Sorry, you can't pass iohandle to dumps()")
        
        # here are our three forms:
        if obj is not None:				# XML_Pickler().dumps(obj)
            return dumps(obj, binary, deepcopy=deepcopy, version=version)
        elif hasattr(self,'to_pickle'): # XML_Pickler(obj).dumps()
            return dumps(self.to_pickle, binary, deepcopy=deepcopy, version=version)
        else:							# myXML_Pickler().dumps()
            return dumps(self, binary, deepcopy=deepcopy, version=version)		

    def load(self, fh, paranoia=None, min_accept='1.3'):
        return load(fh, paranoia, min_accept=min_accept)

    def loads(self, xml, paranoia=None, min_accept='1.3'):
        return loads(xml, paranoia, min_accept=min_accept)
    
#------------------------------------------------------------------------
#
# Internal API
#
#------------------------------------------------------------------------

#
# xml.pickle "meta" parser. Detects if this is a 1.1 or 1.3
# pickle and passes the SAX event to the right handler.
#

from xml.sax.expatreader import ExpatParser
from xml.sax.handler import ContentHandler, ErrorHandler
from xml.sax.xmlreader import InputSource

class xmlpickle_meta_parser(ContentHandler):
    def __init__(self, class_search, allow_replicants, allow_rawpickles,
                 min_accept, extensions):
        ContentHandler.__init__(self)
        self.real_parser = None
        self.opt_class_search = class_search
        self.opt_allow_replicants = allow_replicants
        self.opt_allow_rawpickles = allow_rawpickles
        self.opt_min_accept = min_accept
        self.opt_extensions = extensions
        self.stats = XMLPickleStats()
        
    def get_object(self):
        "Get parsed object."
        return self.real_parser.get_object()

    def get_stats(self):
        if self.stats.pickle_version == '1.3':
            st = self.real_parser.get_stats()
            st.pickle_version = '1.3'
            return st
        else:
            # don't have real stats in 1.1, just return with .pickle_version
            return self.stats
        
    def startDocument(self):
        # I'll send a 'startDocument' after I figure out which
        # parser to use
        pass

    def endDocument(self):
        self.real_parser.endDocument()
        
    def startElement(self,name,attrs):
        # if at root <PyObject> pull out pickle version
        if self.real_parser is None and name == 'PyObject':
            # get 'version='; if missing, then it is version 1.1
            version = attrs._attrs.get('version','1.1')

            # future-proofing; be explicit with versions I accept
            if version == '1.1':
                if self.opt_min_accept != '1.1':
                    raise XMLUnpicklingError("I'm not allowed to unpickle this object with min_accept=%s. Need min_accept='1.1'." % self.opt_min_accept)
                
                # version 1.1 SAX parser		
                from gnosis.xml.pickle.prev.ver_11.parsers._sax import xmlpickle_handler as v11_sax_parser
                        
                self.real_parser = v11_sax_parser(self.opt_class_search,
                                                  self.opt_allow_replicants)
                self.stats.pickle_version = "1.1"

            elif version == '1.3':
                from gnosis.xml.pickle.parser import xmlpickle_handler
                self.real_parser = xmlpickle_handler(self.opt_class_search,
                                                     self.opt_allow_replicants,
                                                     self.opt_allow_rawpickles,
                                                     self.opt_extensions)
                self.stats.pickle_version = "1.3"				
                
            else:
                raise XMLUnpicklingError("You need a newer version of Gnosis_Utils to unpickle this object.")
            
            # send a "startDocument" now
            self.real_parser.startDocument()

        # pass along the startElement, in either case
        self.real_parser.startElement(name, attrs)

    def endElement(self,name):
        self.real_parser.endElement(name)
        
    def characters(self,content):
        self.real_parser.characters(content)

    def processingInstruction(self, target, data):
        if self.stats.pickle_version != '1.1':
            # 1.1 didn't handle processing instructions
            self.real_parser.processingInstruction(target, data)
        
    # implement the ErrorHandler interface
    def error(self,exception):
        if self.real_parser is None:
            print "ERROR %s" % str(exception)
            # re-raise exception			
            raise
        else:
            self.real_parser.error(exception)
        
    def fatalError(self,exception):
        if self.real_parser is None:
            print "FATAL ERROR %s" % str(exception)
            # re-raise exception			
            raise
        else:		
            self.real_parser.fatalError(exception)
        
    def warning(self,exception):
        if self.real_parser is None:
            print "WARNING %s" % str(exception)
            # re-raise exception			
            raise
        else:		
            self.real_parser.warning(exception)

    # Implement EntityResolver interface (called when the parser runs
    # across external entities - in our case, PyObjects.dtd).
    # We'll hit this before startElement, so it has to be handled here.
    # Just ignore; DTD reference is only present for external validator use. 
    def resolveEntity(self,publicId,systemId):
       inp = InputSource()
       inp.setByteStream(StringIO(""))
       return inp

