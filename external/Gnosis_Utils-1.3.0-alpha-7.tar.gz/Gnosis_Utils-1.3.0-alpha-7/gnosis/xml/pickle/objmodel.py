"""
The xml.pickle 1.3 object model. This is responsible for taking objects apart
and putting them back together (sort of like the standard marshal module).

This module has the following public functions:

   decompose():
      Takes an arbitrary object and splits it into pieces, ready for 
      the XML tag writer (or any other backend serializer).

   compose_*()
      Takes the values from decompose() and recreates the original object. 
      See 'demo_compose()' for usage example.
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from types import *
import re, new, sys
from gnosis.xml.xmlmap import is_legal_xml, raw_illegal_xml_regex
from gnosis.xml import xmlcoder
from gnosis.xml.pickle.getclass import get_class_from_name, \
     unpickle_function
from gnosis.xml.pickle.api import XMLPicklingError, XMLUnpicklingError,\
     SEARCH_STORE
from copy import copy
from gnosis.pyconfig import pyconfig
from replicants import lookup_replicant_class, make_replicant_class, replicant_info
import replicants
import fpformat

# ASCII that is safe to put in an attribute
# [i.e. non-breaking, doesn't require repr()/eval(), and the XML
# parser won't change, if it's parsed as CDATA]
# -- Don't use directly -- use is_safe_attr_ASCII!! --
re_safe_attr_ASCII = re.compile(r'^[\x20-\x7e]*$')

# roughly match a superset of legal 'numeric' values
re_rough_numeric = re.compile(r'^\s*[\+\-0-9\.:eL]+\s*$')

def is_safe_attr_ASCII( s ):
    """
    Is 's' legal to place directly in an attribute?
    (s may still contain things like <> that need escaping).
    This just checks vs. non-breaking whitespace & binary.
    """
    m = re_safe_attr_ASCII.match(s)

    # the regexp will allow \n at the end to match $, so
    # check that the lengths match as well
    return (m is not None and xmlcoder.is_string_exactly(s) and len(m.group(0)) == len(s))

def split_classtag( classtag ):
    "Given a dotted module.classname, split it and return (modname, classname)"
    if classtag is None:
        return (None,None)
    
    parts = classtag.split('.')
    if len(parts) == 1:
        modname = None
        classname = parts[0]
    else:
        modname = '.'.join(parts[:-1])
        classname = parts[-1]
        
    return modname,classname

def get_base_or_subclass( base, classtag, class_search, allow_replicants, typestr ):
    "typestr is for info; which type= is being loaded?"
    
    if classtag is None:
        return base, 0

    if typestr in ['set','frozenset'] and not pyconfig.Have_BuiltinSet():
        if not allow_replicants:
            raise XMLUnpicklingError("Cannot create type=%s, class=%s when allow_replicants=0" % (typestr,classtag))
        
        if classtag is None:
            classtag = '__builtin__.%s' % typestr

        m,n = split_classtag(classtag)
        k = lookup_replicant_class(m, n)
        if k is None:
            k = make_replicant_class(m, n, typestr)
            
        return k,1
    
    modname,classname = split_classtag(classtag)
    return get_class_from_name( classname, modname, class_search,
                                allow_replicants, typestr )

def type_needs_finalization( typestr ):
    """
    Does the given type= need to be finalized?
    If so, make sure to call finalize_object().
    If not, do NOT call finalize_object().
    """
    return composers_table[typestr][4]

def finalize_object( rawobj, attrs ):
    """
    Finalize the given object by setting its attributes,
    and calling one or more of __init__, __setstate__.

    attrs is a dict of attributes for the object.
    This may contain both object data, as well as
    special tags:
         #initargs = Value returned from __getinitargs__ during pickling.
         #state = Value returned from __getstate__ during pickling,
                  if not a dict.
    """
    #print "--- <enter> FINALIZE ",rawobj,attrs
    
    if attrs is None:
        raise XMLUnpicklingError("attrs cannot be None")

    # I need to delete the special attrs as they are used, but
    # it's bad practice to modify attrs, so ...
    attrs = copy(attrs)
    
    # ordering below is matched to the ordering in pickle.py;
    # don't change, else it won't match the protocol correctly

    # if #initargs present, pass to __init__
    if attrs.has_key('#initargs'):
        apply( rawobj.__init__, attrs['#initargs'] )
        del attrs['#initargs']
        
    # next, decide how to populate object attributes.
    # careful: an object can have __getstate__ without
    # __setstate__, and vice versa.
    if attrs.has_key('#state'):
        # data may be an arbitrary object, if __setstate__ present		
        data = attrs['#state'] 
        del attrs['#state']
        # ugh ... there are objects out there (see numpy) that define __setstate__ but
        # not __getstate__, so don't actually use __setstate__ unless #state is present
        found_state = 1
    else:
        data = attrs
        found_state = 0

    # -- all special attrs have been removed now --
    
    # how should I put 'data' into object?
    if found_state and hasattr(rawobj, '__setstate__'):
        rawobj.__setstate__(data)
    else:
        # sanity - must be a dict if no __setstate__
        # (if __setstate__ present, 'data' can be any object)
        if type(data) is DictType:
            for key,val in data.items():
                setattr(rawobj, key, val)
            
        else:
            # subtle -- this can happen either because the class really
            # does violate the pickle protocol, or because class_search
            # was restricted and we couldn't create the real class, so
            # __setstate__ is missing (and #stateval isn't a dict)
            raise XMLUnpicklingError("Non-DictType without setstate violates pickle protocol."+\
                                     "(class_search/allow_replicants setting may be too restrictive)")

    #print "--- <exit> FINALIZE", rawobj
    return rawobj

#
# Dataflow for composing objects:
#
# 1. Given type=, call:
#		core_first = compose_needs_coredata(typestr)
#
# 2. If core_first == True, collect coredata first, then call:
#		 obj,is_replicant = compose_top_core()
#
# 3. Else, immediately call:
#		 obj,is_replicant = compose_top_nocore()
#
# 4. Collect all subitems.
#
# 5. If coredata present, and not core_first, call:
#		 compose_setcore( coredata )
#
# 6. finalize_object()
#

def demo_compose( typestr, classtag, coredata, attrs,
                  class_search=SEARCH_STORE, allow_replicants=1 ):
    """
    A 'demo' of a full compose. Its called 'demo' because the parser
    won't actually use it this way, but this is convenient for
    low-level test purposes.
    """
    # do I have to pass coredata to create?
    core_first = compose_needs_coredata( typestr )

    # turn UElement back into raw coredata, so lower levels
    # don't have to care where the data came from
    if isinstance(coredata,UElement):
        coredata.decode()
        coredata = coredata.plain

    if hasattr(attrs,'#newargs'):
        newargs = attrs['#newargs']
        del attrs['#newargs']
    else:
        newargs = None
        
    if core_first:
        obj,is_replicant = compose_top_core( typestr, classtag, coredata, newargs,
                                             class_search, allow_replicants )
    else:
        obj,is_replicant = compose_top_nocore( typestr, classtag, newargs,
                                               class_search, allow_replicants )
        compose_setcore( typestr, obj, coredata )

    # should it be finalized?
    if composers_table[typestr][4]:
        obj = finalize_object(obj, attrs)
    
    return obj

def type_wants_core( typestr ):
    """
    Does the given type= use coredata?
    """
    return composers_table[typestr][0]

def compose_needs_coredata( typestr ):
    """
    For the given type=, which version of compose_top do you call?

    If it returns True: call compose_top_core() with the coredata
    Else: call compose_top_nocore()
    """
    # if obj wants core AND setcore==None, then it needs
    # core at creation time
    if (composers_table[typestr][0]) and \
       (composers_table[typestr][1] is None):
        return 1 # need core at creation
    else:
        # either don't have core, or want it later
        return 0

def get_default_coredata( typestr ):
    """
    Get the default 'empty' coredata value for the type=.
    Will be None if there is no 'empty' value.
    
    (Only containers will have an 'empty' value.)
    """
    return composers_table[typestr][2]

def compose_setcore( typestr, obj, coredata ):
    if coredata is None:
        return # no coredata

    # this checks for exact types
    if type(coredata) not in [StringType,UnicodeType,ListType,DictType]:
        raise XMLUnpicklingError("Illegal coredata type '%s'" % str(coredata))

    if replicants.is_replicant(obj):
        obj.__coredata__ = coredata
        return
    
    setcore = composers_table[typestr][1]
    if setcore is None:
        # someone stuffed coredata into a non-coredata type
        raise XMLUnpicklingError("type='%s' cannot have coredata" % typestr)

    return setcore(obj,coredata)

def compose_top_core( typestr, classtag, coredata, newargs=None,
                      class_search=SEARCH_STORE, allow_replicants=1 ):
    """
    Rebuild a pickled object from its decomposed parts.
    You must only call this if 'compose_needs_coredata()' returns True.
    
    Inputs:
       typestr: The type= value
       classtag: The class= value, or None.
       coredata: Coredata
       newargs: The __getnewargs__() for the object, or None if no newargs.
       class_search,allow_replicants: Defines search restrictions for object loading.

    Returns:
       (obj, is_replicant)
    """

    return composers_table[typestr][3]( classtag, coredata, newargs,
                                        class_search, allow_replicants )

def compose_top_nocore( typestr, classtag, newargs,
                        class_search=SEARCH_STORE, allow_replicants=1 ):
    """
    Rebuild a pickled object from its decomposed parts.
    You must only call this if 'compose_needs_coredata()' returns False.
    
    Inputs:
       typestr: The type= value
       classtag: The class= value, or None.
       newargs: The __getnewargs__() for the object, or None if no newargs.
       class_search,allow_replicants: Defines search restrictions for object loading.
    Returns:
       (obj, is_replicant)
    """ 
    return composers_table[typestr][3]( classtag, newargs,
                                        class_search, allow_replicants )
    
# Object composition is broken into steps (see DESIGN for full background):
#
# For classes that can have self-referencing coredata (which means
# their coredata is mutable):
#	 1. Create an empty object of the correct class, with empty coredata.
#	 2. Set the coredata, at an abitrarily later time.
#	 3. Finalize object by inserting its attributes, calling
#		__setstate__, __init__, etc.
#
# For classes that cannot have self-referencing coredata (which means
# their coredata is non-mutable):
#	 1. Create empty object of the correct class, simultaneously setting
#		its coredata.
#	 2. Finalize object by inserting its attributes, calling
#		__setstate__, __init__, etc.
#
# For classes with no coredata:
#	 1. Create empty object of the correct class.
#	 2. Finalize object by inserting its attributes, calling
#		__setstate__, __init__, etc.
#
# All objects will use the same finalize() routine, so it is just
# a matter of creating the first step(s) for each "type="
#

def maketop_empty_core( baseclass, classtag, newargs,
                        class_search, allow_replicants, typestr ):
    """
    Generic 'maketop' for classes whose coredata can be set later.
    (Also works for classes with no coredata).
    
    Note that __new__ works differently for mutables & immutables.
    This version is for mutables; it does not pass coredata to __new__.
    Caller is responsible for inserting coredata.

    'baseclass' can be None for oldstyle classes; it is always safe
    to pass baseclass=object.
    """ 
    klass,is_replicant = get_base_or_subclass( baseclass, classtag,
                                               class_search, allow_replicants,
                                               typestr )

    if is_replicant:
        obj = klass() # calling __init__ is OK for the replicants
        return obj, is_replicant
    
    if pyconfig.Have_ObjectClass() and issubclass(klass,object):
        # __new__ only works on newstyle classes

        # baseclass may be None, so try calling klass.__new__ first.
        # If that fails, fallback on baseclass.
        try:
            if newargs is not None:
                return klass.__new__(klass,*newargs), is_replicant
            else:
                return klass.__new__(klass), is_replicant
        except TypeError:
            # klass.__new__ will fail if class defines __new__ args, but doesn't
            # define __getnewargs__(). In this case, call baseclass.__new__ to
            # get a bare object that will be filled in.
            if not baseclass:
                raise XMLUnpicklingError("INTERNAL ERROR: Need baseclass, but baseclass=None")
            return baseclass.__new__(klass), is_replicant
        
    else:
        if newargs != None:
            raise XMLUnpicklingError("__newargs__ aren't allowed for oldstyle classes.")
        
        # oldstyle way of not calling __init__
        return new.instance(klass,{}), is_replicant

def setcore_list( obj, core ): obj[:] = core
def setcore_dict( obj, core ):	obj.update( core )
def setcore_set( obj, core ): obj.update( core )

def maketop_list( classtag, newargs, class_search, allow_replicants ):	
    if pyconfig.Have_ObjectClass():
        return maketop_empty_core( list, classtag, newargs,
                                   class_search, allow_replicants, 'list' )
    else:
        if classtag is None:
            # exact type
            return [],0
        else:
            # make a replicant			
            return maketop_empty_core( None, classtag, newargs,
                                       class_search, allow_replicants, 'list' ) 

def maketop_set( classtag, newargs, class_search, allow_replicants ):
    if pyconfig.Have_BuiltinSet():		
        return maketop_empty_core( set, classtag, newargs,
                                   class_search, allow_replicants, 'set' )
    else:
        return maketop_empty_core(None, classtag, newargs,
                                  class_search, allow_replicants, 'set')

def maketop_dict( classtag, newargs, class_search, allow_replicants ):
    if pyconfig.Have_ObjectClass():
        return maketop_empty_core( dict, classtag, newargs,
                                   class_search, allow_replicants, 'dict' )
    else:
        if classtag is None:
            # exact type			
            return {},0
        else:
            # make a replicant			
            return maketop_empty_core( None, classtag, newargs,
                                       class_search, allow_replicants, 'dict' )
    
def maketop_immutable( baseclass, classtag, coredata, newargs,
                       class_search, allow_replicants, typestr ):
    """
    Generic 'maketop' for immutables that need their coredata immediately.
    
    Immutables are a bit easier; just pass coredata to __new__.
    """
    # this routine relies on the fact that __init__ in subclasses of
    # immutable builtins must match the baseclass definition, so
    # that __new__(klass,coredata) always does the right thing.
    # see test_assumptions.py:003

    # load klass, or make replicant of class
    klass,is_replicant = get_base_or_subclass( baseclass, classtag,
                                               class_search, allow_replicants,
                                               typestr )

    if is_replicant:
        obj = klass() # calling __init__ is OK for the replicants
        obj.__coredata__ = coredata
        return obj, is_replicant
    
    # if obj has __getnewargs__, then pass those to __new__ (must be
    # a tuple; can never be 'None'
    if newargs != None:
        # not baseclass.__new__!
        obj = klass.__new__(klass, *newargs)
    elif coredata is not None:
        # create & set coredata. with no __newargs__, the class *MUST*
        # take these exact args to __new__
        obj = baseclass.__new__(klass, coredata)
    else:
        # no coredata given
        obj = baseclass.__new__(klass)
    
    return obj, is_replicant

def maketop_tuple( classtag, coredata, newargs, class_search, allow_replicants ):
    if pyconfig.Have_ObjectClass():
        return maketop_immutable(tuple, classtag, coredata, newargs,
                                 class_search, allow_replicants, 'tuple' )
    else:
        if classtag is None:
            # exact type			
            return tuple(coredata),0
        else:
            # make a replicant
            return maketop_immutable(None, classtag, coredata, newargs,
                                     class_search, allow_replicants, 'tuple' )
        
def maketop_frozenset( classtag, coredata, newargs, class_search, allow_replicants ):
    if pyconfig.Have_BuiltinSet():			
        return maketop_immutable(frozenset, classtag, coredata, newargs,
                                 class_search, allow_replicants, 'frozenset' )
    else:
        # has to be a replicant, so it is cleaner to use maketop_empty_core
        # routine and set core manually
        obj,is_replicant = maketop_empty_core(None, classtag, newargs,
                                              class_search, allow_replicants,
                                              'frozenset')
        if not is_replicant:
            raise XMLUnpicklingError("Internal error: Expecting a replicant for (frozenset,%s), got %s" % \
                                     (classtag,klass))
            
        obj.__coredata__ = coredata
        return obj, is_replicant
    
def maketop_string( classtag, coredata, newargs, class_search, allow_replicants ):
    # only two cases:
    #	parser will pass coredata=str() if I'm a str() or subclass
    #	parser will pass coredata=unicode() if I'm a unicode() or subclass

    if pyconfig.Have_ObjectClass():
        if isinstance(coredata,str): baseclass = str
        elif isinstance(coredata, unicode): baseclass = unicode
        else: raise XMLUnpicklingError("Bad coredata in compose_string")
    else:
        if classtag is None:
            # exact class
            return coredata,0

        # make a replicant
        baseclass = None
        
    obj,is_replicant = maketop_immutable(baseclass, classtag, coredata, newargs,
                                         class_search, allow_replicants, 'string')
    
    if is_replicant:
        obj.__coredata__ = coredata

    return obj,is_replicant
        
def maketop_numeric( classtag, coredata, newargs, class_search, allow_replicants ):
    
    # first, a safety check to make sure the coredata string is roughly some
    # sort of numeric value (actually, Python should safely raise an exception
    # on any non-legal values, but this is an extra sanity check)
    if coredata is None:
        raise XMLUnpicklingError("Numeric without coredata - what??")
    
    if not re_rough_numeric.match(coredata):
        raise XMLUnpicklingError("Non-numeric data passed to compose_numeric")

    #print "MAKETOP_NUMERIC ",coredata,classtag
    
    obj = None

    if pyconfig.Have_ObjectClass():
        bases = [complex, float, long, int]
    else:
        bases = [None, None, None, None]
        
    # -- convert coredata from string -> real numeric value
    # -- and set correct baseclass

    # complex? (check first, since can also contain '.' or L)
    if ':' in coredata:
        # turn string into complex coredata (all others can be
        # parsed directly by Python, but not our special format)
        p = coredata.split(':')
        coredata = complex(float(p[0]), float(p[1]))
        baseclass = bases[0]
        
    # float?
    elif '.' in coredata:
        coredata = float(coredata)
        baseclass = bases[1]
        
    # long?
    elif coredata[-1] == 'L':
        coredata = long(coredata)
        baseclass = bases[2]
        
    # else, by elimination, it must be an integer
    else:
        coredata = int(coredata)
        baseclass = bases[3]
        
    if classtag is None:
        # baseclass, so it's just the coredata
        return coredata,0

    return maketop_immutable(baseclass, classtag, coredata, newargs,
                             class_search, allow_replicants, 'numeric' )

##def PRE_maketop_numeric( classtag, coredata, newargs, class_search, allow_replicants ):
    
##	# first, a safety check to make sure the coredata string is roughly some
##	# sort of numeric value (actually, Python should safely raise an exception
##	# on any non-legal values, but this is an extra sanity check)
##	if coredata is None:
##		raise XMLUnpicklingError("Numeric without coredata - what??")
    
##	if not re_rough_numeric.match(coredata):
##		raise XMLUnpicklingError("Non-numeric data passed to compose_numeric")

##	obj = None

##	if pyconfig.Have_ObjectClass():

##		# complex? (check first, since can also contain '.' or L)
##		if ':' in coredata:
##			baseclass = complex
        
##		# float?
##		elif '.' in coredata:
##			baseclass = float

##		# long?
##		elif coredata[-1] == 'L':
##			baseclass = long

##		# else, by elimination, it must be an integer
##		else:
##			baseclass = int

##	else:
##		baseclass = None
        
##	if ':' in coredata:
##		# turn string into complex coredata (all others can be
##		# parsed directly by Python, but not our special format)
##		p = coredata.split(':')
##		coredata = complex(float(p[0]), float(p[1]))

##	return maketop_immutable(baseclass, classtag, coredata, newargs,
##							 class_search, allow_replicants, 'numeric' )

def maketop_pyobj( classtag, newargs, class_search, allow_replicants ):

    if pyconfig.Have_ObjectClass():
        return maketop_empty_core( object, classtag, newargs,
                                   class_search, allow_replicants, 'pyobj' )
    else:
        # can only make old-style, so never need baseclass
        return maketop_empty_core( None, classtag, newargs,
                                   class_search, allow_replicants, 'pyobj' )

def maketop_blob( classtag, coredata, newargs, class_search, allow_replicants ):

    # sanity
    if classtag != None:
        raise XMLUnpicklingError('Blob cannot have class=')
    
    # simple - core has already been decoded for us
    return coredata,0

def maketop_function( classtag, newargs, class_search, allow_replicants ):

    if not classtag:
        # there is no base/default function to use
        raise XMLUnpicklingError("class= must be given in compose_function")

    modname,classname = split_classtag(classtag)
    # will never be a replicant
    return (unpickle_function( modname, classname, class_search ), 0)

def maketop_class( classtag, newargs, class_search, allow_replicants ):

    if not classtag:
        # there is no base/default class to use		
        raise XMLUnpicklingError("class= must be given in compose_function")

    return get_base_or_subclass( None, classtag, class_search,
                                 allow_replicants, 'class' )

def maketop_none( classtag, newargs, class_search, allow_replicants ):
    # easy; no coredata, attrs or subclasses possible
    return None, 0

def maketop_true( classtag, newargs, class_search, allow_replicants ):
    # easy; no coredata, attrs or subclasses possible
    return True, 0

def maketop_false( classtag, newargs, class_search, allow_replicants ):
    # easy; no coredata, attrs or subclasses possible
    return False, 0

# The following table is keyed by "type=" and is made of
# these tuples:
#
#	(hascore, setcore, default_core, create_top, do_finalize)
#
# Where:
#	 hascore = 1/0 indicating that the type has coredata
#
#	 setcore = Function to set the coredata for types with mutable cores.
#			   It is called as: setcore( object, coredata )
#			   Where 'coredata' will be one of these *exact* types,
#			   no subclasses allowed: string, unicode, list, dict, None.
#
#			   If setcore==None, it means the type needs its coredata at
#			   creation time.
#
#	 default_core = Some types have a default ("empty") core value.
#					For those types, the value is here.
#					If no "empty" default makes sense, then this is None
#					('None' can never be valid coredata, see below.)
#
#	 create_top = 'Top half' of the object creation.
#				  If (hascore and setcore == None) (needs core at creation time),
#				  it will be called as:
# 
#					   create_top( classtag, coredata,
#								   class_search, allow_replicants )
#
#					   classtag:
#						   Value from "class='..'", or None if it's a baseclass.
#
#					   coredata:
#						   As above, will be a string,unicode,list or dict,
#						   with None meaning "empty coredata". (This is not
#						   ambiguous, since the only object that could possibly
#						   have core=None would be None, but None is defined
#						   below as having no coredata.)
#					   
#				  Else if (not hascore or setcore != None):
#					   create_top( classtag, class_search, allow_replicants )
#
#					   'create_top' must set the object's coredata to
#					   a valid empty value. If there is no coredata in the pickle,
#					   then setcore will ever be called.
#
#				  Both forms of create_top return: (object, made_replicant)
#				  Where made_replicant is 0 or 1, indicating whether a
#				  replicant was created (must be an integer).
#
#	 do_finalize = 1/0, if the object needs to be finalized.
#				   This is mainly a sanity check - if finalization data
#				   is found in the XML stream, but the object doesn't
#				   support attributes, etc., an error will be raised.
#
#				   NOTE: An object can still be passed to a mutator, even
#				   if it doesn't need finalization. "Finalization" means
#				   'completion of the object before it is passed to the
#				   mutator stack'.
#

composers_table = {
    # Types with mutable coredata
    'list':		 (1, setcore_list, [],	 maketop_list,		1),
    'set':		 (1, setcore_set,  [],	 maketop_set,		1),
    'dict':		 (1, setcore_dict, {},	 maketop_dict,		1),
    # Types with non-mutable coredata
    'numeric':	 (1, None,		   None, maketop_numeric,	1),
    'string':	 (1, None,		   None, maketop_string,	1),
    'tuple':	 (1, None,		   [],	 maketop_tuple,		1),
    'frozenset': (1, None,		   [],	 maketop_frozenset, 1),
    # Has coredata, but no finalization. Coredata is usually in <u>
    # but it's legal to omit it (Mutator API attaches #mutators
    # in a coreless blob). So, set the default core to '' since it
    # will be "don't care" in cases like that.
    'blob':		 (1, None,		   '',	 maketop_blob,		0),
    # No coredata, but needs finalization.
    'pyobj':	 (0, None,		   None, maketop_pyobj,		1),
    # Types with no coredata, and no finalization step
    'None':		 (0, None,		   None, maketop_none,		0),
    'True':		 (0, None,		   None, maketop_true,		0),
    'False':	 (0, None,		   None, maketop_false,		0),
    'class':	 (0, None,		   None, maketop_class,		0),
    'function':	 (0, None,		   None, maketop_class,		0)
    }

# -- regexps for the counting routines below --

# Match 'binary' ASCII - this regex assumes that the ASCII is
# going to be put into the body text, so breaking whitespace & tabs
# are OK here. (Note this regex must be exact, since it is reused
# for the exhastive test.)
re_binary_ascii = re.compile('[^\x09\x0a\x0d\x20-\x7e]+')

# This is a subset of the XML-illegal set. Excluded are single chars of a
# two-char set that are illegal by themselves. Including those would
# slow the regex, and complicate the counting because of subgroup matches.
# We're just estimating the "bad values" count, so this is fine. We'll
# check full legality before declaring a string to be 'unicode/plain',
# so nothing will be missed.
re_basic_bad_xml = re.compile(u'[\u0000-\u0008\u000b-\u000c\u000e-\u001f\ufffe-\uffff]+')

def count_binary_ascii( txt ):
    """
    Count binary bytes in txt. Assumes txt will be
    placed in a tag body, not attribute. Returns count.
    """
    p = re_binary_ascii.findall(txt)
    return len( ''.join(p) )

def estimate_bad_xml( utxt ):
    """
    Estimate the count of 'bad' XML chars in unicode string utxt.
    Assumes utxt will be placed in a tag body, not attribute.
    Returns count.
    """
    #print "ESTIM ",repr(utxt)
    p = re_basic_bad_xml.findall(utxt)
    #print "P",p
    return len( u''.join(p) )

class UElement:
    """
    Holds data to/from a <u> element.
    UElement is intended to be one of the coredata types, so
    it is an object. .decode() and .encode() need to take no
    parameters, in order to avoid passing parameters around,
    so the dataflow looks a little different.

    Note that, when encoding, if 'plain' is not *exactly* a string/unicode
    (no subclasses), data will be cPickled.

    Usage (keyword args are recommended):

       Plain -> Encoded:
           u = UElement( plain=data, allow_rawpickles=value )
           u.encode()
           # now u.encoded and u.encoding are valid
           
       Encoded -> Plain:
           u = UElement( encoded=data, encoding=enc, allow_rawpickles=value )
           u.decode()
           # now u.plain is valid
    """
    def __init__(self, plain=None, allow_rawpickles=0, encoded=None, encoding=None):
        self.plain = plain
        self.allow_rawpickles = allow_rawpickles
        self.encoded = encoded
        self.encoding = encoding

    def __str__(self):
        return "UElement plain=%s, allow_rawpickles=%d, encoded=%s, encoding=%s" % \
              (repr(self.plain),self.allow_rawpickles,repr(self.encoded),self.encoding)
    
    def decode(self):
        """
        Decode my encoded data with my encoding.
        Updates .plain
        """
        if not self.allow_rawpickles and self.encoding[:6] == 'pickle':
            raise XMLUnpicklingError("I'm not allowed to decode encoding=\"%s\" when allow_rawpickles=0" % \
                                     self.encoding)
        
        self.plain = xmlcoder.decode_as( self.encoded, self.encoding )
    
    def encode(self):
        """
        Encode my plain data with an appropriate coding.
        Updates .encoded, .encoding
        """
        data = self.plain

        if xmlcoder.is_string_exactly( data ):
            # does the string contain any binary?
            if re_binary_ascii.search(data):
                codec = 'string/base64'
            else:
                codec = 'string/plain'

        elif xmlcoder.is_unicode_exactly( data ):
            
            # does it contain anything that needs escaping?
            if not is_legal_xml(data):
                codec = 'unicode/utf8-base64'
            else:
                codec = 'unicode/plain'

        else:
            # it is something that needs cPickling
            codec = 'pickle/c-base64'
            
            # before actually calling cPickle, see if I'm allowed to do so.
            # this avoids any potential security holes that might be created by
            # calling cPickle.
            if not self.allow_rawpickles:
                raise XMLPicklingError("I'm not allowed to encode \"%s\" when allow_rawpickles=0" % repr(data))
            
        self.encoded = xmlcoder.encode_as(data, codec) 
        self.encoding = codec
        
        # XXX this is nice, but too slow to be the default policy. I'm keeping
        # the code (commented out) in case I want to add it in a hook later.
        
#		# try and pick the best encoder without doing an exhaustive search
#		
#		fast = 1
#
#		if xmlcoder.is_string_exactly( data ):
#
#			# does the string contain any binary?
#			if re_binary_ascii.search(data):				
#				# sample 40 bytes from middle of string to estimate
#				# how much binary it contains (data shorter than 40 chars
#				# will be caught by one of last two cases; if the estimate
#				# is wrong, binary strings will still be caught by the next
#				# to last case, so nothing will be missed)
#				i = len(data)/2
#				nr = count_binary_ascii( data[i:i+40] )
#
#				if nr >= 20:
#					# assume mostly binary; decide if it's worth compressing
#					if len(data) > 8000:
#						bin,comp = 2,1
#					else:
#						bin,comp = 2,0
#						
#				else:
#					# assume some binary, but still readable; don't compress
#					bin, comp = 1,0
#					
#			else:
#				# no binary
#				bin, comp = 0,0
#
#		elif xmlcoder.is_unicode_exactly( data ):
#			
#			# does it contain anything that needs escaping?
#			if not is_legal_xml(data):
#				
#				# see notes above, same 'sampling' idea here
#				i = len(data)/2
#				nr = estimate_bad_xml( data[i:i+40] )
#
#				if nr >= 20:
#					# assume mostly binary; decide if it's worth compressing
#					if len(data) > 8000:
#						bin,comp = 2,1
#					else:
#						bin,comp = 2,0
#						
#				else:
#					# assume some binary, but readable; don't compress
#					# (fast=0 makes it use xml-escape which preserves
#					# more of the unicode content in readable form)
#					bin, comp = 1,0
#					fast = 0
#					
#			else:
#				# no binary
#				bin,comp = 0,0
#		
#
#		else:
#			# it is something that needs cPickling; might as well compress,
#			# since there is no way to know the length right now
#			bin,comp = 1,1
#
#			# before actually calling cPickle, see if I'm allowed to do so.
#			# this avoids any potential security holes that might be created by
#			# calling cPickle.
#			if not self.allow_rawpickles:
#				raise XMLPicklingError("I'm not allowed to encode \"%s\" when allow_rawpickles=0" % repr(data))
#			
#		self.encoded,self.encoding = xmlcoder.encode( data, bin, comp, fast=fast )

def del_coredata_if_newargs(attrs, coredata):
    # if there is a #newargs attribute, then coredata is
    # redundant, and should not be placed in the pickle
    if attrs.has_key('#newargs'):
        coredata = None

    return attrs,coredata

def decompose_replicant(obj):
    """
    Take a replicant and decompose it back into its
    original parts, as closely as possible.

    Same return values as decompose()
    """
    inf = replicant_info(obj)

    # turn __coredata__ (if present) back into one of
    # the coredata types (string,unicode,dict,list,None)
    
    if not hasattr(obj,'__coredata__') or obj.__coredata__ == None:
        coredata = None
    else:
        # obj.__coredata__ must be one of the 'base' types
        typestr,corefunc = base_atoms.get(type(obj.__coredata__), (None,None))
        if corefunc != None:
            coredata = corefunc(obj.__coredata__)
        else:
            typestr,corefunc = base_containers.get(type(obj.__coredata__),
                                                   (None,None))
            if not corefunc:
                raise XMLPicklingError("Replicant has bad __coredata__: %s" % repr(obj.__coredata__))

            coredata = corefunc(obj.__coredata__)

    # if coredata is Unicode, put it in a UElement
    if xmlcoder.is_unicode_exactly(coredata):
        # no rawpickles will be required to encode unicode
        coredata = UElement(plain=coredata, allow_rawpickles=0)
        coredata.encode()
        
    classtag = '%s.%s' % (inf[1],inf[2])
    attrs = get_pickleable_attrs(obj)
    if attrs.has_key('__coredata__'):
        del attrs['__coredata__']

    return (inf[0], classtag, coredata, attrs)

# Checklist of things that are known to be unpickleable (standard pickle
# doesn't handle these either - see test_assumptions.py:004)
# Note that LambdaType can't be placed here since LambdaType==FunctionType.
# Lambdas are caught in try_classify_atom().
KNOWN_UNPICKLEABLE_TYPES = [BufferType, CodeType, EllipsisType, FileType,
                            FrameType, MethodType,
                            ModuleType, SliceType, TracebackType, XRangeType]

if pyconfig.Have_GeneratorExpressions():
    KNOWN_UNPICKLEABLE_TYPES.append(GeneratorType)	

def decompose( obj, allow_replicants, allow_rawpickles ):
    """
    Given an arbitrary object 'obj', decompose it into a form
    ready to be made into an xml.pickle element.
    
    allow_replicants specifies whether decompose is allowed to
    decompose replicant objects (1=yes, 0=no)
    
    allow_rawpickles specifies whether decompose is allowed to
    create cPickles for unknown types (1=yes, 0=no)
    
    Returns:
       (type, classtag, coredata, attrs)

    Where:
       type = One of the xml.pickle 'type=' values.
       
       classtag = 'module.class' tag, or None if it isn't needed
                  for unpickling (e.g. for baseclasses and 'unique' types)
                  
       coredata = The coredata for obj. Will be *exactly* one of
                       - string (for 'value=' attribute)
                       - UElement (for <u> element; already encoded)
                       - list
                       - dict
                       - None

                  Each will be an *exact* type, no subclasses.
                  'None' means 'no coredata' (None can never
                  be a coredata value, so there's no ambiguity.)

       attrs = obj attributes as a dict, or {} if no attributes.
               Will contain special attrs such as #initargs, etc.
    """
    # Check vs. known unpickleable objects
    if type(obj) in KNOWN_UNPICKLEABLE_TYPES:
        raise XMLPicklingError("Unable to pickle objects of type '%s' (%s)" % \
                               (type(obj),repr(obj)))
                     
    # If decomposing a replicant, reconstruct the parts as
    # closely as possible. I think it's better to do it all
    # in one place, rather than spread this over, e.g. get_classtag(),
    # get_pickleable_attrs(), etc. For instance, this makes it
    # easy to add a flag to turn off this behavior.
    if replicants.is_replicant(obj):
        if not allow_replicants:
            raise XMLPicklingError("Trying to repickle a replicant (info=%s), but allow_replicants=0" % (str(replicant_info(obj))))
            
        return decompose_replicant(obj)
    
    # check Atoms (atoms are most common, so it is best to
    # check them first)
    is_atom, typestr, classtag, coredata, attrs = try_classify_atom( obj )
    if is_atom:
        attrs,coredata = del_coredata_if_newargs(attrs,coredata)

        if xmlcoder.is_string_exactly(coredata) or xmlcoder.is_unicode_exactly(coredata):
            # if coredata is str() and is safe_attr_ASCII, return as str()
            # so it will be placed in value=; else put in UElement for <u>.
            #if (xmlcoder.is_string_exactly( coredata ) and \
            #	re_safe_attr_ASCII.match(coredata)):
            if is_safe_attr_ASCII(coredata):
                return (typestr, classtag, coredata, attrs)
            else: # return coredata in UElement
                ue = UElement(plain=coredata, allow_rawpickles=allow_rawpickles)
                ue.encode()
                return (typestr, classtag, ue, attrs )
        else:
            return (typestr, classtag, coredata, attrs)

    # check Containers
    is_container, typestr, classtag, coredata, attrs = try_classify_container( obj )
    if is_container:
        attrs,coredata = del_coredata_if_newargs(attrs,coredata)
        
        return (typestr, classtag, coredata, attrs)

    # if not Atom & not Container, try as PlainObject
    # (have to do this *AFTER* ruling out Atom & Container)
    try:
        classtag = get_classtag(obj)
        ok_classtag = 1
    except (AttributeError, XMLPicklingError):
        ok_classtag = 0
        
    if ((pyconfig.Have_ObjectClass() and (isinstance(obj,object))) or \
        type(obj) is InstanceType) and ok_classtag:
        # "regular" object; no coredata, just attributes
        return ('pyobj', classtag, None, get_pickleable_attrs(obj))

    # Everything else falls under 'blob'.

    # no classtags or attrs for blobs, since they are completely
    # defined by their coredata & encoding
    ue = UElement(plain=obj, allow_rawpickles=allow_rawpickles)
    ue.encode()
    return ('blob', None, ue, {})

def get_pickleable_attrs( obj ):
    """
    Get data plus special attributes of obj, per the pickle protocol.
    Returns attributes as a dict.
    
    In addition to normal attributes, may contain the following
    special values:

        #newargs = The object returned from obj.__getnewargs__().
                   [Note this goes into the <meta> part of the pickle,
                   and not the data part like the others here, but
                   this is the right place to call __getnewargs__]
        #initargs = The object returned from obj.__getinitargs__()
        #state = The object returned from obj.__getstate__(), if not
                 a dict. (If it is a dict, then it is written as
                 normal attributes.)				 
    """

    attrs = {}

    # get newargs, if present
    if hasattr(obj,'__getnewargs__'):
        # In standard pickle, you pass protocol=2 if you want
        # pickle to honor your __getnewargs__. That's too much
        # cruft for xml.pickle to add, so this scheme is used:
        #
        #	 1. If obj defines __getnewargs__, use it (assume pickle protocol=2)
        #
        #	 2. If obj inherits __getnewargs__ from a *builtin* type,
        #		then do NOT call. Instead, pickle coredata+attrs and
        #		call base.__new__(class,coredata) -- this matches pickle protocol=1
        #
        #	 3. If __getnewargs__ is inherited from a user-defined class, then
        #		I don't know whether protocol=0 or protocol=2 should be
        #		followed. Raise an exception.

        # Another approach would be just to try calling __new__ here and seeing
        # if it worked. Problem is that __new__ might do something (open a file, etc.)
        # that the caller isn't expecting to happen while pickling.
        inherited = 0
        for k in obj.__class__.__mro__[1:]:
            if hasattr(k,'__getnewargs__'):
                # note: obj.__getnewargs__ != obj.__class__.__getnewargs__!
                if k.__getnewargs__ == obj.__class__.__getnewargs__:
                    # I inherited __getnewargs__ from this baseclass.
                    #
                    # If it is from a builtin type, then do not call - it
                    # it most likely wrong for *my* __new__ and shouldn't
                    # be called (i.e. assume it's pickle protocol=0).
                    #
                    # If it is from a user-defined class, then bail out.
                    # Can't guess what to do; would need explicit protocol flag
                    if not all_subclassable_classes_map.has_key(k):
                        # subclassed from a user-defined class
                        raise XMLPicklingError("%s needs __getnewargs__ here, to resolve ambiguity with baseclass %s; see doc/PickleDifferences.txt" % (str(obj.__class__),str(k)))
                    
                    inherited = 1
                    break

        if not inherited:
            # obj defines OWN __getnewargs__, so assume pickle protocol=2
            args = obj.__getnewargs__()

            # pickle seems to require this to be a tuple
            if type(args) is TupleType:
                attrs['#newargs'] = args
                
            # allow 'None' meaning 'no args' (this is xml.pickle extension,
            # see test_newargs.py, near the end)
            elif args == None:
                pass

            else:
                raise XMLPicklingError, \
                      "__getnewargs__() must return a tuple, or None"			

        # else, obj didn't define __getnewargs__, so will pickle coredata and
        # call baseclass.__new__(klass,coredata)
        
    # get initargs, if present
    if hasattr(obj,'__getinitargs__'):
        args = obj.__getinitargs__()
        try:
            len(args)  # directly from pickle.py: args must be a sequence
        except:
            raise XMLPicklingError, \
                  "__getinitargs__() must return a sequence"

        attrs['#initargs'] = args

    try:
        # see if object has __getstate__		
        data = obj.__getstate__()
    except:
        # no __getstate__ - get data from __dict__/__slots__
        data = get_data_attrs(obj)

    # if object has __setstate__, then data can be *any* arbitrary
    # object, so it needs its own container.
    if hasattr(obj,'__setstate__'):
        attrs['#state'] = data
    else:
        # else, it *must* be a dict, and goes in as normal attrs
        if type(data) is not DictType:
            raise XMLPicklingError, \
                  "__getstate__ must return a DictType here"

        attrs.update(data)

    return attrs

def get_data_attrs( obj ):
    """
    Get just the data attributes of an object (from __dict__ and/or
    __slots__) as a dict. Returns {} if object has no attributes.
    """
    attrs = {}
    
    # an object can have *BOTH* a __dict__ and __slots__ (if __slots__
    # contains '__dict__'). In that case, __dict__ will contains the
    # attrs not contained in __slots__.
    if hasattr(obj, '__dict__'):
        # return a copy: more attributes will be added
        # later, and it would be bad to change the original
        # [copy.copy() fails on some things, i.e. 'float.__dict__',
        # but __dict__.copy() should work everywhere.]
        #return obj.__dict__.copy()
        
        # obj.__dict__ can sometimes be None, which Python < 2.2 doesn't like
        if obj.__dict__ is not None:
            attrs.update(obj.__dict__)
        
    if hasattr(obj, '__slots__'):
        for name in obj.__slots__:
            if name == '__dict__':
                continue # was already added above
            
            if hasattr(obj,name): # not all __slots__ may exist as attrs
                attrs[name] = getattr(obj,name)

    return attrs

def get_classtag( obj ):
    if type(obj) in [ClassType,TypeType]:
        return "%s.%s" % (obj.__module__,obj.__name__)
    elif type(obj) in [FunctionType,BuiltinFunctionType]:
        #return "%s.%s" % get_function_info(obj)
        #return '%s.%s' % (obj.__module__,obj.__name__)
        if hasattr(obj,'__module__'):
            return '%s.%s' % (obj.__module__,obj.__name__)
        else:
            # In Python <= 2.2, functions have no __module__ attribute,
            # so have to scan all modules to find the function ... ugh ...
            # This code is adapted from pickle.py whichmodule()
            for name, module in sys.modules.items():
                if module is None:
                    continue
                    
                if name != '__main__' and \
                    getattr(module, obj.__name__, None) is obj:
                        return '%s.%s' % (module.__name__,obj.__name__)
            else:
                return '__main__.%s' % obj.__name__
                
    else:
        # special case
        if pyconfig.Have_ObjectClass() and obj.__class__ == object:
            return None

        if not hasattr(obj,'__module__'):
            # probably __builtin__, but don't just assume it is ...
            
            # weird ... __builtins__ is getting screwed up, so do it like this ...
            if not hasattr(sys.modules['__builtin__'],obj.__class__.__name__):
                raise XMLPicklingError("Cannot find module for object: %s" % repr(obj))
                
            return '__builtin__.%s' % obj.__class__.__name__
        else:
            return "%s.%s" % (obj.__module__,obj.__class__.__name__)	

def try_classify_atom( obj ):
    """
    Is obj an Atom, either a base or subclass, with or without attributes?
    If so, classify it for xml.pickling.

    Returns:
       (is_atom, type, classtag, coredata, attrs)

    Where:
       is_atom = obj is an Atom/CompoundAtom (with or without attrs)
                 If is_atom is 0, the other values are irrelevant.
       type = Text for the xml.pickle 'type=' tag.
       classtag = 'module.class' tag, or None if it isn't needed for unpickling
                  (e.g. for baseclasses and 'unique' types)
       coredata = The 'core' data for the Atom, or None if no coredata.
       attrs = obj attributes as a dict, or {} if no attributes.

    Note:
       The attrs check is best done here, instead of by the caller, since
       there are tricky cases that will fool get_pickleable_attrs, but all the
       necessary info is here.
    """
    #print "CLASSIFY ",obj,getattr(obj,'__class__',None)
    
    # for these, the type *is* the value, so handle these separately
    # Check these first so they won't be grabbed below.
    # (No bool subclasses are possible - see test_assumptions.py:002)
    if pyconfig.Have_TrueFalse():
        if obj is True:		
            return (1, 'True', None, None, {})

        if obj is False:
            return (1, 'False', None, None, {}) 

    # do a type() check first for baseclasses (also needed
    # for older Pythons where builtins aren't real classes)
    vtype,getcore = base_atoms.get(type(obj),(None,None))
    if vtype != None:
        coredata = getcore(obj)
        
        # have to generate classtag for 'class' and 'function'.
        # other base atoms won't have classtags
        if vtype == 'class':
            classtag = get_classtag(obj)
            return (1, vtype, classtag, coredata, {})
        elif vtype == 'function':
            #classtag = '%s.%s' % get_function_info(obj)
            classtag = get_classtag(obj)
            if classtag.find('<lambda>') >= 0:
                # cannot reliably get source code for lambdas ...
                raise XMLPicklingError("Cannot pickle lambda functions (%s)" % repr(obj))

            return (1, vtype, classtag, coredata, {})
        else:	
            # old-style types can't be compound, and are always 'baseclasses'
            return (1, vtype, None, coredata, {})
    
    # check vs. subclassable atoms
    # if not an object here, its not an atom	
    if pyconfig.Have_ObjectClass() and isinstance(obj, object): 
        for klass, vtype, getcore in subclassable_atoms:
            try:			
                if isinstance(obj, klass):
                    # already checked baseclasses, so it has to
                    # be a subclass at this point
                    return (1, vtype, get_classtag(obj), getcore(obj),
                            get_pickleable_attrs(obj))
            except XMLPicklingError:
                # Some things pretend to be subclasses of builtins even though 
                # they don't behave like them (for purposes of pickling) so get_classtag(), 
                # etc. will fail above. Keep going and they will get caught elsewhere (even if 
                # it's as a rawpickle)
                pass
                
            #oclass = getattr(obj,'__class__',None)
            #if oclass != None:
            #	if oclass == klass:
            #		# no classtag for baseclasses
            #		coredata = getcore(obj)
            #		return (1, vtype, None, coredata, get_attributes(obj))
            #	elif isinstance(obj,klass):
            #		# need classtag on subclasses
            #		coredata = getcore(obj)				
            #		return (1, vtype, get_classtag(obj), coredata, get_attributes(obj))

    # not Atom/CompoundAtom (set all to None so caller will
    # crash if they forget to check is_atom)
    return (0,None,None,None,None)
        
def try_classify_container( obj ):
    """
    Is obj a Container, either base or subclass, with or without attributes?
    If so, classify it for xml.pickling.

    Returns:
       (is_container, type, classtag, coredata, attrs)

    Where:
       is_container = obj is an Container/CompoundContainer (with or without attrs)
                      If is_container is 0, the other values are irrelevant.
       type = Text for the type= xml.pickle tags.
       classtag = 'module.class' tag, or None if it isn't needed for unpickling
                  (e.g. for baseclasses and 'unique' types)	   
       coredata = The 'core' data for the Container (i.e. the items it contains).
                  Will be either a list, tuple, or dict.
       attrs = obj attributes as a dict, or {} if no attributes.
    """

    # check vs. non-subclassable types
    vtype,getcore = base_containers.get(type(obj),(None,None))
    if vtype != None:
        coredata = getcore(obj)
        # old-style types can't be compound; don't need classtag			
        return (1, vtype, None, coredata, {}) 
    
    # check vs. subclassable containers
    for klass, vtype, getcore in subclassable_containers:
        if hasattr(obj,'__class__'):
            if obj.__class__ == klass:
                coredata = getcore(obj)
                # exact type doesn't need classtag
                return (1, vtype, None, coredata, get_pickleable_attrs(obj))
            elif isinstance(obj,klass):
                coredata = getcore(obj)				
                # need classtag on subclasses
                return (1, vtype, get_classtag(obj), coredata,
                        get_pickleable_attrs(obj))

    # not a container
    return (0,None,None,None,None)

# tuples below are:
#	  (class, xml.pickle type=, get_coredata_method)
#
# note the get_coredata_method must return the string
# representation of the coredata, ready for parsing by compose()
# 

def int_getcore( obj ):
    return "%d" % int(obj)

def long_getcore( obj ):
    return "%ldL" % long(obj)

def float_getcore( obj ):
    # A double has roughly 15.95 decimal digits of precision, so 16 digits are saved
    # here. See i.e. http://babbage.cs.qc.edu/courses/cs341/IEEE-754references.html.
    #
    # '"%.17g" % float(obj)' is almost right, but leaves you open to variations in
    # C libraries across platforms (win32 & linux given different results, for example).
    # fpformat is pure Python so will be consistent. Of course, hardware differences
    # between platforms can still cause variation, but that is better handled at the
    # application level where the user can write an Extension to do the rounding the
    # way they want it. I believe this is a good default, even if slower than the 
    # "'%.17g' % value" method
    
    #s = "%.17g" % float(obj)
    s = fpformat.sci(float(obj), 16) # not 17!
    
    # ensure a '.', adding if needed (unless in scientific notation)
    # so that the parser will recognize it as a float
    if '.' not in s and 'e' not in s:
        s = s + '.'

    return s

def complex_getcore( obj ):
    # these are always parsed as floats, so there is no need to
    # ensure if there is a '.' or not, unlike the float case above
    #
    # See above for why fpformat is used here.
    #return "%.17g:%.17g" % (obj.real,obj.imag)
    return "%s:%s" % (fpformat.sci(obj.real,16), fpformat.sci(obj.imag,16))

def str_getcore( obj ):
    return str(obj)

def unicode_getcore( obj ):
    return unicode(obj)

def no_coredata( obj ):
    return None

# new-style types, where these are classes
# tuples below are:
#	 (class, type=, get_coredata)
#
# This *EXCLUDES* booleans - see special checks above.
#
subclassable_atoms = []

if pyconfig.Have_ObjectClass():
    subclassable_atoms += [(int,'numeric',int_getcore),
                           (long,'numeric',long_getcore),
                           (float,'numeric',float_getcore),
                           (complex,'numeric',complex_getcore),
                           (str,'string',str_getcore),
                           (unicode,'string',unicode_getcore)]

#
# entries below are:
#	   type(): (type=, get_coredata)
#
# This *EXCLUDES* booleans - see special checks above.
#
base_atoms = {
    # these types can be subclassed, in recent Pythons,
    # but it saves time to do a type() check for the
    # baseclasses first. (Also, the type() check is
    # needed for older Pythons where these are real classes.)
    IntType: ('numeric',int_getcore),
    LongType: ('numeric',long_getcore),
    FloatType: ('numeric',float_getcore),
    ComplexType: ('numeric',complex_getcore),
    StringType: ('string',str_getcore),
    UnicodeType: ('string',unicode_getcore),

    # - the following are non-subclassable, so there is no
    # - matching entry in the table above

    # ClassType matches newstyle classes
    ClassType: ('class',no_coredata),	
    # TypeType matches builtin classes & oldstyle classes
    TypeType: ('class',no_coredata),
    # For functions
    FunctionType: ('function',no_coredata),
    # For builtin functions
    BuiltinFunctionType: ('function',no_coredata),
    NoneType: ('None',no_coredata)	
    }

# these 'getcore' functions return objects, since
# they are compound, and not simple value=

def list_getcore(obj):
    if pyconfig.Have_ObjectClass(): 
        return list(obj)
    else:
        return obj[:]
    
def tuple_getcore(obj):
    if pyconfig.Have_ObjectClass(): 
        return list(obj)
    else:
        return obj[:]
    
def dict_getcore(obj):
    if pyconfig.Have_ObjectClass():
        return dict(obj)
    else:
        return obj.copy()

# new-style types, where these are classes
# tuples are: (class, type=, get_coredata_method)
subclassable_containers = []

if pyconfig.Have_ObjectClass():
    subclassable_containers += [   
        (list,'list',list_getcore),
        (tuple,'tuple',tuple_getcore),
        (dict,'dict',dict_getcore)]

if pyconfig.Have_BuiltinSet():
    subclassable_containers += [
        (set,'set',list_getcore),
        (frozenset,'frozenset',list_getcore)
        ]

# old-style types (where these weren't real classes)

base_containers = {
    # like above with base_atoms, it is faster to do
    # a quick type() check to rule out basetypes.
    # also, this is needed for older Pythons.
    ListType: ('list',list_getcore),
    TupleType: ('tuple',tuple_getcore),
    DictType: ('dict',dict_getcore)
    }

# for convenience/speed
all_subclassable_classes_map = {}
for k,a,b in subclassable_atoms+subclassable_containers:
    all_subclassable_classes_map[k] = 1
    
