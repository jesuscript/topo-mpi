"""
A plugin to handle os.stat() values.

Just import this module to enable it.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle.extensions import StackableExtension, register_extension

try:
    from os import stat_result
    HAVE_STAT_RESULT = 1
except ImportError:
    HAVE_STAT_RESULT = 0

class osStatPlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'os.stat')
        
    def pickle(self, obj):
        if type(obj) != stat_result:
            return self.ignore(obj) 
        
        t,args = obj.__reduce__() # this is safe since I've checked type
        return (args, None, {})
    
    def unpickle(self, obj, coredata, propmap):
        "Take data from pickle() and recreate the compiled regex."
        return stat_result(*obj)

if HAVE_STAT_RESULT:
    register_extension(osStatPlugin())

