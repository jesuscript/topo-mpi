"""
Plugin supporting numpy types.

Just import this module to enable it.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import StackableExtension, register_extension
try:
    import numpy
    HAVE_NUMPY = 1
except ImportError:
    HAVE_NUMPY = 0
    
from types import *

class NumpyVersionA(StackableExtension):
    def __init__(self):
        """
        Name is 'numpy.a' so that later version can be named
        'numpy.b', etc. while keeping the previous versions
        for compatibility.
        """
        StackableExtension.__init__(self, "numpy.a")
                
    def pickle(self, obj):
        bltins = (BooleanType, ComplexType, FloatType, \
                        IntType, LongType, StringType, UnicodeType)

        # numpy.Scalars include Python builtins like int,float,etc.,
        # so need to filter those out
        if type(obj) in bltins:
            return self.ignore(obj)
            
        if type(obj) == numpy.ndarray:
            # unpack verbosely for clarity
            reconstruct, A, B = obj.__reduce__()
            if reconstruct != numpy.core.multiarray._reconstruct:
                raise Exception("Bad __reduce__ info")
                
            atype,ignore1,ignore2 = A
            # sanity
            if atype != numpy.ndarray:
                raise Exception("ERROR")
                
            pickle_ver,shape,array_descr,fortran,data = B			
            dtypestr = array_descr.str # save dtype as string
            
            # replace dtype with string
            B = list(B)
            B[2] = dtypestr
            return (B, None, {})
            
        if type(obj) in numpy.ScalarType:
            func, (dtype,data) = obj.__reduce__()
            dtypestr = dtype.str
            return ((dtypestr,data), None, {})
            
        # not something I want
        return self.ignore(obj)
        
    def unpickle(self, obj, coredata, propmap):
        if len(obj) == 5: # array
            # make empty array
            arr = numpy.core.multiarray._reconstruct(numpy.ndarray, obj[1], numpy.dtype(obj[2]))
            # replace dtypestr with dtype
            obj[2] = numpy.dtype(obj[2])
            # fill with data
            arr.__setstate__(obj)
            return arr
            
        elif len(obj) == 2: # scalar
            dtypestr,data = obj
            v = numpy.core.multiarray.scalar(numpy.dtype(dtypestr), data)
            return v

        else:
            raise Exception("Bad data")
            
if HAVE_NUMPY:
    register_extension(NumpyVersionA())


