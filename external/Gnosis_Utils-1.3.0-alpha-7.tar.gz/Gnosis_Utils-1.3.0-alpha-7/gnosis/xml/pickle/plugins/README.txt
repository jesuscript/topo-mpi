A set of default plugins are provided for popular Python modules.
They are automatically registered when xml.pickle is imported.

For the most part these are "bare bones" implementations which
mimic the way these objects are pickled via copy_reg(). You can easily
substitute your own implementation - plugins registered later will override 
plugins registered earlier.


