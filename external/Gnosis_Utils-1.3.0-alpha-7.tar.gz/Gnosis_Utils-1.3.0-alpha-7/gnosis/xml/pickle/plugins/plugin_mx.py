"""
Plugins supporting various mx.* types.

This is a bare-bones implementation that simply mimics what mx does
via copy_reg(). These can always be overridden if you want to provide 
nicely formatted versions instead.

Just import this module to enable it.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

try:
    from mx.URL import URLType, RawURL
    from mx.DateTime import DateTimeType, DateTimeFromAbsDateTime, \
            DateTimeDeltaType, DateTimeDeltaFromSeconds
    from mx.TextTools import CharSet, CharSetType, TagTable, TagTableType, \
            TextSearch, TextSearchType
    HAVE_MX = 1
except ImportError:
    HAVE_MX = 0

from gnosis.xml.pickle.extensions import StackableExtension, register_extension

# these mimic what mx does for pickling/unpickling through copy_reg()

class mxTextSearchPlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'mx.TextSearch')

    def pickle(self, obj):
        if type(obj) != TextSearchType:
            return self.ignore(obj)
            
        return ((obj.match, obj.translate, obj.algorithm), None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return TextSearch(*obj)

class mxCharSetPlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'mx.CharSet')

    def pickle(self, obj):
        if type(obj) != CharSetType:
            return self.ignore(obj)
            
        return (obj.definition, None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return CharSet(obj)

class mxTagTablePlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'mx.TagTable')

    def pickle(self, obj):
        if type(obj) != TagTableType:
            return self.ignore(obj)
            
        return (obj.compiled(), None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return TagTable(obj)

class mxDateTimePlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'mx.DateTime')

    def pickle(self, obj):
        if type(obj) != DateTimeType:
            return self.ignore(obj)
            
        return ((obj.absdate, obj.abstime), None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return DateTimeFromAbsDateTime(*obj)
        
class mxDateTimeDeltaPlugin(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'mx.DateTimeDelta')

    def pickle(self, obj):
        if type(obj) != DateTimeDeltaType:
            return self.ignore(obj)
            
        return (obj.seconds, None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return DateTimeDeltaFromSeconds(obj)

class mxURLPlugin(StackableExtension):
    "Turn a compiled regex into type='string'"
    def __init__(self):
        StackableExtension.__init__(self, 'mx.URL')

    def pickle(self, obj):
        if type(obj) != URLType:
            return self.ignore(obj)
            
        return (obj.string, None, {})
        
    def unpickle(self, obj, coredata, propmap):
        return RawURL(obj)
        
if HAVE_MX:
    register_extension(mxURLPlugin())
    register_extension(mxDateTimePlugin())
    register_extension(mxDateTimeDeltaPlugin())
    register_extension(mxCharSetPlugin())
    register_extension(mxTagTablePlugin())
    register_extension(mxTextSearchPlugin())
