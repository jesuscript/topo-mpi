"""
A plugin to handle SREs (compiled regular expressions)

Just import this module to enable it.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle.extensions import StackableExtension, register_extension

import re
re_type = type(re.compile('aaa'))

class RegexPlugin(StackableExtension):
    "Turn a compiled regex into type='string'"
    def __init__(self):
        StackableExtension.__init__(self, 'sre')
        
    def pickle(self, obj):
        "Turn a compiled regex into a string"
        if type(obj) != re_type:
            return self.ignore(obj) # not a regex, ignore
        
        return ((obj.pattern, obj.flags), None, {})
    
    def unpickle(self, obj, coredata, propmap):
        "Take data from pickle() and recreate the compiled regex."
        return re.compile(*obj)

register_extension(RegexPlugin())

