"""
Convenience module to register all extensions.

This is automatically imported when xml.pickle is imported.
"""

import plugin_sre
import plugin_mx
import plugin_numpy
import plugin_os

