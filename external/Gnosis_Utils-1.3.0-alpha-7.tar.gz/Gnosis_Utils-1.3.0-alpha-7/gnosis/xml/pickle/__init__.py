"""
gnosis.xml.pickle - Pickling of objects to/from XML.

The user API is implemented in gnosis.xml.pickle.api, but
is exported here for ease of use (so you can say 'import gnosis.xml.pickle.dumps'
instead of 'import gnosis.xml.pickle.api.dumps'). Refer to gnosis.xml.pickle.api
for full documentation.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

# convenience at lower levels
NO_DEPRECATION_MSGS = 0 # allow users to turn off deprecation warnings
try:
    import warnings 
    def deprecation(msg):
        if not NO_DEPRECATION_MSGS:
            # from the warnings documentation example
            warnings.warn(msg, DeprecationWarning, stacklevel=2)
except:
    # warnings.warn will only report each msg once, whereas
    # this will dump it every time. doesn't seem worth fixing.
    def deprecation(msg):
        if not NO_DEPRECATION_MSGS:
            print "DeprecationWarning: %s" % msg


#---------------------------------------------------------------------
# This is the public API - import here to make it available at 
# the top level of the package.
#---------------------------------------------------------------------
from gnosis.xml.pickle.api import XMLPicklingError, XMLUnpicklingError, \
     XMLPickleOtherError, \
     FL_DO_IMPORT, FL_SYSMODULE, FL_STACK, FL_STORE, \
     SEARCH_ALL, SEARCH_NO_IMPORT, SEARCH_STORE, SEARCH_NONE, \
     PARANOIA_M1, PARANOIA_0, PARANOIA_1, PARANOIA_2, XMLPickleStats, \
     XMLPickleOptions

from gnosis.xml.pickle.api import loads_stats, load_stats, dumps_stats, dump_stats, \
     load, loads, dump, dumps, XML_Pickler

from gnosis.xml.pickle.extensions import StackableExtension, ClassExtension, LoadOnlyExtension, \
    register_extension, unregister_extension, NO_EXTENSIONS
    
from gnosis.xml.pickle.getclass import add_class_to_store, remove_class_from_store

from gnosis.xml.pickle.replicants import is_replicant, replicant_info

# **DEPRECATED FUNCTIONS**
from gnosis.xml.pickle.flags import setParanoia, getParanoia

# **REMOVED FUNCTIONS**
def setDeepCopy(val):
    raise DeprecationWarning("setDeepCopy() removed; use flags to dump/dumps instead. If you really want the old API, 'import gnosis.xml.pickle.prev.ver_11 as xml_pickle'")

def getDeepCopy():
    raise DeprecationWarning("getDeepCopy() removed; use flags to dump/dumps instead. If you really want the old API, 'import gnosis.xml.pickle.prev.ver_11 as xml_pickle'")	

def setVerbose(v):
    raise DeprecationWarning("setVerbose() removed; use flags to dump/dumps instead. If you really want the old API, 'import gnosis.xml.pickle.prev.ver_11 as xml_pickle'")

def enumParsers():
    raise DeprecationWarning("enumParsers() removed; parser auto-detected. If you really want the old API, 'import gnosis.xml.pickle.prev.ver_11 as xml_pickle'")

# look for stale files from 1.2.x (lots of files were moved around in 1.3.x - leaving
# them in place might be confusing for someone browsing the installed dir)
import sys, os
# get my installed path
self_mod = sys.modules[__name__]
mydir = self_mod.__path__[0]

for name in ['ext','parsers','util','_pickle.py','_pickle.pyc']:	
    if os.path.exists(os.path.join(mydir,name)):
        deprecation("You should uninstall Gnosis_Utils <= 1.2.x before installing 1.3.x.")

# register default plugins
import gnosis.xml.pickle.plugins.all


