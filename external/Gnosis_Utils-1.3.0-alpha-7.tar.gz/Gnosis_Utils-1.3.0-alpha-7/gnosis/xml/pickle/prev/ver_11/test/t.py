
import gnosis.xml.pickle as xml_pickle

class Foo:
    def __init__(self):
        self.a = 1

#xml_pickle.setParser('SAX')

x = xml_pickle.dumps(Foo())
print x

d = {}
print "ID D ",id(d)
o = xml_pickle.loads(x,config=d)
print "OPTS ",d
print id(d)
print d['madeReplicants']

print o
print type(o)
print o.__doc__

print "ISOBJ ",isinstance(o,object)

print o.a
print o.b
