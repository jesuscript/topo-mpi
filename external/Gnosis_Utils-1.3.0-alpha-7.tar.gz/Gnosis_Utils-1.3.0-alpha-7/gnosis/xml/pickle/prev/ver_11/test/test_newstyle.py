
import gnosis.xml.pickle.gn01 as xml_pickle
from gnosis.util.introspect import isNewStyleInstance, isInstanceLike, hasCoreData

class LLL(list):
    pass

print "HCD ",hasCoreData(LLL([]))

class Foo(object):
    pass

print type(Foo())

f = Foo()

print isNewStyleInstance(f)
print isInstanceLike(f)

print f.__dict__
s = xml_pickle.dumps([])
print s
