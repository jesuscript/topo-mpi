import gnosis.xml.pickle as xml_pickle

# at -1, xml_pickle imports 'module' itself
xml_pickle.setParanoia(-1)

c = xml_pickle.loads(open('c.xml','r').read())
print c
c.call()

