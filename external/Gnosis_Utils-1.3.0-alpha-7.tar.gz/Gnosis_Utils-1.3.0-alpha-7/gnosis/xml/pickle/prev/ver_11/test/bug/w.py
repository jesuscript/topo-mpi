
import pickle

from m import Foo

f = Foo()

open('m.p','w').write(pickle.dumps(f))
