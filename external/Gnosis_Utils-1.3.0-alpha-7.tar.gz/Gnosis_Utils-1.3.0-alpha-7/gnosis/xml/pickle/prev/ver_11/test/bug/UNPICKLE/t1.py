
import pickle

c = pickle.loads(open('c.pck','r').read())
print c
c.call()
