# common pieces were moved to toplevel
from gnosis.xml.pickle.getclass import *

import gnosis.xml.pickle.prev.ver_11
from types import *

#XMLPicklingError = "gnosis.xml.pickle.XMLPicklingError"
#XMLUnpicklingError = "gnosis.xml.pickle.XMLUnpicklingError"

class _EmptyClass: pass

# get my modulename (on-the-fly classes live here)
dynamic_module = _EmptyClass().__class__.__module__

# -- functions for dynamic object creation --

from gnosis.util.introspect import instance_noinit

# adapted from pickle.py, whichmodule()
def get_function_info( func ):

    fname = func.__name__

    for name, module in sys.modules.items():
        if name != '__main__' and \
            hasattr(module, fname) and \
            getattr(module, fname) is func:
            break
    else:
        name = '__main__'

    return (name,func.__name__)

def obj_from_classtype(klass):
    """Create an object of ClassType klass. We aren't
    allowed (by the pickle protocol) to call __init__() on
    the new object, so we have to be careful."""
    import gnosis.xml.pickle.replicants as replicants
    
    obj = instance_noinit(klass)
    
    if replicants.is_replicant(klass):
        typestr,mod,name = replicants.replicant_info(klass)
        
        obj.__doc__ = """This object was created from a replicant class that xml.pickle invented when it failed to load the class '%s' from module '%s' (as type='%s'). This was probably due to your class_search and allow_replicant settings in xml.pickle.load(). Refer to gnosis/xml/pickle/doc/SECURITY for further information.""" % (name,mod,typestr)
        
    return obj

def obj_from_name(classname, modname=None,
                  class_search=SEARCH_NO_IMPORT,
                  allow_replicants=1):
    """Given a classname, optional module name, return an object
    of type module.classname, subject to class_search & allow_replicants rules.
    Does NOT call __init__ on the new object, since the caller
    may need to do some other preparation first."""

    dbg("OBJ FROM NAME %s.%s [%s] %d" % (str(modname),str(classname),modname is None,class_search))
    klass, is_replicant = get_class_from_name(classname,modname,class_search,allow_replicants)
    dbg("KLASS %s" % str(klass))
    return (obj_from_classtype(klass), is_replicant)

# -- get class/module names from an object --

def _klass(thing):
    return thing.__class__.__name__

def _module(thing):
    """If thing's class is located in CLASS_STORE, was created
    from "thin-air", or lives in the "xml_pickle" namespace,
    don't write the module name to the XML stream (without these
    checks, the XML is functional, but ugly -- module names like
    "gnosis.xml.pickle.util._util")
    """
    klass = thing.__class__
    if klass.__module__ == dynamic_module: return None
    if klass in CLASS_STORE.values(): return None
    if klass in gnosis.xml.pickle.prev.ver_11.__dict__.values(): return None
    return thing.__class__.__module__

def safe_eval(s):
    if 0:   # Condition for malicious string in eval() block
        raise "SecurityError", \
              "Malicious string '%s' should not be eval()'d" % s
    else:
        return eval(s)

def safe_string(s):
    if isinstance(s, UnicodeType):
        raise TypeError, "Unicode strings may not be stored in XML attributes"

    # markup XML entities
    s = s.replace('&', '&amp;')
    s = s.replace('<', '&lt;')
    s = s.replace('>', '&gt;')
    s = s.replace('"', '&quot;')
    s = s.replace("'", '&apos;')
    # for others, use Python style escapes
    s = repr(s)
    return s[1:-1]  # without the extra single-quotes

def unsafe_string(s):
    # for Python escapes, exec the string
    # (niggle w/ literalizing apostrophe)
    s = s.replace("'", r"\047")
    exec "s='"+s+"'"
    # XML entities (DOM does it for us)
    return s

def safe_content(s):
    "Markup XML entities and strings so they're XML & unicode-safe"
    s = s.replace('&', '&amp;')
    s = s.replace('<', '&lt;')
    s = s.replace('>', '&gt;')

    # wrap "regular" python strings as unicode
    if isinstance(s, StringType):
        s = u"\xbb\xbb%s\xab\xab" % s

    return s.encode('utf-8')

def unsafe_content(s):
    """Take the string returned by safe_content() and recreate the
    original string."""
    # don't have to "unescape" XML entities (parser does it for us)

    # unwrap python strings from unicode wrapper
    if s[:2]==unichr(187)*2 and s[-2:]==unichr(171)*2:
        s = s[2:-2].encode('us-ascii')

    return s

def subnodes(node):
    # for PyXML < 0.8, childNodes are all <DOM Elements>, so we
    # just remove the #text nodes.
    # for PyXML > 0.8, childNodes includes both <DOM Elements> and
    # DocumentType objects, so we have to separate them.
    return filter(lambda n: hasattr(n,'_attrs') and \
                  n.nodeName<>'#text', node.childNodes)

