"""
To preserve perfect backward-compatiblity, the xml.pickle 1.1 pickler
and unpickler were moved here ('prev/ver_11') in their entirety.
This is primarly intended for backward compatibility with 1.1 data.
You don't have to do anything to read 1.1 data - the toplevel parser
will call these routines as needed.

If you want to explicitly use the 1.1 suite, you can do it with:

   import gnosis.xml.pickle.prev.ver_11 as xml_pickle

-------------------
Store Python objects to (pickle-like) XML Documents

Please see the information at gnosis.xml.pickle.prev.ver_11.doc for
explanation of usage, design, license, and other details
"""

# pull in common exceptions, defs, etc. from toplevel
from gnosis.xml.pickle import *

# now my ver_11-specific stuff
from gnosis.xml.pickle.prev.ver_11.ext import *

from gnosis.xml.pickle.prev.ver_11._pickle import \
     XML_Pickler, \
     dump, dumps, load, loads

from gnosis.xml.pickle.prev.ver_11.util import \
     setParanoia, getParanoia, setDeepCopy, getDeepCopy,\
     get_class_from_store, add_class_to_store, remove_class_from_store,\
     setParser, setVerbose, enumParsers

