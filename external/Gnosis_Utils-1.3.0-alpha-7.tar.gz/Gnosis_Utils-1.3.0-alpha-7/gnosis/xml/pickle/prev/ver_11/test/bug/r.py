
import pickle

o = pickle.loads(open('m.p','r').read())
print o
o.hi()
