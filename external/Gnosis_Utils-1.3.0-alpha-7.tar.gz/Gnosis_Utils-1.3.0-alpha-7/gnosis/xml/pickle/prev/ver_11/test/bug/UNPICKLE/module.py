
__all__ = ["C"]

class C(object):
    def call(self):
        print "C.call(self)"
