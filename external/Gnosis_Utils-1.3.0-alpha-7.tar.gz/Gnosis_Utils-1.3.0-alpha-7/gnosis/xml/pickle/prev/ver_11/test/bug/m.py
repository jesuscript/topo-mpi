
class Foo:
    def __init__(self):
        self.a = 123

    def hi(self):
        print "Hello Foo"
        
