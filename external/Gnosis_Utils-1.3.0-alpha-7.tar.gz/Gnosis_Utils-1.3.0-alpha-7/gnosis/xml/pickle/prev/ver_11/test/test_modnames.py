"Demonstrate that on-the-fly and gnosis.xml.* namespaces not saved in XML file --fpm"

import gnosis.xml.pickle.prev.ver_11 as xml_pickle
from gnosis.xml.pickle import is_replicant
from UserList import UserList
import funcs
import re
import gnosis.xml.pickle

funcs.set_parser()

# handcoded object to load Foo (i.e. without the pickler having
# seen it before)
ud_xml = """<?xml version="1.0"?>
<!DOCTYPE PyObject SYSTEM "PyObjects.dtd">
<PyObject module="__main__" class="Foo">
</PyObject>
"""

class myfoo: pass
class Foo: pass

# print "On-the-fly -- SHOULD *NOT* SEE MODULE NAME IN XML"
p = xml_pickle.loads(ud_xml)
# print it so we can see the modname
#print "Fullname = "+str(p)
#if p.__class__.__module__ != 'gnosis.xml.pickle.prev.ver_11.util._util' or \
#	   p.__class__.__name__ != 'Foo':
#	print p.__class__.__name__
if not is_replicant(p):
    raise "ERROR(1)"


# dump and make sure modname doesn't stick
s = xml_pickle.dumps(p)
#print s
if re.search(s,'module'):
    raise "ERROR(2)"

#print "From (old) xml_pickle namespace -- SHOULD *NOT* SEE MODULE NAME IN XML"
# put Foo into xml_pickle namespace
#xml_pickle.Foo = myfoo
# careful - use current-version namespace!
gnosis.xml.pickle.Foo = myfoo
p = xml_pickle.loads(ud_xml)
# print it so we can see the modname
#print "Fullname = "+str(p)
if p.__class__.__module__ != '__main__' or \
       p.__class__.__name__ != 'myfoo':
    print ud_xml
    raise "ERROR(3)"

# dump it and make sure modname doesn't stick
s = xml_pickle.dumps(p)
#print s
if re.search(s,'module'):
    raise "ERROR(4)"

# delete so it won't be found again below
#del xml_pickle.Foo
del gnosis.xml.pickle.Foo

# explicitly add to class store
xml_pickle.add_class_to_store('Foo',myfoo)

#print "From class store -- SHOULD *NOT* SEE MODULE NAME IN XML"
p = xml_pickle.loads(ud_xml)
# print it so we can see the modname
#print "Fullname = "+str(p)
if p.__class__.__module__ != '__main__' or \
       p.__class__.__name__ != 'myfoo':
    raise "ERROR(5)"

# dump & make sure modname doesn't stick
s = xml_pickle.dumps(p)
#print s
if re.search('module',s):
    raise "ERROR(6)"

# remove so it won't be found again below
xml_pickle.remove_class_from_store('Foo')

# now, make sure we haven't broken modnames showing up when they SHOULD :-)
#print "My namespace (__main__) -- SHOULD SEE MODULE NAME IN XML"
# allow it to load my Foo
xml_pickle.setParanoia(0)
p = xml_pickle.loads(ud_xml)
# print it so we can see the modname
#print "Fullname = "+str(p)
if p.__class__.__module__ != '__main__' or \
       p.__class__.__name__ != 'Foo':
    raise "ERROR(7)"

# dump & make sure module name is written
s = xml_pickle.dumps(p)
#print s
if not re.search('PyObject\s+(version=\"[0-9\.]+\"\s+)?module="__main__"\s+class="Foo"',s):
    raise "ERROR(8)"

print "** OK **"


