
import doctest

from test.test_support import forget
import sys

_template =\
""" 
>>> forget('module')
>>> assert 'module' not in sys.modules
    
>>> from %(pickle)s import *
>>> %(additional)s

>>> c = load(open("c.%(ext)s"))
>>> type(c)
<class 'module.C'>
>>> c.x
1
>>> c.call()
C.call(self)
"""

class Session1:
    """Standard pickle package.
    """ 
    
    _variables = dict()
    _variables["ext"]        = "pck"
    _variables["pickle"]     = "pickle"
    _variables["additional"] = "# pickle security model"
    
    __doc__ += _template % _variables

class Session2:
    """XML pickle package (gnosis), paranoia level: 0.
    """
 
    _variables = dict()
    _variables["ext"]        = "xml"
    _variables["pickle"]     = "gnosis.xml.pickle"
    _variables["additional"] = "setParanoia(0)"   
       
    __doc__ += _template % _variables

class Session3:
    """XML pickle package (gnosis), paranoia level: -1.
    """
 
    _variables = dict()
    _variables["ext"]        = "xml"
    _variables["pickle"]     = "gnosis.xml.pickle"
    _variables["additional"] = "setParanoia(-1)"   
       
    __doc__ += _template % _variables
                
def run():
    """
    Run the test suite.
    """
    import pickle
    import gnosis.xml.pickle
   
    from module import C
    c = C()
    c.x = 1
   
    pickle.dump(c, open("c.pck", "w"))
    gnosis.xml.pickle.dump(c, open("c.xml", "w"))
   
    del c
    del C
   
    doctest.testmod()

if __name__ == "__main__":
    run()
