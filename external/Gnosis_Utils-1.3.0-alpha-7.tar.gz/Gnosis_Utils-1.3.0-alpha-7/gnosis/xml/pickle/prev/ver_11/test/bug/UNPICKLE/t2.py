import gnosis.xml.pickle as xml_pickle

# paranoia=0 requires the caller to have imported 'module'

import module

xml_pickle.setParanoia(0)
c = xml_pickle.loads(open('c.xml','r').read())
print c
c.call()
