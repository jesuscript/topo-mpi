"""
This directory is meant as a place for deprecated
versions to be placed, as a means of maintaining
backward compatibility.

ver_11/ = xml.pickle version 1.2.0
"""
