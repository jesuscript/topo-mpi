"""
An example of building a pipeline of modular StackableExtensions.

Here we have three classes: GenericText, AuthoredText, and Article.
Although xml.pickle would have no problem pickling each of these objects
as-is, we'd like to customize the XML a bit. If you pickled each object as-is,
you'd end up with three XML 'objects' that look nothing alike. Since
they are clearly similar, it'd be nice to have their XML representations
look similar to each other.

By defining the StackableExtensions below, we can cause each of the three
types to be pickled as:

    <attr name='..' type='string'>
        [                               ]
        [ A block containing the text.  ]
        [                               ]

        [Other tags added, depending on type.]
    </attr>

Now it's in a more 'human-readable' form - regardless of which object
type is pickled, the block of text always sits at the top.
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, \
     unregister_extension

#-----------------------------------------------------------------------
# The three classes of text
#-----------------------------------------------------------------------
class GenericText:
    "A generic piece of text."
    def __init__(self, text):
        self.text = text

class AuthoredText:
    "Text with an author and title."
    def __init__(self, title, author, text):
        self.title = title
        self.author = author
        self.text = text

class Article:
    "Published article, with text, author, title and publication name."
    def __init__(self, title, author, publication, text):
        self.title = title
        self.author = author
        self.publication = publication
        self.text = text		

#------------------------------------------------------------------------
# The three StackableExtensions
#------------------------------------------------------------------------
class GenericTextHandler(StackableExtension):

    def __init__(self):
        # set my extension name
        StackableExtension.__init__(self, 'GenericText')
        
    def pickle(self, obj):
        "Don't need whole object, just mutate into text by itself."
        if not isinstance(obj,GenericText):
            return self.ignore(obj)
        
        return (obj.text, None, {})

    def unpickle(self, obj, coredata, propmap):
        "Recreate GenericText from text returned above."
        return GenericText(obj)

class AuthoredTextHandler(StackableExtension):

    def __init__(self):
        # set my extension name
        StackableExtension.__init__(self, 'AuthoredText')

    def pickle(self, obj):
        """Turn myself into a GenericText object, tacking on 'author'
        and 'title' as properties (this is superior to simply
        adding an .author and .title to a GenericText instance,
        because properties live in a separate namespace, and will
        never conflict with object attribute names)."""
        if not isinstance(obj,AuthoredText):
            return self.ignore(obj)
        
        return (GenericText(obj.text), None,
                {'author':obj.author, 'title':obj.title})

    def unpickle(self, obj, coredata, propmap):
        """Take the GenericText obj I returned above, plus my propmap
        and recreate the AuthoredText."""
        return AuthoredText(propmap['title'], propmap['author'], obj.text)
    
class ArticleHandler(StackableExtension):

    def __init__(self):
        # set my extension name
        StackableExtension.__init__(self, 'Article')

    def pickle(self, obj):
        """Like above, don't reinvent the wheel, just build on top
        of AuthoredText, tacking on my 'publication' property."""
        if not isinstance(obj, Article):
            return self.ignore(obj)
        
        return (AuthoredText(obj.title, obj.author, obj.text),
                None, {'publication':obj.publication})

    def unpickle(self, obj, coredata, propmap):
        """Take the AuthoredText obj I returned above, plus my property
        list, and recreate the Article."""
        return Article(obj.title, obj.author, propmap['publication'], obj.text)

# register my handlers. extensions registered *later* are called *earlier*,
# so do it in the correct order to build the pipeline
register_extension(GenericTextHandler())
register_extension(AuthoredTextHandler())
register_extension(ArticleHandler())

text_g1 = """
Here is some text to go in a GenericText
object. Blah blah, isn't this swell.

I added newlines at the start/end just to make the edges
line up, and make this look like a nicer standalone block in
the XML file. They aren't needed for any technical reason.
"""

text_a1 = """
Here is some text to go in an AuthoredText
holder. Wheeeee!!!!!!!!

I added newlines at the start/end just to make the edges
line up, and make this look like a nicer standalone block in
the XML file. They aren't needed for any technical reason.
"""

text_a2 = """
Here is some text to go inside an Article
container. Yipee doo dandy.

I added newlines at the start/end just to make the edges
line up, and make this look like a nicer standalone block in
the XML file. They aren't needed for any technical reason.
"""

print "\n***** GenericText *****\n"

o = GenericText(text_g1)
# 'deepcopy' is just for aesthetics -- omits ids (since I know there are no refs here)
x = xml_pickle.dumps(o,deepcopy=1)
print x
p = xml_pickle.loads(x)
#print p, p.__dict__
if not isinstance(p,GenericText) or p.__dict__ != o.__dict__:
    raise "ERROR"

print "\n***** AuthoredText *****\n"

o = AuthoredText('On the blahness of blah', 'S. Cruz', text_a1)
# 'deepcopy' is just for aesthetics -- omits ids (no refs here)
x = xml_pickle.dumps(o,deepcopy=1)
print x
p = xml_pickle.loads(x)
#print p, p.__dict__
if not isinstance(p,AuthoredText) or p.__dict__ != o.__dict__:
    raise "ERROR"

print "\n***** Article *****\n"

o = Article('All About Blah', 'Mr. No One', 'Journal of Blandness', text_a2)
# 'deepcopy' is just for aesthetics -- omits ids (no refs here)
x = xml_pickle.dumps(o,deepcopy=1)
print x
p = xml_pickle.loads(x)
#print p, p.__dict__
if not isinstance(p,Article) or p.__dict__ != o.__dict__:
    raise "ERROR"

print "** OK **"
