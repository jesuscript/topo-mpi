#
# Test decompose/compose loop for each object type.
#

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import t_atoms, t_containers
from gnosis.xml.pickle.objmodel import demo_compose, decompose, get_data_attrs
from gnosis.xml.pickle import SEARCH_NO_IMPORT

def testobj( obj ):
    "Assumes obj is Atom/Container"
    
    print "*TEST* ",repr(obj)
    otype,classtag,coredata,attrs = decompose( obj, 0, 0 )
    #print repr(vals)
    if otype == 'blob':
        raise "Shouldn't have to make a blob!"
    
    o = demo_compose( otype, classtag, coredata, attrs, SEARCH_NO_IMPORT, 0 )
    print o
    # careful: '!=' tests the coredata (and *ONLY* the coredata!)
    if o != obj: 
        raise Exception("Failed coredata test: %s, %s" % (repr(o),repr(obj)))

    # test the attributes also
    if get_data_attrs(o) != get_data_attrs(obj):
        raise "Attrs don't match"

#
# Take one of each Atom & Container and run them through
# a decompose/compose cycle to ensure the match.
#

for k,v in t_atoms.Atoms.items():
    # base types, no attrs
    testobj(v)

for k,v in t_atoms.SubclassAtoms_NoAttr.items():
    # subclassed, no attrs
    testobj(v)

for k,v in t_atoms.SubclassAtoms_Attr.items():
    # subclassed, with attrs
    testobj(v)		

for k,v in t_containers.Containers.items():
    # base types, no attrs
    testobj(v)

for k,v in t_containers.SubclassContainers_NoAttr.items():
    # subclassed, no attrs
    testobj(v)

for k,v in t_containers.SubclassContainers_Attr.items():
    # subclassed, with attrs
    testobj(v)		
    
print "** OK **"

