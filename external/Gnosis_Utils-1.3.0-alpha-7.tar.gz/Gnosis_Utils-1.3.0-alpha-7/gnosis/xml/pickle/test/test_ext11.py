"""
Test to ensure that all sortable items are being sorted correctly.
This includes:
    . attributes
    . dicts
    . sets/frozensets
    . propmap/metadata returned from extensions
    
If this test ever fails, print the XML to make sure it's sorted, and
update the SHA-1's below if necessary.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.extensions import StackableExtension, ClassExtension,\
                        register_extension, unregister_extension
from gnosis.xml.pickle.extras import norm_xml, object_sha
from gnosis.pyconfig import pyconfig

class Foo:

    def __init__(self):	
        # add some attributes to ensure they're sorted correctly
        self.zzz = 'hello zzz'
        self.bbb = 'hello bbb'
        self.ggg = 'hello ggg'
        self.aaa = 'hello aaa'
        
        # add a dict to make sure it is sorted correctly
        self.ddd = {'zyx': 123, 'ayz': 43.45, 'b2y': 888, 'yuwz': 374, 'cytza': 999}

        # add a set to make sure it is sorted correctly
        if pyconfig.Have_BuiltinSet():
            self.sss = set(["tyr","bhy","aok","zyy","cqj","frt"])
    
class TestClassExt(ClassExtension):
    def __init__(self):
        ClassExtension.__init__(self, 'TestClassExt')
    
    def pickle(self, obj):
        if isinstance(obj, Foo):
            return (obj,
                        # metadata that will be sorted
                        {'Squash': 89,
                         'Pickles': 111,
                         'Bananas': 44,
                         'Apples': 123,
                         'Oranges': 456
                         },
                        # property map that will be sorted
                        {'Size': 12,
                         'Zoompf': 0,
                         'Weight': 100,
                         'Girth': 8,
                         'Inseam': 123
                         })
                         
        else:
            return self.ignore(obj)
            
class TestStackableExt(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'TestStackableExt')
        
    def pickle(self, obj):
        if isinstance(obj, Foo):
            return (obj, 
                        # coredata that will be sorted
                        {'Squash': 89,
                         'Pickles': 111,
                         'Bananas': 44,
                         'Apples': 123,
                         'Oranges': 456
                         },
                        # propmap that will be sorted
                        {'Size': 12,
                         'Zoompf': 0,
                         'Weight': 100,
                         'Girth': 8,
                         'Inseam': 123
                         })
                         
        else:
            return self.ignore(obj)

if pyconfig.Have_BuiltinSet():
    known_SHA = "78d1cf7828bfa898ecef9992f767f31476fa3ae6"
else:
    known_SHA = "cd8ce4047dba3c49681efeb9cfdef0c4e271fc6e"	
f = Foo()
ext = TestClassExt()
register_extension(ext)
#xml = norm_xml(f)
#print xml
#print object_sha(f)
if known_SHA != object_sha(f):
    raise Exception("ERROR(1)")

unregister_extension(ext)

if pyconfig.Have_BuiltinSet():
    known_SHA = "51e355f72eb0326c1a46107652b04c2eb97d5b39"
else:
    known_SHA = "c158cd8ded6e2c17a179c21b05ea49fc05c75251"

ext = TestStackableExt()
register_extension(ext)
#xml = norm_xml(f)
#print xml
#print object_sha(f)
if known_SHA != object_sha(f):
    raise Exception("ERROR(2)")
    
unregister_extension(ext)
    
print "** OK **"

                         
                         

