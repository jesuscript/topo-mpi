"""
Demonstration of ClassExtensions, using all three cases of coredata
(mutatable, immutable, and none).
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.extensions import ClassExtension, register_extension, \
     unregister_extension

class Baz:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c

    def __str__(self):
        return "Baz: a=%s, b=%s, c=%s" % (repr(self.a),repr(self.b),repr(self.c))
        
class BazToImmutable(ClassExtension):
    """
    Mutate Baz to a type with an immutable core.
    """
    def __init__(self):
        ClassExtension.__init__(self, "Bazzer.Immutable")
        
    def pickle(self, obj):
        """
        Mutate to a tuple holding (.a,.b,.c), and attach some
        properties also, for demo purposes.
        """
        if not isinstance(obj,Baz):
            return self.ignore(obj)
        
        return ((obj.a,obj.b,obj.c), {}, {'aaa':123,'bbb':456,'ccc':78.9})

    def unpickle_begin_core(self, typestr, metadata, coredata, *unused):
        # coredata is the coredata from the tuple returned above
        return Baz(coredata[0],coredata[1],coredata[2])

    def unpickle_finalize(self, obj, propmap):
        # see if propmap correct
        if propmap != {'aaa':123,'bbb':456,'ccc':78.9}:
            raise "ERROR"

class BazToNoCore(ClassExtension):
    """
    Mutate Baz to a type with NO coredata.
    """
    def __init__(self):
        ClassExtension.__init__(self, "Bazzer.NoCore")
    
    def pickle(self, obj):
        """
        Just to be wacky, lets mutate to the builtin function 'chr',
        and attach (.a,.b,.c) in the property list.
        """
        if not isinstance(obj,Baz):
            return self.ignore(obj)
        
        return (chr, {}, {'a':obj.a,'b':obj.b,'c':obj.c})

    def unpickle_begin_nocore(self, *unused):
        # a,b,c are in property list, so just make empty Baz for now
        return Baz(0,0,0)

    def unpickle_finalize(self, obj, propmap):
        # now set a,b,c from propmap
        obj.a = propmap['a']
        obj.b = propmap['b']
        obj.c = propmap['c']
        
class BazToMutable(ClassExtension):
    """
    Mutate Baz to a type with mutable coredata.
    """
    def __init__(self):
        ClassExtension.__init__(self, "Bazzer.Mutable")
        
    def pickle(self, obj):
        """
        Mutate to a list holding (.a,.b,.c) and attach some properties,
        for demo purposes.
        """
        if not isinstance(obj,Baz):
            return self.ignore(obj)
        
        return ([obj.a,obj.b,obj.c], {}, {'aaa':123,'bbb':456,'ccc':78.9})

    def unpickle_begin_nocore(self, *unused):
        # don't have coredata yet, so create empty Baz
        return Baz(0,0,0)

    def unpickle_set_coredata(self, typestr, obj, coredata):
        # coredata is from list returned in pickle()
        obj.a = coredata[0]
        obj.b = coredata[1]
        obj.c = coredata[2]

    def unpickle_finalize(self, obj, propmap):		
        # make sure propmap came back OK
        if propmap != {'aaa':123,'bbb':456,'ccc':78.9}:
            raise "ERROR"

def check_baz(o1,o2):
    for attr in ['a','b','c']:
        if getattr(o1,attr) != getattr(o2,attr):
            raise "ERROR"
        
#print "\n***** Baz -> mutable core *****\n"
ext = BazToMutable()
register_extension(ext)

o = Baz(123,u'a unicode value', ('here','is','a','tuple'))
x = xml_pickle.dumps(o,short_ids=1)
#print x

p = xml_pickle.loads(x)
check_baz(o,p)

# remove it so I can register another handler for Baz
unregister_extension(ext)

#print "\n***** Baz -> immutable core *****\n"

ext = BazToImmutable()
register_extension(ext)

o = Baz(12+34j, [u'here','is a',u'somewhat','unicode',u'stringlist'],
        {'a':111, 'b':222, 'c':333})
x = xml_pickle.dumps(o,short_ids=1)
#print x

p = xml_pickle.loads(x)
check_baz(o,p)

unregister_extension(ext)

#print "\n***** Baz -> no core *****\n"

ext = BazToNoCore()
register_extension(ext)

o = Baz(1,2,3)
x = xml_pickle.dumps(o,short_ids=1)
#print x

p = xml_pickle.loads(x)
check_baz(o,p)

unregister_extension(ext)

print "** OK **"
