"""
StackableExtension demo. One extension turns 'Foo' into 'Bar',
and a second turns 'Bar' into a list.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT
from gnosis.xml.pickle.extensions import StackableExtension, register_extension

class Foo:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c

    def __str__(self):
        return "Foo (%s,%s,%s)" % (repr(self.a),repr(self.b),repr(self.c))
    
class Bar:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c
        
class Ext_FooToBar(StackableExtension):

    def __init__(self):
        StackableExtension.__init__(self, "Foo2Bar")
        
    def pickle(self, obj):
        if isinstance(obj,Foo):
            # mutate self into a Bar, and attach some properties
            return (Bar(obj.a,obj.b,obj.c), None, {'aaa':123, 'bbb':'xyy'})
        else:
            return self.ignore(obj)

    def unpickle(self, obj, coredata, propmap):
        # make sure I got back my propmap OK
        if propmap != {'aaa':123, 'bbb':'xyy'}:
            raise "ERROR"
        
        return Foo(obj.a,obj.b,obj.c)
    
class Ext_BarToList(StackableExtension):

    def __init__(self):
        StackableExtension.__init__(self, "Bar2List")
        
    def pickle(self, obj):
        if isinstance(obj, Bar):
            # mutate my attrs into a list and attach some properties
            return ([obj.a,obj.b,obj.c], None, {'xxx':12+34j,'yyy':u'UUU'})
        else:
            return self.ignore(obj)

    def unpickle(self, obj, coredata, propmap):
        # make sure I got back my propmap OK		
        if propmap != {'xxx':12+34j,'yyy':u'UUU'}:
            raise "ERROR"
        
        return Bar(obj[0],obj[1],obj[2])

# register my handlers. extensions registered *later* are called *earlier*,
# so do it in the correct order to build the pipeline
register_extension(Ext_BarToList())
register_extension(Ext_FooToBar())

f = Foo(4,5,6)

# put Foo in a list to be pickled
o = [1,2,3,f]
x = dumps(o,short_ids=1,deepcopy=0)
#print x
p = loads(x,SEARCH_NO_IMPORT)

# check
if p[:3] != o[:3] or p[3].__dict__ != o[3].__dict__:
    raise "ERROR"

print "** OK **"




