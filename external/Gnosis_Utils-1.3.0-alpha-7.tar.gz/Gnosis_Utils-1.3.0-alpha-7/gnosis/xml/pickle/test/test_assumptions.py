"""
Various assumptions about Python features that were true at
the time that xml.pickle was written. The test #'s are
referenced at various points in the xml.pickle code, so
in case 'Python 3000' breaks any of these, they can be
traced back into the pickler.
"""

__author__ = ['Frank McIngvale <frankm@hiwaay.net>']

import pickle, sys
from gnosis.pyconfig import pyconfig

#
# 001 - objects are only pickled once when references are made
#
GC_COUNT = 0
class VolatileGetstate:
    def __init__(self):
        pass
    
    def __getstate__(self):
        global GC_COUNT
        GC_COUNT += 1
        return {'a':1,'b':2,'count':GC_COUNT}

f = VolatileGetstate()
# __getstate__ should only be called ONCE since
# references will be pickled
s = pickle.dumps([f,f,f])

if GC_COUNT != 1:
    raise Exception("ERROR")

g = pickle.loads(s)
for o in g:
    if o.count != 1:
        raise Exception("ERROR")

#
# 002 - bools cannot be subclassed
#
if pyconfig.Have_BoolClass():
    # bools should NOT be subclassable
    if pyconfig.IsLegal_BaseClass('True'):
        raise Exception("ERROR")

#
# 003 - subclassed immutable builtins must define __init__ just
# like their baseclasses (unless they have __new__ and possibly __getnewargs__)
# - see test_newargs for more on this.
#
if pyconfig.Have_ObjectClass():
    try:
        class Foo(tuple):
            def __init__(self,a,b): tuple.__init__(self,b)
            
        f = Foo('aaa',(1,2,3))
        raise Exception("ERROR")
    except TypeError,exc:
        pass

    try:
        class Foo(int):
            def __init__(self,a,b,c): int.__init__(self,c)
            
        f = Foo('aaa','aaa',11)
        raise Exception("ERROR")
    except TypeError,exc:
        pass

    try:
        class Foo(str):
            def __init__(self,a,b): str.__init__(self,b)

        f = Foo([1,2],'aaa')
        raise Exception("ERROR")
    except TypeError:
        pass

    try:
        class Foo(unicode):
            def __init__(self,a,b): unicode.__init__(self,b)

        f = Foo([1,2],u'aaa')
        raise Exception("ERROR")
    except TypeError:
        pass	

    if pyconfig.Have_BuiltinSet():
        try:
            class Foo(frozenset):
                def __init__(self,a,b): unicode.__init__(self,b)

            f = Foo('aaa',[1,2,3])
            raise Exception("ERROR")
        except TypeError, exc:
            pass

#
# 004 - types that aren't pickleable by pickle or xml.pickle
#

bad = []

# BufferType
bad.append( buffer('aaa') )

# CodeType
c = compile('a=1','dummy','exec')
bad.append(c)

# EllipsisType
bad.append(Ellipsis)

# FileType
f = open('dummy','w')
bad.append(f)

# FrameType
try:
    raise Exception('aaa')
except:
    frame = sys.exc_traceback.tb_frame

bad.append(frame)

# GeneratorType
if pyconfig.Have_GeneratorExpressions():
    g = (x for x in [1,2,3])
    bad.append( g )

# LambdaType
l = lambda(x): x+1
bad.append(l)

# MethodType ('instancemethod')
class Foo:
    def aaa(self):
        pass

f = Foo()
bad.append(f.aaa)

# ModuleType is not pickleable
#    First, this matches standard pickle behavior. 
#    Secondly, this is critical in case you have:
#       modA.modB with class Foo
#       modA.modB.Foo -- as a module
#
#    The classtag for both of these would be "modA.modB.Foo" which would be
#    ambiguous. However, since modules (or references to modules) cannot
#    be pickled, the second case can never occur.
import string
bad.append(string)

# SliceType
bad.append(slice(1,2))

# TracebackType
try:
    raise Exception('aaa')
except:
    bad.append(sys.exc_traceback)

# XRangeType
bad.append(xrange(10))

for o in bad:
    try:
        pickle.dumps(o)
        raise "ERROR - shouldn't be able to pickle %s" % repr(o) # should not have worked
    except (TypeError, pickle.PicklingError):
        pass

# make sure 'dummy' file is closed
del bad

from funcs import unlink
unlink('dummy')

print "** OK **"

    
