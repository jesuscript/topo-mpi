__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import pickle

l = [1]
t = (3,l)
l.append(t)
l.append(l)
l.append(t)

print id(t)
print id(l[1])
print id(l[3])
print id(l[1][1][1])
    
s = pickle.dumps(l)

l2 = pickle.loads(s)

print id(l2[1])
print id(l2[3])
print id(l2[1][1][1])
