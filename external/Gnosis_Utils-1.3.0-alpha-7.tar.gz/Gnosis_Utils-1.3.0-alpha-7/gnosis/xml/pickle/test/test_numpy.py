from gnosis.xml.pickle import dumps, loads
from gnosis.xml.pickle.extras import xmlequal
import sys
from random import randint, random, choice, seed
import numpy as N

# for repeatable results ...
seed(8128734)

ALPHA = 'abcdefghijklmnopqrstuvqxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
DIGIT = '0123456789'
SYM = '`~!@#$%^&*()-_=+[{]}\\|:;"\'<,>.?/'

def r_uint(): return randint(0,100000)
def r_int(): return randint(-100000,100000)
def r_float(): return random() * r_int()
def r_complex(): return complex(r_float(), r_float())
def r_strchr(): return choice(ALPHA+DIGIT+SYM)
def r_unichr(): return u''+r_strchr()
def r_bool(): return choice([0,1])

ntypelist = [
    # some of these numpy types actually map to Python types,
    # but try them all anyways to ensure they are handled correctly
    ('uint', r_uint),
    ('uint0', r_uint),
    ('uint8', r_uint),
    ('uint16', r_uint),
    ('uint32', r_uint),
    ('uint64', r_uint),
    ('int', r_int),
    ('int0', r_int),
    ('int8', r_int),
    ('int16', r_int),
    ('int32', r_int),
    ('int64', r_int),
    ('int128', r_int),
    ('float', r_float),
    ('float32', r_float),
    ('float64', r_float),
    ('float96', r_float),
    ('float128', r_float),
    ('complex64', r_complex),
    ('complex128', r_complex),
    ('complex192', r_complex),
    ('unicode', r_unichr),
    ('unicode_', r_unichr),
    ('unicode0', r_unichr),
    ('str', r_strchr),
    ('str_', r_strchr),
    ('string0', r_strchr),
    ('string_', r_strchr),
    ('bool', r_bool),
    ('bool8', r_bool),	
    ]

# Some hardcoded values for reference

# arrays
a1 = N.array([1.2,2.3,3.4,4.5,5.6,6.7],N.float32)
a2 = N.array([[1.2,2.3,3.4],[4.5,5.6,6.7]],N.float32)
a3 = N.array(['a','b','c','d'], N.unicode)
a4 = N.array([['abc','def','ghi'],['jkl','mno','pqr']], N.unicode)
a5 = N.array([['abc','def','ghi'],['jkl','mno','pqr']], N.str)
a6 = N.array('abcdef', N.str)
a7 = N.array([[1,0,0],[0,1,0],[1,1,0],[0,1,1]], N.bool)
a8 = N.array([[1,2,3],[4,5,6],[7,8,9],[10,11,12]],N.uint16)
# scalars
s1 = N.float32(1.23)
s2 = N.complex64(1.23+2.34j)
s3 = N.uint8(200)

ALL_A = [a1,a2,a3,a4,a5,a6,a7,a8]
ALL_S = [s1,s2,s3]

for arr in ALL_A:
    x = dumps(arr)
    arr2 = loads(x)
    if not (arr == arr2).all():
        raise Exception("Bad")
    
    if not xmlequal(arr,arr2):
        raise Exception("Bad2")

for v in ALL_S:
    x = dumps(v)
    v2 = loads(x)
    if v != v2 or not xmlequal(v,v2):
        raise Exception("Bad3")
        
# ------ random arrays ------
omit = []
ArrayMap = {}

for name, itemfunc in ntypelist:
    if hasattr(N, name): # not all types may be available
        dtype = getattr(N,name)
        initdata = [itemfunc() for i in range(10)]
        val = N.array(initdata, dtype)
        ArrayMap['NumPy array of %s' % name] = val
        
    else:
        omit.append(name)
        continue

xml = dumps(ArrayMap, deepcopy=1)
#print xml

result = loads(xml)
# deeply compare objects to ensure they are identical
if not xmlequal(ArrayMap, result):
    raise Exception("Bad array result!")

# compare arrays item-by-item (coercive compare of course)
for k,v in ArrayMap.items():
    # compare arrays
    c = result[k] == ArrayMap[k]
    if not c.all(): # if any entries not equal
        raise Exception("Bad array result (2)")

print "Omitted arrays:",omit

omit = []
ScalarMap = {}
# ------ Random scalar values ------ 
for name, itemfunc in ntypelist:
    if hasattr(N, name): # not all types may be available
        dtype = getattr(N,name)
        initdata = [itemfunc() for i in range(10)]
        val = itemfunc()
        ScalarMap['NumPy scalar of %s' % name] = val		
    else:
        omit.append(name)
        continue

xml = dumps(ScalarMap, deepcopy=1)
#print xml

result = loads(xml)
# deeply compare objects to ensure they are identical
if not xmlequal(ScalarMap, result):
    raise Exception("Bad scalar result!")

# compare arrays item-by-item (coercive compare of course)
for k,v in ScalarMap.items():
    if result[k] != ScalarMap[k]:
        raise Exception("Bad scalar result (2)")
        
print "Omitted scalars:",omit

print "** OK **"

