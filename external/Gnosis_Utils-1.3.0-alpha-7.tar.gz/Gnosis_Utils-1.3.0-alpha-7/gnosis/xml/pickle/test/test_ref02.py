__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from UserList import UserList
from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT

#u = UserList([1,2,3])
#u.append(u)
l = [1,2,3]
l.append(l)
u = UserList(l)
print u
x = dumps(u,short_ids=1)
print x

p = loads(x,class_search=SEARCH_NO_IMPORT,allow_replicants=0)
print p
#print id(p),id(p[3])
print dumps(p,short_ids=1)



