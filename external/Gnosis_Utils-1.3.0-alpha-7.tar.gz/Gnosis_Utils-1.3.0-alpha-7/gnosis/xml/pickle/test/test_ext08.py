"""
Demo showing that both Stackable and Class extensions can
handle the same object.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, \
     unregister_extension, ClassExtension
from types import *
from funcs import * # grab enumerate() if needed

ORDER = ''

class Whatever:
    pass

class FooExt(StackableExtension):

    def __init__(self):
        StackableExtension.__init__(self, "FooExt")
    
    def pickle(self, obj):
        if not isinstance(obj,Whatever):
            return self.ignore(obj)

        global ORDER
        ORDER += 'Fp'

        # return arbitrary coredata + propmap I can check below
        return (obj, ['Foo',u'core','is',u'here'],
                {'foo1':123,'foo2':345})

    def unpickle(self, obj, coredata, propmap):
        for i,v in enumerate(['Foo',u'core','is',u'here']):
            # guard against string coerce
            if coredata[i] != v or type(v) != type(coredata[i]):
                raise "ERROR"

        if propmap != {'foo1':123,'foo2':345}:
            raise "ERROR"

        global ORDER
        ORDER += 'Fu'
        
        return obj

class BarExt(StackableExtension):

    def __init__(self):
        StackableExtension.__init__(self, "BarExt")
    
    def pickle(self, obj):
        if not isinstance(obj,Whatever):
            return self.ignore(obj)

        global ORDER
        ORDER += 'Bp'

        # return arbitrary coredata + propmap I can check below		
        return (obj, {u'Bar': 'core', 'is': u'here', u'whee': 987},
                {'bar1':12.34,'bar2':34.56})

    def unpickle(self, obj, coredata, propmap):
        l1 = coredata.keys()
        l1.sort()
        odict = {u'Bar': 'core', 'is': u'here', u'whee': 987}
        l2 = odict.keys()
        l2.sort()

        print l1, l2
        for i,v in enumerate(l1):
            if l2[i] != v or type(v) != type(l2[i]):
                raise "ERROR %s %s" % (str(v), str(l2[i]))

        for k,v in coredata.items():
            if v != odict[k] or type(v) != type(odict[k]):
                raise "ERROR"

        if propmap != {'bar1':12.34,'bar2':34.56}:
            raise "ERROR"

        global ORDER
        ORDER += 'Bu'
        
        return obj

class TazExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "TazExt")
        
    def pickle(self, obj):
        if not isinstance(obj,Whatever):
            return self.ignore(obj)

        global ORDER
        ORDER += 'Tp'

        # return arbitrary metadata + propmap I can check below
        metadata = {'baz1': 'hello metadata1', 'baz2': 'hello metadata2'}
        
        return (obj, metadata,
                {'bazprop1':84+35j,'bazprop2':1.2345})

    # 'Whatever' is an instance, so I need to implement the "nocore" API
    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        global ORDER
        ORDER += 'Tubc'

        if	metadata != {'baz1': 'hello metadata1', 'baz2': 'hello metadata2'}:
            raise "ERROR"
        
        return Whatever()

    def unpickle_finalize(self, obj, propmap):
        if propmap != {'bazprop1':84+35j,'bazprop2':1.2345}:
            raise "ERROR"
        
        global ORDER
        ORDER += 'Tuf'
    
# doesn't matter what order these are added in -- StackableExtensions
# are always called first

register_extension(TazExt())
register_extension(FooExt())
register_extension(BarExt())

w = Whatever()
w.aaa = 'www aaa'
w.bbb = u'www bbb'
w.ccc = 98765
w.ddd = 333.555

# all three extensions will operate on 'w'
x = dumps(w,short_ids=1,comments="Created by test_ext08.py")
print x

# allow loads() to find my classes
o = loads(x,SEARCH_NO_IMPORT)

# check attrs (exact types too!)
if o.aaa != 'www aaa' or type(o.aaa) != StringType or \
       o.bbb != u'www bbb' or type(o.bbb) != UnicodeType or \
       o.ccc != 98765 or o.ddd != 333.555:
    raise "ERROR"

# make sure everything was called in the right order
if ORDER != 'BpFpTpTubcTufFuBu':
    raise "ERROR"

print "** OK **"

