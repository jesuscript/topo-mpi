
#
# Test the user API, in these combinations:
#
#    dump->load
#    dumps->loads
#    dump_stats->load_stats
#    dumps_stats->loads_stats
#

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import is_replicant,\
     SEARCH_NO_IMPORT, add_class_to_store, replicant_info, SEARCH_STORE, SEARCH_NONE, \
     remove_class_from_store
import gnosis.xml.pickle
from gnosis.xml.pickle.objmodel import get_classtag
from gnosis.pyconfig import pyconfig
import re, sys
from funcs import unlink

# define convenience forms ...
def dumps( *args, **kwargs ):
    return gnosis.xml.pickle.dumps( *args, **kwargs )

def dump( *args, **kwargs ):
    return gnosis.xml.pickle.dump( *args, **kwargs )

def dumps_stats( *args, **kwargs ):
    return gnosis.xml.pickle.dumps_stats( *args, **kwargs )

def dump_stats( *args, **kwargs ):
    return gnosis.xml.pickle.dump_stats( *args, **kwargs )

def load( *args, **kwargs ):
    kw = {'min_accept':'1.1'}
    kw.update(kwargs)
    return gnosis.xml.pickle.load( *args, **kw )

def loads( *args, **kwargs ):
    kw = {'min_accept':'1.1'}
    kw.update(kwargs)
    return gnosis.xml.pickle.loads( *args, **kw )

def loads_stats( *args, **kwargs ):
    kw = {'min_accept':'1.1'}
    kw.update(kwargs)
    return gnosis.xml.pickle.loads_stats( *args, **kw )

def load_stats( *args, **kwargs ):
    kw = {'min_accept':'1.1'}
    kw.update(kwargs)
    return gnosis.xml.pickle.load_stats( *args, **kw )

# ---- dumps() / loads() --
o = [1,2,3]
x = dumps(o, version="1.1")
# see if it's really 1.1 pickle -- look for __toplevel__ hack
if not re.search('<attr name="__toplevel__"',x):
    raise "ERROR(0)"
p = loads(x)
if p != o:
    raise "ERROR(1)"

x = dumps(o, version="1.3")
# see if it's really 1.3 pickle
if not re.search('<PyObject version="1.3"',x):
    raise "ERROR(0)"
p = loads(x)
if p != o:
    raise "ERROR(2)"

# ---- dump() / load() ----
f = open('apitest.xml','w')
dump(o, f, version="1.1")
del f
x = open('apitest.xml','r').read()
# see if it's really 1.1 pickle -- look for __toplevel__ hack
if not re.search('<attr name="__toplevel__"',x):
    raise "ERROR(0)"
f = open('apitest.xml','r')
p = load(f)
if p != o:
    raise "ERROR(1)"

f = open('apitest.xml','w')
dump(o, f, version="1.3")
del f
x = open('apitest.xml','r').read()
# see if it's really 1.3 pickle
if not re.search('<PyObject version="1.3"',x):
    raise "ERROR(0)"
f = open('apitest.xml','r')
p = load(f)
if p != o:
    raise "ERROR(2)"

# -- dumps_stats() / loads_stats() --
o = [(1,2,3),{'a':1,'b':2,'c':3},[10,11,12]]

x,stats = dumps_stats(o, version="1.1")
# see if it's really 1.1 pickle -- look for __toplevel__ hack
if not re.search('<attr name="__toplevel__"',x) or \
       stats.pickle_version != '1.1':
    raise "ERROR()"
p,stats = loads_stats(x)
if stats.pickle_version != '1.1' or p != o:
    raise "ERROR(x)"

x,stats = dumps_stats(o, version="1.3")
# see if it's really 1.3 pickle
if not re.search('<PyObject version="1.3"',x) or \
       stats.pickle_version != '1.3' or \
       stats.nr_objects != 16:
    raise "ERROR(x)"

p,stats = loads_stats(x)
if stats.pickle_version != '1.3' or \
       stats.nr_objects != 16 or p != o:
    raise "ERROR(4)"

# ---- dump_stats() / load_stats() ----

f = open('apitest.xml','w')
stats = dump_stats(f, o, version="1.1")
# see if it's really 1.1 pickle -- look for __toplevel__ hack
del f
x = open('apitest.xml','r').read()
if not re.search('<attr name="__toplevel__"',x) or \
       stats.pickle_version != '1.1':
    raise "ERROR()"
f = open('apitest.xml','r')
p,stats = load_stats(f)
if stats.pickle_version != '1.1' or p != o:
    raise "ERROR(x)"

f = open('apitest.xml','w')
stats = dump_stats(f, o, version="1.3")
# see if it's really 1.3 pickle
del f
x = open('apitest.xml','r').read()
if not re.search('<PyObject version="1.3"',x) or \
       stats.pickle_version != '1.3' or \
       stats.nr_objects != 16:
    raise "ERROR(x)"

f = open('apitest.xml','r')
p,stats = load_stats(f)
if stats.pickle_version != '1.3' or \
       stats.nr_objects != 16 or p != o:
    raise "ERROR(4)"

# make sure file is closed so can be deleted later
del f

# ------ XML_Pickler -------

from gnosis.xml.pickle import XML_Pickler

# Three ways to use XML_Pickler ...
#     XML_Pickler().dumps(obj)
#     XML_Pickler(obj).dumps()
#     myXML_Pickler().dumps()
#

x = XML_Pickler().dumps(o,version='1.1')
# see if it's really 1.1 pickle -- look for __toplevel__ hack
if not re.search('<attr name="__toplevel__"',x):
    raise "ERROR(0)"
p = XML_Pickler().loads(x,min_accept='1.1')
if p != o:
    raise "ERROR"

x = XML_Pickler(o).dumps(version='1.1')
# see if it's really 1.1 pickle -- look for __toplevel__ hack
if not re.search('<attr name="__toplevel__"',x):
    raise "ERROR(0)"
p = XML_Pickler().loads(x,min_accept='1.1')
if p != o:
    raise "ERROR"

class mypickler(XML_Pickler):
    def __init__(self):
        XML_Pickler.__init__(self)
        self.a = (1,2,3)

m = mypickler()
x = m.dumps(version='1.1')
if re.search('<PyObject version="',x):
    raise "ERROR(0)"

o = m.loads(x,paranoia=0,min_accept='1.1')
if m.__class__ != o.__class__ or m.a != o.a:
    raise "ERROR"

# remove temp file
unlink('apitest.xml')

print "** OK **"
