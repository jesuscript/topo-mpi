
#
# For each object in t_atoms, t_containers, run it through
# the classifiers to make sure it is classified correctly.
#
#

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import t_atoms, t_containers
from gnosis.xml.pickle.objmodel import try_classify_atom, \
     try_classify_container, decompose

def expect_atom( obj, expect_attr ):
    # first, check that it's seen as an Atom
    is_atom, vtype, classtag, coredata, attrs = try_classify_atom(obj)
    
    print "Atom: %-25s, Type=%s, Class=%s, Core=%s" % (k,vtype,classtag,str(coredata))

    if not is_atom:
        raise "Failed to classify as Atom: %s" % str(obj)

    if (expect_attr and not len(attrs.keys())) or (not expect_attr and len(attrs.keys())):
        raise "Failed Atom attr check: %s,%s,%s" % (str(obj),expect_attr,attrs)

    # check that it's NOT seen as a container
    is_container, vtype, classtag, coredata, attrs = try_classify_container(obj)

    if is_container:
        raise "Failed: Classified Atom as Container: %s" % str(obj)

    print decompose(obj,0,0)
    
def expect_container( obj, expect_attr ):
    # first, check that it's seen as a Container
    is_container, vtype, classtag, coredata, attrs = try_classify_container(obj)
    
    print "Container: %-25s, Type=%s, Class=%s, Core=%s" % (k,vtype,classtag,str(coredata))
    
    if not is_container:
        raise "Failed to classify as Container: %s" % str(obj)

    if (expect_attr and not len(attrs.keys())) or (not expect_attr and len(attrs.keys())):
        raise "Failed to Container attr check: %s,%s" % (str(obj),expect_attr)

    # check that it's NOT seen as an Atom
    is_atom, vtype, classtag, coredata, attrs = try_classify_atom(obj)

    if is_atom:
        raise "Failed: Classified Container as Atom: %s" % str(obj)

    print decompose(obj,0,0)	

#
# Test one of each Atom & Container
#

for k,v in t_atoms.Atoms.items():
    # base types, no attrs
    expect_atom( v, 0 )

for k,v in t_atoms.SubclassAtoms_NoAttr.items():
    # subclassed, but no attrs
    expect_atom( v, 0 )

for k,v in t_atoms.SubclassAtoms_Attr.items():
    # subclass, with attrs
    expect_atom( v, 1 )
    
for k,v in t_containers.Containers.items():
    # base types, no attrs	
    expect_container( v, 0 )

for k,v in t_containers.SubclassContainers_NoAttr.items():
    # subclassed, but no attrs	
    expect_container( v, 0 )

for k,v in t_containers.SubclassContainers_Attr.items():
    # subclassed, with attrs
    expect_container( v, 1 )	

print "** OK **"

