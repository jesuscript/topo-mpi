
from gnosis.pyconfig import pyconfig
import os, sys, string

__all__ = ['unlink','touch']

# fake enumerate() for older Pythons
if not pyconfig.Have_Enumerate():
    def enumerate(seq):
        l = []
        i = 0
        for item in seq:
            l.append( (i,item) )
            i += 1

        return l

    __all__.append('enumerate')
    
# cheap substitutes for some shell functions
def unlink(filename):
    if not os.path.isfile(filename):
        return

    # eegh ... convoluted, but this is the only
    # way I made it work for both Linux & Win32 
    try: os.unlink(filename)
    except: pass

    try: os.remove(filename)
    except: pass

def touch(filename):
    open(filename,'w')

