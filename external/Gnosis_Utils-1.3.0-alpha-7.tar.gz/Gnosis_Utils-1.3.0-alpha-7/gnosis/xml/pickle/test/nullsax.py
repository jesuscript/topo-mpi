"""
A 'null' SAX parser that does nothing (purely a speed test).
"""

__author__ = ['Frank McIngvale <frankm@hiwaay.net>']

from xml.sax.expatreader import ExpatParser
from xml.sax.handler import ContentHandler, ErrorHandler
from xml.sax.xmlreader import InputSource
from StringIO import StringIO

class saxdemo_parser(ContentHandler):
    def __init__(self):
        ContentHandler.__init__(self)

    #
    # The ContentHandler interface
    #
    def setDocumentLocator(self, locator):
        pass
        
    def startDocument(self):
        pass

    def endDocument(self):
        pass
        
    def startElement(self,name,attrs):
        pass

    def startElementNS(self, name, qname, attrs):
        pass
        
    def endElement(self,name):
        pass

    def endElementNS(self, name, qname):
        pass
        
    def characters(self,content):
        pass

    def ignorableWhitespace(self, whitespace):
        pass

    def processingInstruction(self, target, data):
        pass

    def skippedEntity(self, name):
        pass

    def startPrefixMapping(self, prefix, uri):
        pass

    def endPrefixMapping(self, prefix):
        pass
    
    #
    # The ErrorHandler interface
    #
    def error(self,exception):
        print "** ERROR **", str(exception)
        raise exception

    def fatalError(self,exception):
        print "** FATAL ERROR **", str(exception)
        raise exception

    def warning(self,exception):
        print "** WARNING **", str(exception)
        raise exception

    #
    # The EntityResolver interface
    #
    def resolveEntity(self,publicId,systemId):
        inp = InputSource()
        inp.setByteStream(StringIO(""))
        return inp

def sparse(xml):
    parse(StringIO(xml))
    
def parse(fileobj):
    
    e = ExpatParser()
    m = saxdemo_parser()
    e.setContentHandler(m)
    e.setErrorHandler(m)
    e.setEntityResolver(m)

    e.parse(fileobj)

# might be used as a module also

if __name__ == '__main__':
    
    import sys, os
    from stat import *
    from time import time

    print "READING ..."
    t1 = time()
    parse(open(sys.argv[1],'r'))
    dt = time()-t1
    dt += 1e-6

    size = os.stat(sys.argv[1])[ST_SIZE]
    
    print "Parsed %d bytes, at a rate of %d bytes/sec (%.1f seconds)" % (size,size/dt,dt)

