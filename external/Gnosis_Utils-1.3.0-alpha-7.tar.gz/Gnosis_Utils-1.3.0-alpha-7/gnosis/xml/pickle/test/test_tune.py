from gnosis.xml.pickle import dumps_stats, loads_stats, SEARCH_NO_IMPORT, dumps, loads
import random
import profile, pstats
from time import time
from copy import copy
import pickle

import sys
sys.path.insert(0,'.')

from randstuff import rand_obj
import randstuff

# LARGE_STRINGS gives too much of a slowdown, not a really
# good benchmark here
randstuff.LARGE_STRINGS = 0
# don't use unicode since xml.pickle <= 1.2.0 can't handle
# arbitrary unicode strings
randstuff.USE_UNICODE = 0

# pick a seed for repeatable results
random.seed(182732264)
o = rand_obj(6)

def doit_new(obj):
    
    t0 = time()
    xml,stats = dumps_stats(obj)
    dt = time()-t0
    #profile.run('xml,stats = dumps_stats(o)','statsout.dat')
    #ps = pstats.Stats('statsout.dat')
    #ps.sort_stats('cumulative')
    #ps.reverse_order()
    #ps.print_stats()
    #sys.exit(0)
    #print xml
    print "LEN ",len(xml)
    print "nr objects ",stats.nr_objects
    print "obj/sec ",stats.nr_objects/dt
    
    t0 = time()
    o,stats = loads_stats(xml,SEARCH_NO_IMPORT)
    dt = time()-t0
    l = copy(locals())
    l['xml'] = xml	
    #profile.runctx('o,stats = loads_stats(xml,SEARCH_NO_IMPORT)',globals(),l, 'statsout.dat')
    #ps = pstats.Stats('statsout.dat')
    #ps.sort_stats('cumulative')
    #ps.reverse_order()
    #ps.print_stats()
    #sys.exit(0)
    print "Loaded version: ",stats.pickle_version
    print "nr loaded ",stats.nr_objects
    print "obj/sec ",stats.nr_objects/dt

    return stats.nr_objects

def doit_11(obj, NR):
    
    t0 = time()
    xml = dumps(obj,version='1.1')
    dt = time()-t0
    print "LEN ",len(xml)
    print "obj/sec ",NR/dt
    
    t0 = time()
    o,stats = loads_stats(xml,SEARCH_NO_IMPORT,min_accept='1.1')
    dt = time()-t0
    print "Loaded version: ",stats.pickle_version
    print "obj/sec ",NR/dt

def doit_pickle(obj, NR):
    
    t0 = time()
    s = pickle.dumps(obj)
    dt = time()-t0
    #profile.run('xml,stats = dumps_stats(o)')
    #sys.exit(0)
    #print xml
    print "LEN ",len(s)
    print "obj/sec ",NR/dt
    
    t0 = time()
    o = pickle.loads(s)
    dt = time()-t0
    print "obj/sec ",NR/dt
    
print "*** xml.pickle 1.3 ***"
nr = doit_new(o)
print "*** xml.pickle 1.1 ***"
doit_11(o, nr)
print "*** standard pickle ***"
doit_pickle(o, nr)

