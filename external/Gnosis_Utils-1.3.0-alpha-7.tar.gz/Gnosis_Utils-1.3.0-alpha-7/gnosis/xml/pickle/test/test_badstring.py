"""
XML is not 100% binary-clean. Many characters are illegal in an XML
file, and others will be silently discarded by the XML parser.

xml.pickle is aware of this, and will use various encoding/escaping
methods to ensure that all values are preserved exactly. From the caller's
perspective, xml.pickle makes XML appear to be 100% binary clean,
for both strings & unicode values.

One case to mention specifically is '\r\n': An XML parser will discard
the '\r' from '\r\n' pairs. xml.pickle will encode the \r to the character
reference '&#x0d;'. To not do so would risk data loss in cases of pure
binary data that happened to contain a '\r\n' pair. If you find this
annoying (ie. if you are producing pickles with blocks of readable text),
then you should normalize the line endings yourself before passing them
to xml.pickle.

This tests a variety of string/unicode cases to show that the
exact text of each is preserved. Several of these were
unpickleable under 1.2.0. Test them to make sure they are OK now.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps,loads,dump,load
from types import *
from gnosis.xml.xmlmap import is_legal_xml
import sys

class Foo:
    def __init__(self,s):
        self.s = s

test_str = [
    # a string that's safe to place in value=
    'safe attr ASCII',
    # safe to place in value=, and the &<> will be escaped
    "safe attr ASCII with &<>",
    # xml.pickle knows that the tabs below will be removed by the lowlevel
    # XML parser if the string is placed in value=. To preserve the exact
    # text, xml.pickle will place the string in a <u> element body instead.
    'a string with \t non-attr \t safe \t space',
    # The lowlevel XML parser will remove \r's from \r\n pairs.
    # xml.pickle recognizes this, and will escape the \r's so that
    # the exact text is preserved.
    "a multi\r\nline \t string\n\r\n\r\nwith some\r\n \\r and \\n",
    # this shows that all spaces/tabs/etc. are preserved exactly
    "\t multi \t\t line  \n   with \r\n   some extra   \n   spaces \n and &<> & < > \n\t\n    ",
    # and of course things like this won't fool it
    "hm, look an &amp;&gt;&lt;&<>",
    # a utf-8 encoded string
    '\xed\xa0\x80',
    # a long binary string - will be base64 encoded
    '\x01\x02\x03\x04'*100,
    # long mixed binary+text - will be url encoded for readability
    'hello \x01 world \x02' * 20,
    # huge binary string, will be compressed
    '\x01\x02\x03\x04'*8000,
    # tricky - the re_safe_attr_ASCII will allow the \n at the end,
    # so make sure it is caught and placed in the body
    'does it catch the linefeed?\n',
    'does it catch the linefeed?\r',
    'does it catch the linefeed?\r\n',
    'does it catch the linefeed?\n\r',
    # ensure that 0-length strings are OK
    ''
    ]

from test_xml_legality import bad_unicode, good_unicode

test_uni = [
    u'OK',
    # Unicode values that contains the (1.2.0) special string sequence
    u'\xbb\xbbABC\xab\xab',
    # same, but mix in some \r's like above to show they are preserved
    u'\xbb\xbbABC\n\r\nDEF\r\n\r\nGHI\xab\xab',
    # like above, shows that all spaces/tabs/etc. are preserved exactly
    u"\t multi \t\t line  \n   with \r\n   some extra   \n   spaces \n and &<> & < > \n\t\n    ",
    # like string case
    u"hm, look an &&amp;<&gt;>&&lt;&&",
    # long 'bad' value, will be base64 encoded
    u'\u0001\u0002\u0003' * 100,
    # long bad+text value, will be XML-escaped for readability
    u'hello \u0001 world \u0002' * 20,
    # huge 'bad' value, will be compressed
    u'\u0001\u0002\u0003\u0004' * 8000,
    # ensure that 0-length strings are OK
    u''
    ]

# add tests from test_xml_legality			
test_uni += bad_unicode + good_unicode

for s in test_str:
    x = dumps(s)
    print x
    g = loads(x)
    if g != s:
        raise "ERROR %s,%s" % (repr(s),repr(g))

for u in test_uni:
    x = dumps(u)
    print x
    g = loads(x)
    
    if g != u:
        raise "ERROR %s,%s" % (repr(u),repr(g))

# test using 'prefer_cdata' flag, to show that it
# still preserves content
for s in test_str:
    x = dumps(s,prefer_cdata=1)
    print x
    g = loads(x)
    if g != s:
        raise "ERROR %s,%s" % (repr(s),repr(g))

for u in test_uni:
    x = dumps(u,prefer_cdata=1)
    print x
    g = loads(x)
    
    if g != u:
        raise "ERROR %s,%s" % (repr(u),repr(g))

print "** OK **"
