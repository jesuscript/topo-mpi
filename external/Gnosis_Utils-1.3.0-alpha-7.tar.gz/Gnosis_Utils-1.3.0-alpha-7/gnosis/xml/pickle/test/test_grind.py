"""
test_grind.py - dump()/load() looping with randomly generated objects.

Will restart where it last stopped if interrupted by Ctrl-C, or a crash.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

#import psyco; psyco.full()

from gnosis.xml.pickle import dump_stats, load_stats, dumps, loads, dump, load, SEARCH_NONE, \
     SEARCH_NO_IMPORT
import random, os, re
from xml.parsers.expat import ExpatError
from stat import *
from time import time
from funcs import unlink

import sys
sys.path.insert(0,'.')
from randstuff import rand_obj

def write(msg):
    sys.stderr.write(msg+'\n')
    sys.stderr.flush()
    
def finish_state():
    # dumps first to minimize chance of user hitting Ctrl-C while writing
    xml = dumps(random.getstate())
    open('grindseed.xml','wb').write(xml)

def start_state():
    if not os.path.isfile('grindseed.xml'):
        finish_state()

    # the see should just be a plain list, so restrict search
    seed = load(open('grindseed.xml','rb'),SEARCH_NONE,allow_replicants=0)
    random.setstate(seed)

def compare_objs(o1, o2):
    from gnosis.xml.pickle.extras import object_slowcmp, object_sha_core, norm_xml
    import cPickle, pickle
    
    if not object_slowcmp(o1, o2):
        # error - dump info
        h1 = object_sha_core(o1)
        h2 = object_sha_core(o2)
        ERR = "Objects don't match!\n"
        ERR += "HASH A: %s\n" % h1
        ERR += "HASH B: %s\n" % h2
        # dump XML to files ...
        open('grinderrA.xml','wb').write(norm_xml(o1))
        open('grinderrB.xml','wb').write(norm_xml(o2))
        # dump as regular pickles ...
        open('grinderrObj.pck','wb').write(pickle.dumps(o1))
        open('grinderrObj.cpk','wb').write(cPickle.dumps(o2))
        ERR += "XML dumped to 'grinderrA.xml' and 'grinderrB.xml'\n"
        ERR += "pickle/cPickle written to 'grinderrObj.pck' and 'grinderrObj.cpk'\n" 
        raise Exception(ERR)

import profile
import pickle
#import cPickle as pickle

TOT_NROBJ = 0
TOT_SIZE = 0
TOT_DUMPSEC = 0.0
TOT_LOADSEC = 0.0
TOT_P_DUMPSEC = 0.0
TOT_P_LOADSEC = 0.0
TOT_P_SIZE = 0

def run_loop():
    global TOT_NROBJ, TOT_DUMPSEC, TOT_LOADSEC, TOT_P_DUMPSEC, \
           TOT_SIZE, TOT_P_LOADSEC, TOT_P_SIZE
    
    start_state()

    # print a 'run ID' - a little visual cue that the runs are progressing,
    # and/or that the runs are being repeated when there is an error, or
    # if user hit Ctrl-C during a run.
    write('Run ID: %X' % (random.randint(0,sys.maxint-1)))

    # write XML to file for reference in case test crashes
    o = rand_obj(5) # create object of (up to) depth 5
    f = open('randdump.xml','wb')
    # do timing stats
    t1 = time()
    # should require no rawpickles, so prohibit them
    st = dump_stats(f, o, allow_rawpickles=0)
    dt = time()-t1 + 1e-6
    TOT_DUMPSEC += dt
    TOT_NROBJ += st.nr_objects
    del f # ensure file is closed
    sz = os.stat('randdump.xml')[ST_SIZE]
    write('# objects: %d (wrote %.1f/sec), XML size: %d' % \
          (st.nr_objects,st.nr_objects/dt,sz))
    TOT_SIZE += sz
    
    try:
        f = open('randdump.xml','rb')
        t1 = time()
        # should be no replicants, so explicitly disallow (better to raise
        # an error at the site of replicant creation, for debugging purposes)
        o2,st = load_stats(f,SEARCH_NO_IMPORT,allow_replicants=0)
        dt = time()-t1 + 1e-6
        TOT_LOADSEC += dt
        write('# objects: %d (read %.1f/sec)' % \
              (st.nr_objects,st.nr_objects/dt))

        # check that orig & copy match
        compare_objs(o,o2)
        write("Objects compared OK")
        
    except ExpatError, exc:
        # get the line# & offset from exception and print bad line,
        # so it can be captured to file, etc. (use print instead of
        # write so stdout can be captured)
        print "ERROR ",exc
        print exc.lineno, exc.offset
        del f
        f = open('randdump.xml','rb')
        n = exc.lineno
        while n > 0:
            line = f.readline()
            n -= 1
            
        print "LINE ",line
        print "REPR LINE ",repr(line)
        print "CHAR ",repr(line[exc.offset])
        s = exc.offset - 5
        if s < 0:
            s = 0

        print "Section: ",repr(line[s:s+10])
        
        sys.exit(1)

    # now get standard pickle times for comparison
    t1 = time()
    s = pickle.dump(o,open('randdump.pck','wb'),1)
    dt = time()-t1 + 1e-6
    TOT_P_DUMPSEC += dt
    sz = os.stat('randdump.pck')[ST_SIZE]
    TOT_P_SIZE += sz
    write('standard pickle (wrote %.1f/sec), size: %d' % \
          (st.nr_objects/dt,sz))
    
    del o
    t1 = time()
    p = pickle.load(open('randdump.pck','rb'))
    dt = time()-t1 + 1e-6
    TOT_P_LOADSEC += dt
    write('standard pickle (read %.1f/sec)' % \
          (st.nr_objects/dt))
    
    unlink('randdump.pck')
    
    # update random seed after tests suceed.
    # else, the same test will  be run again next time.
    finish_state()

def sanity():
    # complex numbers have to be disallowed as keys, since they
    # aren't sortable, so do a quickie test here for sanity to
    # show they are OK
    d = {1.342+8.454j: 'hello', 89.435-3984.454j: 'world'}
    o = {443.323-8234.323j: d}
    xml = dumps(o)
    o2 = loads(xml)
    if o != o2:
        raise "ERROR"

    write("* sanity check ok *")
    
sanity()

try:
    # can hit Ctrl-C whenever to stop test and it will continue
    # at the same place the next time you run.
    i = 1
    #while i < 100:
    while 1:
        write("Loop %d" % i)
        run_loop()
        i += 1

except KeyboardInterrupt:
    print "Exiting on Ctrl-C ..."
    
if TOT_NROBJ > 0:
    print "Total objects: ",TOT_NROBJ
    print "XML pickle:"
    print "  Average dump speed: %.1f obj/sec" % (TOT_NROBJ/TOT_DUMPSEC)
    print "  Average load speed: %.1f obj/sec" % (TOT_NROBJ/TOT_LOADSEC)
    print "  Average size: %.1f bytes/obj" % (float(TOT_SIZE)/TOT_NROBJ)

    print "Pickle:"
    print "  Average Pickle.dump speed: %.1f obj/sec" % (TOT_NROBJ/TOT_P_DUMPSEC)
    print "  Average Pickle.load speed: %.1f obj/sec" % (TOT_NROBJ/TOT_P_LOADSEC)
    print "  Average Pickle size: %.1f bytes/obj" % (float(TOT_P_SIZE)/TOT_NROBJ)		

    print "Factors:"
    print "  XML/Pickle size: %.1f" % (float(TOT_SIZE)/TOT_P_SIZE)
    print "  XML/Pickle dump time: %.1f" % (TOT_DUMPSEC/TOT_P_DUMPSEC)
    print "  XML/Pickle load time: %.1f" % (TOT_LOADSEC/TOT_P_LOADSEC)		

