from mx.URL import URLType, URL
from mx.DateTime import now, DateTimeDelta as dtd
from mx.TextTools import *
from gnosis.xml.pickle import dumps, loads
from gnosis.xml.pickle.extras import xmlequal
import gnosis.xml.pickle.plugins.plugin_mx
import pickle

url = URL("http://www.example.com/abc/def/query.html?name=foo&addr=bar")
x = dumps(url)
url2 = loads(x)

if url != url2:
    raise Exception("ERROR")

n = now()
x = dumps(n)
n2 = loads(x)
if n != n2:
    raise Exception("ERROR")

d = dtd(1, 2.3, 4.5, 6.7)
x = dumps(d)
d2 = loads(x)
if d != d2:
    raise Exception("ERROR")

c = CharSet(u"a-z\u0300-\u03a3")
x = dumps(c)
c2 = loads(x)
if not xmlequal(c,c2):
    raise Exception("ERROR c")

tags = ( 
    (None, Is, 'a', +2),
    (None, Is, 'b'),
    )
    
t = TagTable(tags)
x = dumps(t)
t2 = loads(x)
# seems to load an equivalent TagTable, yet not equal -- just
# do loads() to check for exception

t = TextSearch('searching for this', 'xyzx'*(256/4), BOYERMOORE)
x = dumps(t)
t2 = loads(x)
if not xmlequal(t,t2):
    raise Exception("ERROR ts")

print "* OK *"




