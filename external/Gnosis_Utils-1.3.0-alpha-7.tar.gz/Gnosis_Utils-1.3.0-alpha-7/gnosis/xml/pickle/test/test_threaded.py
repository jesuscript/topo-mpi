
from threading import Thread
from gnosis.xml.pickle import dumps, loads, add_class_to_store, remove_class_from_store, is_replicant
from time import sleep, ctime, time

class AAA:
    def __init__(self, val): self.val = val
        
class BBB:
    def __init__(self, val): self.val = val

class CCC:
    def __init__(self, val): self.val = val

class DDD:
    def __init__(self, val): self.val = val

class EEE:
    def __init__(self, val): self.val = val

class FFF:
    def __init__(self, val): self.val = val

class GGG:
    def __init__(self, val): self.val = val

class HHH:
    def __init__(self, val): self.val = val

class III:
    def __init__(self, val): self.val = val

class JJJ:
    def __init__(self, val): self.val = val

class YYY:
    def __init__(self, val): self.val = val

class ZZZ:
    def __init__(self, val): self.val = val
        
class RunClass(Thread):
    def __init__(self, klass, NR_LOOPS):
        Thread.__init__(self)
        self.klass = klass
        self.NR_LOOPS = NR_LOOPS
        
    def run(self):
        f = self.klass(123)
        xml = dumps(f)

        for i in range(self.NR_LOOPS):			
            add_class_to_store(self.klass)
            o = loads(xml)
            if is_replicant(o) is True:
                raise "ERROR(1)"
            
            remove_class_from_store(self.klass)
            o = loads(xml)
            if is_replicant(o) is False:
                raise "ERROR(2)"
                
        print "DONE ",self.klass,time(),ctime()

def test1():
    all = [AAA,BBB,CCC,DDD,EEE,FFF,GGG,HHH,III,JJJ,YYY,ZZZ]
    threads = []
    
    for k in all:
        t = RunClass(k, 1000)
        threads.append(t)
        
    for t in threads:
        t.start()

    for t in threads:
        t.join()
    
test1()

