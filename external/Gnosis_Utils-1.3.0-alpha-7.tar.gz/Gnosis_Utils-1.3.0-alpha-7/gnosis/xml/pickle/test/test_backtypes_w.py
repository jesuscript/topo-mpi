#
# The writing-side of test_backtypes_r.py
#
# Should be run on the latest Python available, then
# the saved 'backtypes.xml' loaded under earlier Pythons
# to make sure they do something sensible.
#

from gnosis.xml.pickle import dumps_stats, SEARCH_NO_IMPORT
from gnosis.pyconfig import pyconfig

import t_containers

olist = []

l = t_containers.SList_noattr([1,2,3])
l.append(l)
olist.append(l)

t = t_containers.STuple_noattr((11,12,13))
olist.append(t)

d = t_containers.SDict_noattr({'a':111,'b':222})
d['c'] = d
olist.append(d)

l = t_containers.SList_noattr([123,456,789])
l.append(l)
l.aaa = 'abc'
l.bbb = ['d','e','f',l]
olist.append(l)

t = t_containers.STuple_noattr((1.2,3.4,5.6))
t.xxx = [1+2j,3+4j,t]
t.yyy = t
t.zzz = t.xxx
olist.append(t)

d = t_containers.SDict_noattr({'x':'aaa','y':('a','b','c')})
d['z'] = d
d.aaa = 'def'
d.bbb = [1,2,d]
olist.append(d)

if pyconfig.Have_BuiltinSet():
    s = t_containers.SSet_noattr((234,4.56,71+23j))
    olist.append(s)

    s = t_containers.SSet_noattr((345,5.67,91+23j))
    s.aaa = 'zyx'
    s.bbb = ('r','s','t',s)
    olist.append(s)

    s = t_containers.SFrozenSet_noattr((456,5.67,11+23j))
    olist.append(s)

    s = t_containers.SFrozenSet_noattr((567,6.78,1+23j))
    s.aaa = '.zyx'
    s.bbb = ('.r','.s','.t',s)
    olist.append(s)

import sys
x,st = dumps_stats(olist,comments=[
            'This file was written by test_backtypes_w.py',
            'Written with Python %d.%d.%d' % (sys.version_info[0],sys.version_info[1],
                                            sys.version_info[2]),
            'Should only be written using the latest available Python'])
print x
print "%d objects written" % st.nr_objects
open('backtypes.xml','w').write(x)

