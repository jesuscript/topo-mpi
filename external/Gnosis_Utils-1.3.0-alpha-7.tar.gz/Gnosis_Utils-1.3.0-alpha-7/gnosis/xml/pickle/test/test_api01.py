"""
API test, part 1

This is test of the various ways loads() can be called.

This is primarily a test of loading classes with various search/paranoia
settings. Data loading is tested later. loads() is the hard case due to
how it's overloaded for compatibility with 1.2.0 -- see api for docs.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps,loads,dumps_stats,loads_stats,is_replicant,\
     SEARCH_NO_IMPORT, add_class_to_store, replicant_info, SEARCH_STORE, SEARCH_NONE, \
     remove_class_from_store, XMLUnpicklingError, SEARCH_ALL

from gnosis.xml.pickle.objmodel import get_classtag
from gnosis.pyconfig import pyconfig

import re, sys
from types import *
from funcs import * # grab enumerate(), if it's missing

def is_1dot3(xml):
    "Is it a 1.3 pickle?"
    return re.search('<PyObject version="1.3"',xml)

def is_1dot1(xml):
    "Is it a 1.1 pickle (assumes you pickled a list)"
    return re.search('<attr name="__toplevel__"',xml)

# Create a few test classes

class Foo: pass

if pyconfig.Have_ObjectClass():
    class Foo2(object): pass
else:
    class Foo2: pass
    
if pyconfig.Have_Slots():
    class Foo3: __slots__ = ('a','b')
else:
    class Foo3: pass

if pyconfig.Have_ObjectClass() and pyconfig.Have_Slots():
    class Foo4(object): __slots__ = ('a','b')
else:
    class Foo4: pass

def expect_replicants(origlist,testlist):
    """origlist holds Foo* classes/instances.
    Checks that testlist holds only replicants
    of origlist."""
    
    for i,o in enumerate(testlist):
        if not is_replicant(o):
            raise "ERROR - not replicant %s" % str(o)

        # make sure replicant holds true classtag
        info = replicant_info(o)
        name = info[1]+'.'+info[2]
        if name != get_classtag(origlist[i]):
            raise "ERROR (%s,%s)" % (name,get_classtag(origlist[i]))

def loads_expect_replicants(objs,x,arglists):

    for args,kwargs in arglists:
        kw = {'min_accept':'1.1'}
        kw.update(kwargs)		
        l = loads(x,*args,**kw)
        expect_replicants(objs,l)

def loads_stats_expect_replicants(objs,x,arglists):

    for args,kwargs in arglists:
        kw = {'min_accept':'1.1'}
        kw.update(kwargs)				
        l,st = loads_stats(x,*args,**kw)
        expect_replicants(objs,l)

def expect_match(origlist,testlist):
    """orig list holds Foo* class/instances.
    Checks that testlist matches it exactly."""
    
    for i,obj in enumerate(testlist):
        if type(obj) in [ClassType,TypeType]:
            if obj != origlist[i]:
                raise "ERROR"

        elif obj.__class__ != origlist[i].__class__:
                raise "ERROR"
            
def loads_expect_match(objs,x,arglists):
    for args,kwargs in arglists:
        kw = {'min_accept':'1.1'}
        kw.update(kwargs)
        l = loads(x,*args,**kw)
        expect_match(objs,l)

def loads_stats_expect_match(objs,x,arglists):
    for args,kwargs in arglists:
        kw = {'min_accept':'1.1'}
        kw.update(kwargs)		
        l,st = loads_stats(x,*args,**kw)
        expect_match(objs,l)		
        
def run_all_loads_tests(objs,api):
    """
    Run tests using loads().
    
    objs is a list of Foo* class/instances.
    api is the API version to test against"""
    
    if api not in ['1.1','1.3']:
        raise "ERROR"

    # use deepcopy to shorten tags (no id=)
    x = dumps(objs,version=api,deepcopy=1)
    #print x
    # make sure it wrote w/correct API
    if (api == '1.1' and not is_1dot1(x)) or \
       (api == '1.3' and not is_1dot3(x)):
        raise "ERROR"

    # nothing in store - expect all replicants
    arglists_for_replicants = [
        [(),{}],  # no args means default of SEARCH_STORE (or paranoia=1)
        [(1,), {}], # paranoia=1
        [(),{'paranoia':1}], # paranoia=1, kwarg		
        [(SEARCH_STORE,),{}], # class_search=SEARCH_STORE, positional
        [(SEARCH_NONE,),{}],  # class_search=SEARCH_NONE, positional
        [(),{'class_search':SEARCH_STORE}], # class_search=SEARCH_STORE, kwarg
        [(),{'class_search':SEARCH_NONE}], # class_search=SEARCH_NONE, kwarg
        ]
    
    loads_expect_replicants(objs,x,arglists_for_replicants)

    # let it find Foo
    arglists_find_not_in_store = [
        [(-1,),{}], # paranoia=-1, positional
        [(0,),{}],  # paranoia=0, positional
        [(),{'paranoia':0}], # paranoia=0, kwarg
        [(),{'paranoia':-1}], # paranoia=-1, kwarg		
        [(SEARCH_NO_IMPORT,),{}], # class_search, positional
        [(SEARCH_ALL,),{}], # class_search, positional		
        ]
    loads_expect_match(objs,x,arglists_find_not_in_store)

    # make sure nothing 'stuck' above - expect all replicants again
    loads_expect_replicants(objs,x,arglists_for_replicants)

    # now add to store, and load from store (all cases)
    for o in objs:
        if type(o) in [TypeType,ClassType]:
            add_class_to_store(o)

    arglists_find_in_store = [
        [(1,),{}], # paranoia=1, positional
        [(2,),{}], # paranoia=2, positional
        [(),{'paranoia':1}], # paranoia=1, kwarg
        [(),{'paranoia':2}], # paranoia=2, kwarg								
        [(SEARCH_STORE,),{}], # class_search=SEARCH_STORE, positional
        [(),{'class_search':SEARCH_STORE}], # class_search=SEARCH_STORE, kwarg
        ]

    loads_expect_match(objs,x,arglists_find_in_store)

    # SEARCH_NONE should *still* return a replicant
    loads_expect_replicants(objs,x,[[(SEARCH_NONE,),{}]])
    
    # remove them all from the store
    for o in objs:
        if type(o) in [TypeType,ClassType]:
            remove_class_from_store(o)

    # and they all should be replicants again
    loads_expect_replicants(objs,x,arglists_for_replicants)

    # disallowing replicants should cause failure now
    try:
        loads(x,2) # paranoia=2 means no replicants
        raise "ERROR"
    except XMLUnpicklingError:
        pass

    # illegal forms
    try:
        loads(x,0,paranoia=1) # giving paranoia twice
        raise "ERROR"
    except XMLUnpicklingError:
        pass

    try:
        loads(x,SEARCH_STORE,paranoia=1) # mixed usage
        raise "ERROR"
    except XMLUnpicklingError:
        pass

    try:
        loads(x,1,allow_replicants=0) # mixed usage
        raise "ERROR"
    except XMLUnpicklingError:
        pass

    try:
        loads(x,1,class_search=SEARCH_STORE) # mixed usage
        raise "ERROR"
    except XMLUnpicklingError:
        pass			

def run_all_loads_stats_tests(objs,api):
    """
    Version of test using loads_stats.
    Easier since it isn't overloaded like loads().
    
    objs is a list of Foo* class/instances.
    api is the API version to test against"""
    
    if api not in ['1.1','1.3']:
        raise "ERROR"

    # use deepcopy to shorten tags (no id=)
    x = dumps(objs,version=api,deepcopy=1)
    #print x

    # nothing in store - expect all replicants
    arglists_for_replicants = [
        [(),{}],  # no args means default of SEARCH_STORE
        [(SEARCH_STORE,),{}], # class_search=SEARCH_STORE, positional
        [(SEARCH_NONE,),{}],  # class_search=SEARCH_NONE, positional
        [(),{'class_search':SEARCH_STORE}], # class_search=SEARCH_STORE, kwarg
        [(),{'class_search':SEARCH_NONE}], # class_search=SEARCH_NONE, kwarg
        ]
    
    loads_stats_expect_replicants(objs,x,arglists_for_replicants)

    # let it find Foo
    arglists_find_not_in_store = [
        [(SEARCH_NO_IMPORT,),{}], # class_search, positional
        [(SEARCH_ALL,),{}], # class_search, positional		
        ]
    loads_stats_expect_match(objs,x,arglists_find_not_in_store)

    # make sure nothing 'stuck' above - expect all replicants again
    loads_stats_expect_replicants(objs,x,arglists_for_replicants)

    # now add to store, and load from store (all cases)
    for o in objs:
        if type(o) in [TypeType,ClassType]:
            add_class_to_store(o)

    arglists_find_in_store = [
        [(SEARCH_STORE,),{}], # class_search=SEARCH_STORE, positional
        [(),{'class_search':SEARCH_STORE}], # class_search=SEARCH_STORE, kwarg
        ]

    loads_stats_expect_match(objs,x,arglists_find_in_store)

    # SEARCH_NONE should *still* return a replicant
    loads_stats_expect_replicants(objs,x,[[(SEARCH_NONE,),{}]])
    
    # remove them all from the store
    for o in objs:
        if type(o) in [TypeType,ClassType]:
            remove_class_from_store(o)

    # and they all should be replicants again
    loads_stats_expect_replicants(objs,x,arglists_for_replicants)

    # disallowing replicants should cause failure now
    try:
        loads_stats(x,allow_replicants=0)
        raise "ERROR"
    except XMLUnpicklingError:
        pass

# test vs. both 1.1 and 1.3 APIs
for api in ['1.1','1.3']:
    olist = []
    
    for k in [Foo,Foo2,Foo3,Foo4]:
        o = k()
        # 1.1 is buggy if no attributes for object subclasses
        if api == '1.1':
            o.a = 1
            
        olist += [k,o]

    run_all_loads_tests(olist,api)
    run_all_loads_stats_tests(olist,api)	

print "** OK **"


