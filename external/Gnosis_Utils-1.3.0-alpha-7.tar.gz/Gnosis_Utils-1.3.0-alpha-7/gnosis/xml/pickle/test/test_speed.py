#
# before stream additions
#
# write, 521831 objs, 47.776 secs (10922.5/sec)
#

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle

class foo: pass
def mk_foo(level=5):
    f = foo()
    # 1st level obj
    l = [1,2,3,4,5,6,7,8,9,10]
    t = (1.2,2.3,3.4,4.5,5.6,6.7,7.8,8.9,9.1,10.2)
    d = {'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,
         'eight':8,'nine':9,'ten':10}
    c = [(1+2j),(2+3j),(3+4j),(4+5j),(5+6j),(6+7j),(7+8j),(8+9j),(9+10j),(10+11j)]
    s = ('one','two','three','four','five','six','seven','eight','nine','ten')
    # 2nd level obj
    ll = [l,l,l,l,l,
          t,t,t,t,t,
          d,d,d,d,d,
          c,c,c,c,c,
          s,s,s,s,s]
    # 3rd level obj
    u = [ll,ll,ll,ll,ll,ll,ll,ll]
    # 4th level
    f.u = [u,u,u,u,u,u,u,u]
    # 5th level
    if level >= 5: f.uu = [f.u,f.u,f.u,f.u,f.u,f.u]
    # 6th level
    #if level >= 6: f.uuu = [f.uu,f.uu,f.uu,f.uu,f.uu,f.uu]
    if level >= 6: f.uuu = [f.uu,f.uu,f.uu]	
    return f

from time import time

#import psyco; psyco.full()

import profile, sys

o = mk_foo(5)

#xml_pickle.dump(open('speed.xml','w'), o,deepcopy=1)
#sys.exit(0)

# write in 1.1 format
print "****** 1.1 ******"
t1 = time()
xml,stats = xml_pickle.dumps_stats(o, deepcopy=1, version="1.1")
#open('speed-1.1.xml','w').write(xml) # save for reference
print "XML len ",len(xml)
print "WRITE TIME ",time()-t1
t1 = time()
o2,stats = xml_pickle.loads_stats(xml,min_accept='1.1')
print "LOADED AS ",stats.pickle_version
print "PARSE TIME",time()-t1

# write in 1.3 format
print "****** 1.3 ******"
t1 = time()
xml,stats = xml_pickle.dumps_stats(o, deepcopy=1, version="1.3")
#open('speed-1.3.xml','w').write(xml) # save for reference
#profile.run('xml,stats = xml_pickle.dumps_stats(o, deepcopy=1, version="1.3")')
#sys.exit(0)
print "XML len ",len(xml)
wtime = time()-t1
print "WRITE TIME ",wtime
print "NR OBJECTS ",stats.nr_objects
print "(wrote %.1f objects/second)" % (stats.nr_objects/wtime)
t1 = time()
xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)
#profile.run('xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)')
#sys.exit(0)
print "LOADED AS ",stats.pickle_version
print "NR OBJECTS ",stats.nr_objects
rtime = time()-t1
print "PARSE TIME ",rtime
print "(read %.1f objects/second)" % (stats.nr_objects/rtime)

# see how much of a speed penalty binary=1 gives
print "****** 1.3, gzip ******"
t1 = time()
#f = open('speed_out.xml','w')
xml, stats = xml_pickle.dumps_stats(o, binary=1, deepcopy=1, version="1.3")
#profile.run('xml,stats = xml_pickle.dumps_stats(o, deepcopy=1, version="1.3")')
#sys.exit(0)
print "XML len ",len(xml)
wtime = time()-t1
print "WRITE TIME ",wtime
print "NR OBJECTS ",stats.nr_objects
print "(wrote %.1f objects/second)" % (stats.nr_objects/wtime)
xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)
print "LOADED AS ",stats.pickle_version
print "NR OBJECTS ",stats.nr_objects
rtime = time()-t1
print "PARSE TIME ",rtime
print "(read %.1f objects/second)" % (stats.nr_objects/rtime)
