
from xml.dom.minidom import parseString
import re
import sys

# define True/False if this Python doesn't have them
try:
    a = True
except:
    True = 1
    False = 0

from gnosis.xml.xmlmap import *

# sanity check for testing purposes
def try_in_xml( uval ):
    "Try putting the Unicode string uval into an XML doc & parsing."
    
    xml = u'<?xml version="1.0" encoding="utf-8" ?>'
    xml += u'<H>' + uval + '</H>'

    #print [u for u in usplit(xml) if u >= u'\U00010000']

    try:
        parseString(xml.encode('utf-8'))
        return True # succeeded
    except:
        return False # failed

# --- test cases ---

bad_unicode = [
    # 0000-0008 is illegal
    u'abc\u0001def',
    # 000B-000C is illegal
    u'abc\u000cdef',
    # 000E-001F is illegal
    u'abc\u0015def',
    # D800-DBFF is illegal, unless it starts a 2-char sequence
    u'abc\ud900def',
    # DC00-DFFF is illegal, unless it ends a 2-char sequence
    u'abc\uDDDDdef',
    # FFFE-FFFF is illegal
    u'abc\ufffedef',
    # case of D800-DBFF at end of string (next to last segment of regex)
    u'abc\ud800',
    # case of DC00-DFFF at start of string (last segment of regex)
    u'\udc00'
    ]

good_unicode = [
    # 0009-000A is legal
    u'abc\u0009def\u000aghi',
    # 000D is legal
    u'abc\u000ddef',
    # 0020-D7FF is legal
    u'abc\u0020def\u8112ghi\ud7ffjkl',
    # E000-FFFD is legal
    u'abc\ue000def\uF123ghi\ufffdjkl',
    # U00010000 - U0010FFFF is legal
    u'abc\U00010000def\U00023456ghi\U00101234jkl'
    ]

if __name__ == '__main__':

    print "** BAD VALUES **"
    for u in bad_unicode:
        # print the unicode value, test legality, and sanity check by
        # putting it in an XML document & parsing it
        print "%-50s %8s %1d" % (repr(u), is_legal_xml(u), try_in_xml(u))

    print "\n** GOOD VALUES **"
    for u in good_unicode:
        # print the unicode value, test legality, and sanity check by
        # putting it in an XML document & parsing it
        print "%-50s %8s %1d" % (repr(u), is_legal_xml(u), try_in_xml(u))

    # an all-illegal string
    u = u'\u0000\u0005\u0008\u000b\u000c\u000e\u0010\u0019\u001f' + \
        u'\ud800\ud900\u0000\udc00\udd00\udfff\ufffe\uffff'

    print "\nTesting one char at a time ..."
    print repr(u)
    for c in usplit(u):
        # test as a char
        if is_legal_xml_char(c):
            raise "ERROR(1)"

        # test as a string
        if is_legal_xml(c):
            raise "ERROR(2)"

        # stick in an XML document to double-check the above
        # (have to exclude \u000d from test since it WILL parse
        # correctly, but is considered illegal -- see xmlmap.py '\r NOTE')
        if try_in_xml(c) != False and c != u'\u000d':
            raise "ERROR(3)"

    print "OK\n"

    # an all-legal string
    u = u'\u0009\u000a\u0020\u000d\u2345\ud7ff' + \
        u'\ue000\ue876\ufffd' + \
        u'\U00010000\U00012345\U00100000\U0010ffff'
    # subtle -- make sure it allows a handcoded 2-char sequence (this
    # is the case that forces usplit() to do a full pass even if \U is
    # stored as single chars)
    u += u'\ud800\udc00' 

    print repr(u)
    for c in usplit(u):
        # test as a char
        if not is_legal_xml_char(c):
            raise "ERROR(1)"

        # test as a string
        if not is_legal_xml(c):
            raise "ERROR(2)"

        # stick in an XML document to double-check the above
        if try_in_xml(c) != True:
            raise "ERROR(3)"

    print "OK"

