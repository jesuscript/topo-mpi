"""
Test things that extensions are not allowed to do.
"""

from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT, XMLPicklingError
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, \
     unregister_extension, ClassExtension

class Foo:
    def __init__(self,a):
        self.a = a

class Bar:
    def __init__(self,a):
        self.a = a

class Baz:
    def __init__(self,m):
        self.meta = m
        
class Foo2Bar(StackableExtension):

    def __init__(self):
        StackableExtension.__init__(self, "Foo2Bar")
        
    def pickle(self, obj):
        if not isinstance(obj, Foo):
            return self.ignore(obj)
        
        return (Bar(obj.a), None, {})

class BadClassExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "BadClassExt")

    def pickle(self, obj):
        if not isinstance(obj,Baz):
            return self.ignore(obj)
        
        metadata = {'aaa':obj.meta}
        return (obj, metadata, {})
    
register_extension(Foo2Bar())
register_extension(BadClassExt())

# first, a legal case to make sure extension works
f = Foo('Hello Foo!')
x = dumps(f,short_ids=1)

# this is illegal - the StackableExtension cannot return
# a mutated version of 'f' that contains self-referencing data
# (see DESIGN, etc.)
try:
    f = Foo(None)
    f.a = [1,2,f]
    x = dumps(f,short_ids=1)
    raise "ERROR" # that shouldn't have worked!
except XMLPicklingError:
    pass # ok

# a legal case of ClassExtension usage, to make sure its OK
b = Baz(123)
x = dumps(b,short_ids=1)
#print x

# an illegal case with self-referencing metadata
try:
    b = Baz('Hello')
    b.meta = b
    x = dumps(b,short_ids=1)
    raise "ERROR" # shouldn't have worked!
except XMLPicklingError:
    pass # ok

# nothing wrong with metadata containing self-refs to OTHER objects
l = [10,11,12]
b = Baz([l,l])
x = dumps(b,short_ids=1)
#print x

print "** OK **"


