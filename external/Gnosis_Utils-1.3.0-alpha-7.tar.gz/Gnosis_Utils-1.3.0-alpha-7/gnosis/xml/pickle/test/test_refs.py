from cStringIO import StringIO
import gnosis.xml.pickle as xml_pickle
from gnosis.pyconfig import pyconfig

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

class Foo(tuple): pass

f = Foo((4,5,6))
f.a = f

l = [1,2]
l.append(l)
l.append(f)
#print id(l),id(l[2]),id(f),id(l[3].a)
xml,st = xml_pickle.dumps_stats(l)
if st.nr_objects != 9:
    raise "ERROR"
#print xml

m,st = xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)
if st.nr_objects != 9:
    raise "ERROR"
#print id(m),id(m[2]),id(m[3]),id(m[3].a)

if id(m) != id(m[2]) or id(m[3]) != id(m[3].a):
    raise 'ERROR'

class A:																
    def __init__(self, x=0):										
        self.__parent__ = None								   
        self.x = x												
                                                                                
    def setParent(self, p):											
        self.__parent__ = p										

x				= A(1)													
x.y				= A(2)													
x.y.z			= A(3)													
x.y.z.setParent(x.y)

xml,st = xml_pickle.dumps_stats(x)
if st.nr_objects != 9:
    raise "ERROR"
#print xml
p,st = xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)
if st.nr_objects != 9:
    raise "ERROR"

if [x.x,x.y.x,x.y.z.x,x.y.z.__parent__.x] != \
   [p.x,p.y.x,p.y.z.x,p.y.z.__parent__.x]:
    raise "ERROR"

# this was inspired by two handcoded selfrefs in prev/ver_11/test/test_selfrefs.py,
# but tweaked to be even harder (1.2.x can't do this correctly)
class Foo: pass
class Bar(list): pass

f = Foo()
f.b = f # ref myself in <attr>
f.a = Bar([f]) # ref myself in <list> inside <attr>
f.a.append(f.a) # <list> refs self in items
f.a.z = f # <list> refs f through <attr>
f.a.y = f.a # <list> refs self through <attr>

#print id(f),id(f.b),id(f.a[0]),id(f.a.z),id(f.a.y),id(f.a),id(f.a[1])

xml,st = xml_pickle.dumps_stats(f,short_ids=1)
if st.nr_objects != 7:
    raise "ERROR"
#print xml
p,st = xml_pickle.loads_stats(xml, xml_pickle.SEARCH_NO_IMPORT, 1)
if st.nr_objects != 7:
    raise "ERROR"

#print id(p),id(p.b),id(p.a[0]),id(p.a.z),id(p.a.y),id(p.a),id(p.a[1])

if id(p.b) != id(p) or id(p.a[0]) != id(p) or \
   id(p.a.z) != id(p) or id(p.a.y) != id(p.a) or id(p.a) != id(p.a[1]):
    raise "ERROR"

print "** OK **"
