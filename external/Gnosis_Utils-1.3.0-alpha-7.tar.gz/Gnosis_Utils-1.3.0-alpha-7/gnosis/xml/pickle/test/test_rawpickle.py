"""
Test/demo of how rawpickles are affected by the allow_rawpickles flag.
"""

from gnosis.xml.pickle import dumps,loads,dumps_stats,loads_stats,is_replicant,\
     SEARCH_NO_IMPORT, add_class_to_store, replicant_info, SEARCH_STORE, SEARCH_NONE, \
     remove_class_from_store, XMLPicklingError, XMLUnpicklingError, SEARCH_ALL, NO_EXTENSIONS

from gnosis.xml.pickle.extras import object_slowcmp

# just import some class that I cannot pickle natively
import re

r = re.compile('abc',re.I)
try:
    # turn off builtin extensions (since they handle SREs now).
    # now, allow_rawpickles=0 by default, so this should not work
    x = dumps(r, extensions=NO_EXTENSIONS)
    raise "ERROR"
except XMLPicklingError:
    pass

# now, allow it
x = dumps(r,allow_rawpickles=1, extensions=NO_EXTENSIONS)
#print x

try:
    # allow_rawpickles=0 by default, so this should not work
    o = loads(x)
    raise "ERROR"
except XMLUnpicklingError:
    pass

# now, allow it
r2 = loads(x,allow_rawpickles=1)

# check result by comparing SHA-1 of objects
if not object_slowcmp(r, r2, allow_rawpickles=1):
    raise "ERROR"

print "** OK **"



