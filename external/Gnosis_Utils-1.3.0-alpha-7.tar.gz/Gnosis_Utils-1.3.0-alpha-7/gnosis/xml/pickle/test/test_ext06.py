"""
In this demo, a StackableExtension acts like sort
of a 'decorator', attaching the __doc__ string to the
XML stream the first time is sees a particular object.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, \
     unregister_extension
from gnosis.xml.pickle.getclass import get_class_from_name

class PyDocMaker(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'PyDoc')
        
        self.doc_cache = {}

    def make_docstring(self, obj):
        
        if hasattr(obj,'__module__'):
            name = obj.__module__ + '.'
        else:
            name = ''
            
        if hasattr(obj,'__name__'):
            name += obj.__name__
        elif hasattr(obj,'__class__'):
            name += obj.__class__.__name__
        else:
            name = repr(obj)

        nr = 70 - len(name)
        s = '\n  +--[%s]' % name + '-'*nr + '\n'
        lines = obj.__doc__.splitlines()
        lines = ['  | '+line for line in lines]
        txt = '\n'.join(lines)
        s += txt
        s += '\n  +' + '-'*74 + '\n'
        return s
    
    def pickle(self, obj):
        if not hasattr(obj, '__doc__') or obj.__doc__ == None or \
           self.doc_cache.has_key(id(obj.__doc__)):
            return self.ignore(obj)
        
        txt = self.make_docstring(obj)
        self.doc_cache[id(obj.__doc__)] = 1
        #print "RETURNING ",obj,txt
        return (obj, txt, {})	

    def unpickle(self, obj, coredata, propmap):
        # I didn't do anything to obj in pickle(), so
        # just return it as-is here
        return obj
    
register_extension(PyDocMaker())

class Foo:
    """
    Here is some documentation
    for the class Foo. Is has a
    very complicated interface that
    will take a lot of text to explain.
    """
    pass

import gnosis.xml.xmlcoder as xmlcoder
obj = [(chr,unicode),repr,Foo,Foo(),xmlcoder.encode_as]
try:
    import zlib
    obj.append(zlib.compress)
except: pass

# 'deepcopy=1' is just for aesthetics -- omits ids (no refs in this demo).
# 'prefer_cdata=1' means I want <![CDATA (where possible) instead of
# XML body-escaping, to preserve readability of text.
x = xml_pickle.dumps(obj,deepcopy=1,prefer_cdata=1)
print "THE XML "
print x

#xml_pickle.loads(x)

print "** OK **"
