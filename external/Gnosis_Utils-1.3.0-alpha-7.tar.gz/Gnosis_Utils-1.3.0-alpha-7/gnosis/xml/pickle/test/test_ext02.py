"""
Demo of a StackableExtension to handle regexps.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.extensions import StackableExtension, register_extension

import re
re_type = type(re.compile('aaa'))

class Ext_RegexToString(StackableExtension):
    "Turn a compiled regex into type='string'"
    def __init__(self):
        StackableExtension.__init__(self, "regex2str")
        
        self.flags_list = [(re.I,'I'),(re.L,'L'),(re.U,'U'),(re.M,'M'),
                           (re.S,'S'),(re.X,'X')]
        
    def pickle(self, obj):
        if type(obj) != re_type:
            return self.ignore(obj)
        
        # turn flags into a verbose string
        flags = []
        for f,s in self.flags_list:
            if obj.flags & f:
                flags.append( s )

        if len(flags):
            return (obj.pattern, None, {'flags': ','.join(flags)})
        else:
            return (obj.pattern, None, {})
    
    def unpickle(self, obj, coredata, propmap):
        flag = 0

        # split flag string
        flags = propmap.get('flags','').split(',')

        for f in flags:
            for g in self.flags_list:
                if g[1] == f:
                    flag += g[0]

        #print flag
        
        return re.compile(obj,flag)
    
register_extension(Ext_RegexToString())

# test w/no flags
r1 = re.compile(u'bbb.+')
o = [1,2,r1]
#print o[2].pattern, o[2].flags

x = xml_pickle.dumps(o,short_ids=1)
#print x
p = xml_pickle.loads(x)
#print p[2].pattern, p[2].flags

# check
if p[2].pattern != o[2].pattern or \
   p[2].flags != o[2].flags:
    raise "ERROR"

# test w/flags
r1 = re.compile(u'bbb.+',re.I|re.M|re.L)
o = [1,2,r1]
#print o[2].pattern, o[2].flags

x = xml_pickle.dumps(o,short_ids=1)
#print x
p = xml_pickle.loads(x)
#print p[2].pattern, p[2].flags

# check
if p[2].pattern != o[2].pattern or \
   p[2].flags != o[2].flags:
    raise "ERROR"

print "** OK **"
