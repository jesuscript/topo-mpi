"""
test_randprof.py - Like test_grind.py, but setup for profiling instead.

Will restart where it last stopped if interrupted by Ctrl-C, or a crash.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dump_stats, load_stats, dumps, loads, dump, load, SEARCH_NONE, \
     SEARCH_NO_IMPORT
import random, os, re
from xml.parsers.expat import ExpatError
from stat import *
from time import time
from funcs import unlink

import sys
sys.path.insert(0,'.')
from randstuff import rand_obj

def finish_state():
    dump(open('grindseed.xml','w'), random.getstate())

def start_state():
    if not os.path.isfile('grindseed.xml'):
        finish_state()

    # the see should just be a plain list, so restrict search
    seed = load(open('grindseed.xml','r'),SEARCH_NONE,allow_replicants=0)
    random.setstate(seed)

def compare_objs(o1, o2):
    from gnosis.xml.pickle.extras import object_slowcmp
    
    if not object_slowcmp(o1, o2):
        raise Exception("Objects don't match!")

import profile

def run_loop():
    start_state()

    # print a 'run ID' - a little visual cue that the runs are progressing,
    # and/or that the runs are being repeated when there is an error, or
    # if user hit Ctrl-C during a run.
    print 'Run ID: %X' % (random.randint(0,2**32))

    # write XML to file for reference in case test crashes
    return rand_obj(4) # create object of (up to) depth 4
    f = open('randdump.xml','w')
    # do timing stats
    t1 = time()
    st = dump_stats(f, o)
    dt = time()-t1 + 1e-6
    del f # ensure file is closed
    print '# objects: %d (wrote %.1f/sec), XML size: %d' % \
          (st.nr_objects,st.nr_objects/dt,os.stat('randdump.xml')[ST_SIZE])
    
    try:
        f = open('randdump.xml','r')
        t1 = time()
        # should be no replicants, so explicitly disallow (better to raise
        # an error at the site of replicant creation, for debugging purposes)
        o2,st = load_stats(f,SEARCH_NO_IMPORT,allow_replicants=0)
        dt = time()-t1 + 1e-6
        print '# objects: %d (read %.1f/sec)' % \
              (st.nr_objects,st.nr_objects/dt)

        # XML dump of orig & copy should match
        compare_objs(o,o2)
        print "XML compared OK"
        
    except ExpatError, exc:
        # get the line# & offset from exception and print bad line,
        # so it can be captured to file, etc.
        print "ERROR ",exc
        print exc.lineno, exc.offset
        del f
        f = open('randdump.xml','r')
        n = exc.lineno
        while n > 0:
            line = f.readline()
            n -= 1
            
        print "LINE ",line
        print "REPR LINE ",repr(line)
        print "CHAR ",repr(line[exc.offset])
        s = exc.offset - 5
        if s < 0:
            s = 0

        print "Section: ",repr(line[s:s+10])
        
        sys.exit(1)

    # update random seed after tests suceed.
    # else, the same test will  be run again next time.
    finish_state()

def sanity():
    # complex numbers have to be disallowed as keys, since they
    # aren't sortable, so do a quickie test here for sanity to
    # show they are OK
    d = {1.342+8.454j: 'hello', 89.435-3984.454j: 'world'}
    o = {443.323-8234.323j: d}
    xml = dumps(o)
    o2 = loads(xml)
    if o != o2:
        raise "ERROR"

    print "* sanity check ok *"
    
sanity()

# can hit Ctrl-C whenever to stop test and it will continue
# at the same place the next time you run.
i = 1
while 1:
    print "Loop %d" % i
    run_loop()
    i += 1

unlink('randdump.xml')

