"""
A 'null' SAX parser that verbosely prints event information.
"""

__author__ = ['Frank McIngvale <frankm@hiwaay.net>']

from xml.sax.expatreader import ExpatParser
from xml.sax.handler import ContentHandler, ErrorHandler
from xml.sax.xmlreader import InputSource
from StringIO import StringIO

class saxdemo_parser(ContentHandler):
    def __init__(self):
        ContentHandler.__init__(self)

    #
    # The ContentHandler interface
    #
    def setDocumentLocator(self, locator):
        print "setDocumentLocator"
        self.locator = locator

    def showloc(self):
        s = 'At %s, ' % (self.locator.getPublicId() or self.locator.getSystemId())
        s += "line=%d, col=%d" % (self.locator.getLineNumber(),
                                             self.locator.getColumnNumber())
        print s
        
    def startDocument(self):
        self.showloc()
        print "startDocument"
        
    def endDocument(self):
        self.showloc()
        print "endDocument"
        
    def startElement(self,name,attrs):
        self.showloc()
        print "startElement <%s>, attrs=%s" % (name,str(attrs._attrs))
        
    def startElementNS(self, name, qname, attrs):
        self.showloc()
        print "startElementNS name=%s, qname=%s, attrs=%s" % \
              (name,qname,str(attrs))
        
    def endElement(self,name):
        self.showloc()
        print "endElement </%s>" % name
        
    def endElementNS(self, name, qname):
        self.showloc()
        print "endElementNS name=%s, qname=%s" % (name,qname)
        
    def characters(self,content):
        self.showloc()
        print "characters=%s" % repr(content)
        
    def ignorableWhitespace(self, whitespace):
        self.showloc()
        print "ignorableWhitespace=%s" % repr(whitespace)
        
    def processingInstruction(self, target, data):
        self.showloc()
        print "processingInstruction target=%s, data=%s" % (target,data)
        
    def skippedEntity(self, name):
        self.showloc()
        print "skippedEntity name=%s" % name
        
    def startPrefixMapping(self, prefix, uri):
        self.showloc()
        print "startPrefixMapping prefix=%s, uri=%s" % \
              (prefix,uri)
        
    def endPrefixMapping(self, prefix):
        self.showloc()
        print "endPrefixMapping prefix=%s" % prefix
        
    #
    # The ErrorHandler interface
    #
    def error(self,exception):
        print "** ERROR **", str(exception)
        raise exception

    def fatalError(self,exception):
        print "** FATAL ERROR **", str(exception)
        raise exception

    def warning(self,exception):
        print "** WARNING **", str(exception)
        raise exception

    #
    # The EntityResolver interface
    #
    def resolveEntity(self,publicId,systemId):
        print "resolveEntity publicId=%s, systemId=%s" % \
              (str(publicId),str(systemId))
        
        inp = InputSource()
        inp.setByteStream(StringIO(""))
        return inp

def parse(fileobj):
    
    e = ExpatParser()
    m = saxdemo_parser()
    e.setContentHandler(m)
    e.setErrorHandler(m)
    e.setEntityResolver(m)

    e.parse(fileobj)

import sys

parse(open(sys.argv[1],'r'))

