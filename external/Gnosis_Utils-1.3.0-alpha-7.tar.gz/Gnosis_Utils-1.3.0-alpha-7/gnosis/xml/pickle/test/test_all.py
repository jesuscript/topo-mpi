
import os,sys,string
from time import time
from gnosis.xml.pickle.prev.ver_11.util import enumParsers
import funcs
from gnosis.pyconfig import pyconfig
from funcs import unlink, touch

# make sure I'm in the 'test' directory -- this allows the user to run test_all.py from
# the toplevel (or anywhere else)
path,name = os.path.split(sys.argv[0])
if os.path.isdir(path):
    os.chdir(path)
    
maintests = """
api01
api02
api03
backtypes_r
catalog
circular
classify
comploop
ext01
ext02
ext03
ext05
ext06
ext08
ext09
ext10
ext11
protorules
ref01
ref02
replicants
"""

# these really belong in xml.test, but are so important that I want
# to make sure they're part of the main regression suite
maintests += """
blob_coders
xml_legality
"""

def echof(filename,line):
    "Add a line to the named file."
    if os.path.isfile(filename):
        f = open(filename,'a')
    else:
        f = open(filename,'w')

    f.write(line+'\n')

def pechof(filename,line):
    "Print a line & add to named file."
    print line
    echof(filename, line)
    
# set output filename, and remove any existing file
tout = 'TESTS.OUT-%s-%s' % (sys.platform,sys.version.split()[0])
unlink(tout)
touch(tout)

# create list of tests
tests = []
for name in string.split(maintests):
    tests.append( 'test_%s.py' % name )

if pyconfig.Have_GeneratorExpressions():
    tests.append( 'test_assumptions.py' )
else:
    pechof(tout, "** OMITTING test_assumptions.py **")

if pyconfig.Have_ObjectClass():
    # Py < 2.2 have a bug that prevent this from working
    tests.append( 'test_badstring.py' )
    # these need newstyle objs
    tests.append('test_ext04.py')
    tests.append('test_newargs.py')
    tests.append('test_refs.py')
    tests.append('test_safe_read.py')
    tests.append('test_loop.py')
else:
    pechof(tout, "** OMITTING test_badstring.py **")
    pechof(tout, "** OMITTING test_ext04.py **")
    pechof(tout, "** OMITTING test_ext_mintypes.py **")
    pechof(tout, "** OMITTING test_newargs.py **")
    pechof(tout, "** OMITTING test_refs.py **")
    pechof(tout, "** OMITTING test_safe_read.py **")
    pechof(tout, "** OMITTING test_loop.py **")

if pyconfig.Have_Module('re'):
    tests.append('test_rawpickle.py')
else:
    pechof(tout, "** OMITTING test_rawpickle.py **")

if pyconfig.Have_Module('numpy'):
    tests.append('test_numpy.py')
else:
    pechof(tout, "** OMITTING test_numpy.py **")

if pyconfig.Have_Module('mx'):
    tests.append('test_mx.py')
else:
    pechof(tout, "** OMITTING test_mx.py **")
    
# sanity check the test harness before starting
def check_harness():
    # try to redirect stderr to a file so that the intentional
    # exceptions in the "fail" tests below won't freak out the user
    if os.name == 'posix':
        outstr = '2>&1 > harness_check.out'
    elif os.name == 'nt':
        outstr = '2>1> harness_check.out'
    else:
        # don't know how to redirect stderr here ...
        outstr = '> harness_check.out'
        
    # known "pass" tests
    for good in ['test_pass_1.py','test_pass_2.py','test_pass_3.py']:
        r = os.system('%s %s %s' % (sys.executable,good,outstr))
        if r != 0:
            pechof(tout,"****** Harness test failed ******")
            sys.exit(1)

    # known "fail" tests
    print "***************** INGORE EXCEPTIONS BETWEEN THESE LINES *****************"	
    for bad in ['test_fail_exit.py','test_fail_raise_1.py',
                'test_fail_raise_2.py','test_fail_raise_3.py']:
        r = os.system('%s %s %s' % (sys.executable,bad,outstr))
        if r == 0:
            pechof(tout,"****** Harness test failed ******")
            sys.exit(1)

    print "***************** INGORE EXCEPTIONS BETWEEN THESE LINES *****************"
    
    unlink('harness_check.out')

import gnosis.version
pechof(tout,"*** Running all xml.pickle tests:")
pechof(tout,"    Gnosis Utils %s" % gnosis.version.VSTRING)
pechof(tout,"    Python %s" % str(sys.version))

# check test harness
check_harness()
pechof(tout,"Sanity check: OK")

t1 = time()

for test in tests:
    print "Running %s" % test
    echof(tout,"** %s %s **" % (sys.executable,test))
    r = os.system("%s %s >> %s"%(sys.executable,test,tout))
    if r != 0:
        pechof(tout,"***ERROR***")
        sys.exit(1)

pechof(tout,"%.1f seconds" % (time()-t1))

pechof(tout,"***** ALL TESTS COMPLETED *****")


