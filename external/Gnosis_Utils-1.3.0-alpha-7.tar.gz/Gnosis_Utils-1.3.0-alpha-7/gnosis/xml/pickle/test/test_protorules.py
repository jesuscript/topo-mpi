"""
Test that the various pickle protocol rules are followed correctly
(specifically, rules re: __getstate__, __setstate__, __getinitargs__).

See also test_newargs for a continuation of this.
"""

__author__ = ['Frank McIngvale <frankm@hiwaay.net>']

from gnosis.xml.pickle import dumps,loads,dumps_stats,loads_stats,is_replicant,\
     SEARCH_NO_IMPORT, add_class_to_store, replicant_info, SEARCH_STORE, SEARCH_NONE, \
     remove_class_from_store, XMLUnpicklingError, SEARCH_ALL

from gnosis.pyconfig import pyconfig
import pickle

ORDER = ''

def add(s):
    global ORDER
    ORDER += s

Vals0 = {'a':111,'b':222,'c':333}
class ObjGetstate0:
    "getstate without setstate (state must be dict)"
    def __init__(self):
        add('0i')
        self.zzz = 'not pickled'
        
    def __getstate__(self):
        add('0g')
        return Vals0

    def check(self):
        if self.__dict__ != Vals0:
            raise "ERROR"

Vals1 = {'a':12.34,'b':34.56,'c':78.91}
class ObjGetstate1:
    "setstate without getstate (state must be dict)"
    
    def __init__(self):
        add('1i')
        self.__dict__.update(Vals1)

    def __setstate__(self,state):
        add('1s')
        if state != Vals1:
            raise "ERROR"

Vals2 = {'a':(10,11,12), 222: 'hello', 12.34: [50,60,70]}
class ObjGetstate2:
    "getstate AND setstate, with state==dict"
    def __init__(self):
        add('2i')
        
    def __getstate__(self):
        add('2g')
        return Vals2

    def __setstate__(self,state):
        add('2s')
        if state != Vals2:
            raise "ERROR"

Vals3 = [(111,222,333),'hello',{'state': 444.333}]
class ObjGetstate3:
    "getstate AND setstate, with state != dict"
    def __init__(self):
        add('3i')
        
    def __getstate__(self):
        add('3g')
        return Vals3

    def __setstate__(self,state):
        add('3s')
        if state != Vals3:
            raise "ERROR"
        
class ObjGetstate4:
    "getstate without setstate, and self-referencing state"
    def __init__(self):
        add('4i')
        
    def __getstate__(self):
        add('4g')
        return {'aaa': self, 'bbb': (1,self), 'ccc': {'xxx':233,'yyy':self}}

    def check(self):
        # check self-refs
        if id(self.aaa) != id(self) or \
           id(self.bbb[1]) != id(self) or \
           id(self.ccc['yyy']) != id(self):
              raise "ERROR"
    
class ObjGetstate5:
    "getstate AND setstate, with state != dict and self-referencing state"
    def __init__(self):
        add('5i')
        
    def __getstate__(self):
        add('5g')
        return [self,(1,self),{'aaa':233,'bbb':self}]

    def __setstate__(self,state):
        add('5s')
        # check self-refs
        if id(state[0]) != id(self) or \
           id(state[1][1]) != id(self) or \
           id(state[2]['bbb']) != id(self):
            raise "ERROR"		

def do_test(dump_func, load_func):
    
    import re, sys

    o = ObjGetstate0()
    #print dir(o)
    x = dump_func(o)
    # should *NOT* have '#state' attr, since no __setstate__
    if re.search('#state',x):
        raise "ERROR"
    #print x
    p = load_func(x)
    p.check()

    o = ObjGetstate1()
    x = dump_func(o)
    #print x
    # should have '#state' attr, since __setstate__ present
    if x[:5] == '<?xml' and not re.search('#state',x):
        raise "ERROR"
    p = load_func(x) # self-test while loading

    o = ObjGetstate2()
    x = dump_func(o)
    #print x
    # should have '#state' attr, since __setstate__ present
    if x[:5] == '<?xml' and not re.search('#state',x):
        raise "ERROR"
    p = load_func(x) # self-test while loading

    o = ObjGetstate3()
    x = dump_func(o)
    #print x
    # should have '#state' attr, since __setstate__ present
    if x[:5] == '<?xml' and not re.search('#state',x):
        raise "ERROR"
    p = load_func(x) # self-test while loading

    o = ObjGetstate4()
    x = dump_func(o)
    #print x
    # should NOT have '#state' attr, since no __setstate__
    if x[:5] == '<?xml' and re.search('#state',x):
        raise "ERROR"
    p = load_func(x)
    p.check()

    o = ObjGetstate5()
    x = dump_func(o)
    # should have '#state' attr, since __setstate__ present
    if x[:5] == '<?xml' and not re.search('#state',x):
        raise "ERROR"
    #print x
    p = load_func(x) # self-test while loading

    # check that everything was called in the right order
    if ORDER != '0i0g1i1s2i2g2s3i3g3s4i4g5i5g5s':
        raise "ERROR"

    #print ORDER

def dumpfunc_xml(o):
    # sanity check the sanity check :-)
    x = dumps(o)	
    if x[:5] != '<?xml':
        raise "ERROR"

    return x

def loadfunc_xml(x):
    return loads(x,SEARCH_NO_IMPORT)

def dumpfunc_p(o): return pickle.dumps(o)
def loadfunc_p(s): return pickle.loads(s)

# test with xml.pickle
do_test(dumpfunc_xml, loadfunc_xml)
ORDER = ''
# test with standard pickle to make we agree on rules
do_test(dumpfunc_p, loadfunc_p)


print "** OK **"


  	
