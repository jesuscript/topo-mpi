
# One of each Container, in dicts

from gnosis.pyconfig import pyconfig

#==============================================================
# Basic Containers without attributes
#==============================================================
Containers = {
    'list': [1,2,3],
    'tuple': (4,5,6),
    'dictionary': {'a':1,'b':2}
    }

if pyconfig.Have_BuiltinSet():
    Containers.update( {
        'set': set([10,11,12]),
        'frozenset': frozenset([100,110,120])
        })						   

#==============================================================
# Subclassed Containers without attributes
#==============================================================
if pyconfig.Have_ObjectClass():
    class SList_noattr(list): pass
    class STuple_noattr(tuple): pass
    class SDict_noattr(dict): pass
    
if pyconfig.Have_BuiltinSet():
    class SSet_noattr(set): pass
    class SFrozenSet_noattr(frozenset): pass

SubclassContainers_NoAttr = {}

if pyconfig.Have_ObjectClass():
    SubclassContainers_NoAttr.update( {
        'Scontainer_list_noattr': SList_noattr([2,3,4]),
        'Scontainer_tuple_noattr': STuple_noattr((10,11,12)),
        'Scontainer_dict_noattr': SDict_noattr({'x':10,'y':11,'z':12})
        })

if pyconfig.Have_BuiltinSet():
    SubclassContainers_NoAttr.update( {
        'Scontainer_set_noattr': SSet_noattr([1,2,3]),
        'Scontainer_frozenset_noattr': SFrozenSet_noattr([1,2,3])	
        })

#==============================================================
# Subclassed Containers with attributes
#==============================================================
if pyconfig.Have_ObjectClass():
    class SList_attr(list):
        def __init__(self,l):
            list.__init__(self,l)
            self.s = 'slist_attr subattr'

    class STuple_attr(tuple):
        def __init__(self,t):
            tuple.__init__(self,t)
            self.s = 'stuple_attr subattr'

    class SDict_attr(dict):
        def __init__(self,d):
            dict.__init__(self,d)
            self.s = 'sdict_attr subattr'

if pyconfig.Have_BuiltinSet():
    class SSet_attr(set):
        def __init__(self,t):
            set.__init__(self,t)
            self.s = 'sset_attr subattr'				

    class SFrozenSet_attr(frozenset):
        def __init__(self,t):
            frozenset.__init__(self,t)
            self.s = 'sfrozenset_attr subattr'				

SubclassContainers_Attr = {}

if pyconfig.Have_ObjectClass():
    SubclassContainers_Attr.update( {
        'Scontainer_list_attr': SList_attr([2,3,4]),
        'Scontainer_tuple_attr': STuple_attr((10,11,12)),
        'Scontainer_dict_attr': SDict_attr({'x':10,'y':11,'z':12})
        })

if pyconfig.Have_BuiltinSet():
    SubclassContainers_Attr.update( {
        'Scontainer_set_attr': SSet_attr([8,9,10]),
        'Scontainer_frozenset_attr': SFrozenSet_attr([18,19,20])		
        })
