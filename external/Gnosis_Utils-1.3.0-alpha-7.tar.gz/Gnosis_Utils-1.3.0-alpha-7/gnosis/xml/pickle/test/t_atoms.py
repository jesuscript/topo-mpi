
# One of each Atom in dicts

from gnosis.pyconfig import pyconfig
from t_classes import *

def TestFunction(): pass

if not pyconfig.Have_TrueFalse():
    True = 1
    False = 0
    
#-------------------------------------------
# Atoms - single data item with no attrs
#-------------------------------------------
Atoms = {
    'atom_int': 21,
    'atom_long': 100L,
    'atom_float': 12.34,
    'atom_complex': 56+78j,
    'atom_string': 'a string',
    'atom_unicode': u'a unicode',
    'atom_builtin_class': float,
    
    # since these are seperate 'uniq' types to xml.pickle
    'atom_bool_true': True,
    'atom_bool_false': False,	
    'atom_none': None,

    # two kinds of functions
    'atom_function': TestFunction,
    'atom_builtin_function': chr
    }

# three styles of classes
Atoms['atom_old_class'] = SampleOldClass
if pyconfig.Have_ObjectClass():
    Atoms['atom_new_class'] = SampleNewClass

if pyconfig.Have_Slots():
    Atoms['atom_slots_class'] = SampleSlotsClass
    
#-------------------------------------------------------------------
# SubclassAtoms_NoAttr: subclassed from Atoms, but without attrs
#-------------------------------------------------------------------
if pyconfig.Have_ObjectClass():
    class SInt_noattr(int): pass
    class SLong_noattr(long): pass
    class SFloat_noattr(float): pass
    class SComplex_noattr(complex): pass
    class SString_noattr(str): pass
    class SUnicode_noattr(unicode): pass
    # no subclasses of classtype
    # no subclasses from bool
    # no subclasses of None
    # no subclasses of functiontype

SubclassAtoms_NoAttr = {}

if pyconfig.Have_ObjectClass():
    SubclassAtoms_NoAttr.update({
        'Satom_int_noattr': SInt_noattr(123),
        'Satom_long_noattr': SLong_noattr(4567L),
        'Satom_float_noattr': SFloat_noattr(56.789),
        'Satom_complex_noattr': SComplex_noattr(23+45j),
        'Satom_string_noattr': SString_noattr('Sstring_noattr core'),
        'Satom_unicode_noattr': SUnicode_noattr(u'Sunicode_noattr core')
        })

#--------------------------------------------------------------
# SubclassAtoms_Attr: subclassed from Atoms, WITH attrs
#--------------------------------------------------------------

if pyconfig.Have_ObjectClass():
    class SInt_attr(int):
        def __init__(self,i):
            int.__init__(self,i)
            self.s = 'sint_attr subattr'

    class SLong_attr(long):
        def __init__(self,l):
            long.__init__(self,l)
            self.s = 'slong_attr subattr'

    class SFloat_attr(float):
        def __init__(self,f):
            float.__init__(self,f)
            self.s = 'sfloat_attr subattr'

    class SComplex_attr(complex):
        def __init__(self,c):
            complex.__init__(self,c)
            self.s = 'scomplex_attr subattr'

    class SString_attr(str):
        def __init__(self,s):
            str.__init__(self,s)
            self.s = 'sstring_attr subattr'

    class SUnicode_attr(unicode):
        def __init__(self,u):
            unicode.__init__(self,u)
            self.s = 'sstring_attr subattr'										

SubclassAtoms_Attr = {}

if pyconfig.Have_ObjectClass():
    SubclassAtoms_Attr.update({	
        'Satom_int_attr': SInt_attr(123),
        'Satom_long_attr': SLong_attr(4567L),
        'Satom_float_attr': SFloat_attr(56.789),
        'Satom_complex_attr': SComplex_attr(23+45j),
        'Satom_string_attr': SString_attr('Sstring_attr core'),
        'Satom_unicode_attr': SUnicode_attr('Sunicode_attr core')
        })
