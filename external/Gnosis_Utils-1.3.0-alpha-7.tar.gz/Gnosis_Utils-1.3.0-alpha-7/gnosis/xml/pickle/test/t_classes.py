
# Some sample classes

from gnosis.pyconfig import pyconfig

SampleClasses = {}

class SampleOldClass: pass

SampleClasses['SampleOldClass'] = SampleOldClass

if pyconfig.Have_ObjectClass():
    class SampleNewClass(object): pass
    
    SampleClasses['SampleNewClass'] = SampleNewClass
    
if pyconfig.Have_Slots():
    class SampleSlotsClass(object):
        # fixed slots only
        __slots__ = ('aaa','bbb','ccc')

    SampleClasses['SampleSlotsClass'] = SampleSlotsClass
    
    class SampleSlotsDictClass(object):
        # fixed plus dynamic attrs
        __slots__ = ('aaa','bbb','ccc','__dict__')

    SampleClasses['SampleSlotsDictClass'] = SampleSlotsDictClass		
    
