
from cStringIO import StringIO
from gnosis.xml.pickle import XMLUnpicklingError, SEARCH_STORE, \
     SEARCH_NO_IMPORT, dumps, loads
import gnosis.xml.pickle.objmodel as objmodel
import sys
import gnosis.xml.pickle as xml_pickle

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

def testobj(obj):
    print "-------- 1.1 -------------"
    #print xml_pickle.dumps(obj)
    print "-------- 1.3 -------------"
    xml = dumps(obj)
    print xml
    #sio = StringIO(xml)
    o2 = loads(xml,SEARCH_NO_IMPORT)
    print "ORIG ",obj, "UNPICKLED ",o2
    print objmodel.get_data_attrs(obj)
    print objmodel.get_data_attrs(o2)

o = [1,2,3]
testobj(o)

o = (4,5,6)
testobj(o)

o = ['aaa','bbb','ccc']
testobj(o)

o = [u'aaa',u'bbb',u'ccc']
testobj(o)

o = {'aaa':123, 'bbb':456, 'ccc':789}
testobj(o)

o = (((1,2,3),(4,5,6),(7,8,9)),
     ((10,11,12),(13,14,15),(16,17,18)))
testobj(o)

class Foo: pass

f = Foo()
f.a = (1,2,3)
f.b = [1,2,3]
f.c = {'a':1,'b':2,'c':3}

testobj(f)

class Foo2(object): pass

f = Foo2()
f.a = (1,2,3)
f.b = [1,2,3]
f.c = {'a':1,'b':2,'c':3}

testobj(f)

class Foo3(object): __slots__ = ('a','b','c')

f = Foo3()
f.a = (1,2,3)
f.b = [1,2,3]
f.c = {'a':1,'b':2,'c':3}

testobj(f)


print dumps([1,2,3,4])
print dumps([])

l = [1,2]
l.append(l)
testobj(l)

class MyList(list): pass
class MyTuple(tuple): pass

l = MyList([1,2])
l.append(l)

# xml.pickle 1.1 can't handle this ...
t = MyTuple([4,5,6])
t.a = t
l.append(t)

testobj(l)

class Foo(object): pass

f = Foo()
f.a = f
f.b = f
f.c = Foo()
f.c.a = f

xml = dumps(f)
o = loads(xml,SEARCH_NO_IMPORT)
print id(f),id(f.a),id(f.b),id(f.c.a)

xml = dumps(Foo)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(testobj)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(object)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(chr)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(None)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(False)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(True)
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps('a simple attr string')
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps('a simple attr string with &, < and >')
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps('plain ascii with a tab here->\t<-here')
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(u'a simple unicode string with &, < and >')
print xml
print loads(xml,SEARCH_NO_IMPORT)

xml = dumps(u'some \u0019 bad \u0001 XML \ud800 values')
print xml
print repr(loads(xml,SEARCH_NO_IMPORT))

xml = dumps(u'some good \U00101000 XML \U00101234 values')
print xml
print repr(loads(xml,SEARCH_NO_IMPORT))

import re

xml = dumps(re.compile('aaa'),allow_rawpickles=1)
print xml
print repr(loads(xml,SEARCH_NO_IMPORT,allow_rawpickles=1))

xml = dumps(object())
print xml
print repr(loads(xml,SEARCH_NO_IMPORT))

print "** OK **"





