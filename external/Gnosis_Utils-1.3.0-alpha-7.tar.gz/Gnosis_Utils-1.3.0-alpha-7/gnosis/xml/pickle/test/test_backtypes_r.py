#
# Unpickle XML from test_backtypes_w and check results
#
# For the best test, test_backtypes_w should be run with
# the most recent Python available, then run test_backtypes_r
# with older Pythons to make sure they do something sensible.
#

from gnosis.xml.pickle import load, SEARCH_NO_IMPORT
from gnosis.pyconfig import pyconfig
import t_containers
from gnosis.xml.pickle.replicants import replicant_info, is_replicant

OK = 0

print "LOAD"
plist = load(open('backtypes.xml','r'),SEARCH_NO_IMPORT)
print "DONE"

if pyconfig.Have_ObjectClass():
    # list
    l = plist[0]
    if l.__class__ != t_containers.SList_noattr or \
       l[:3] != [1,2,3] or id(l[3]) != id(l):
        raise "ERROR"

    OK += 1
    
    # tuple
    t = plist[1]
    if t.__class__ != t_containers.STuple_noattr or \
       t[:] != (11,12,13):
        raise "ERROR"

    OK += 1
    
    # dict
    d = plist[2]
    if d.__class__ != t_containers.SDict_noattr or \
       d['a'] != 111 or d['b'] != 222 or id(d) != id(d['c']):
        raise "ERROR"

    OK += 1
    
    # list+attr
    l = plist[3]
    if l.__class__ != t_containers.SList_noattr or \
       l[:3] != [123,456,789] or l.aaa != 'abc' or l.bbb[:3] != ['d','e','f'] or \
       id(l) != id(l[3]) or id(l) != id(l.bbb[3]):
        raise "ERROR"

    OK += 1
    
    # tuple+attr
    t = plist[4]
    if t.__class__ != t_containers.STuple_noattr or \
       t[:] != (1.2,3.4,5.6) or t.xxx[:2] != [1+2j,3+4j] or \
       id(t) != id(t.xxx[2]) or id(t) != id(t.yyy) or \
       id(t.zzz) != id(t.xxx):
        raise "ERROR"

    OK += 1
    
    # dict+attr
    d = plist[5]
    if d.__class__ != t_containers.SDict_noattr or \
       d['x'] != 'aaa' or d['y'] != ('a','b','c') or \
       id(d) != id(d['z']) or d.aaa != 'def' or \
       d.bbb[:2] != [1,2] or id(d) != id(d.bbb[2]):
        raise "ERROR"

    OK += 1

# see if this Python has builtin set/frozenset

if pyconfig.Have_BuiltinSet():
    # set
    s = plist[6]
    if s.__class__ != t_containers.SSet_noattr or \
       not 234 in s or not 4.56 in s or not 71+23j in s or \
       len(list(s)) != 3:
        raise "ERROR"

    OK += 1
    
    # set+attr
    s = plist[7]
    if s.__class__ != t_containers.SSet_noattr or \
       not 345 in s or not 5.67 in s or not 91+23j in s or \
       len(list(s)) != 3 or \
       s.aaa != 'zyx' or s.bbb[:3] != ('r','s','t') or \
       id(s) != id(s.bbb[3]):
        raise "ERROR"

    OK += 1
    
    # frozenset
    s = plist[8]
    if s.__class__ != t_containers.SFrozenSet_noattr or \
       not 456 in s or not 5.67 in s or not 11+23j in s:
        raise "ERROR"

    OK += 1
    
    # frozenset+attr
    s = plist[9]
    if s.__class__ != t_containers.SFrozenSet_noattr or \
       not 567 in s or not 6.78 in s or not 1+23j in s or \
       s.aaa != '.zyx' or s.bbb[:3] != ('.r','.s','.t') or \
       id(s) != id(s.bbb[3]):
        raise "ERROR"		

    OK += 1

else:
    # Running on a Python w/out set/frozenset, so all these
    # should be replicants. Check that the replicant class
    # matches the expected name, check that __coredata__ holds the
    # coredata, and check attributes like above.
    
    # set (replicant)
    s = plist[6]
    if not is_replicant(s):
        raise "ERROR"
    
    info = replicant_info(s)
    # make sure it preserved the class info
    if info != ('set','t_containers','SSet_noattr'):
        raise "ERROR"
    # coredata in __coredata__
    if 234 not in s.__coredata__ or 4.56 not in s.__coredata__ or \
       71+23j not in s.__coredata__ or len(s.__coredata__) != 3:
        raise "ERROR"

    OK += 1

    # set+attr (replicant)
    s = plist[7]
    if not is_replicant(s):
        raise "ERROR"
    info = replicant_info(s)
    if info != ('set','t_containers','SSet_noattr') or \
       not 345 in s.__coredata__ or not 5.67 in s.__coredata__ or \
       not 91+23j in s.__coredata__ or len(s.__coredata__) != 3 or \
       s.aaa != 'zyx' or s.bbb[:3] != ('r','s','t') or \
       id(s) != id(s.bbb[3]):
        raise "ERROR"

    OK += 1

    # frozenset
    s = plist[8]
    if not is_replicant(s):
        raise "ERROR"
    info = replicant_info(s)
    if info != ('frozenset','t_containers','SFrozenSet_noattr') or \
           not 456 in s.__coredata__ or not 5.67 in s.__coredata__ or \
           not 11+23j in s.__coredata__ or len(s.__coredata__) != 3:
        raise "ERROR"

    OK += 1
    
    # frozenset+attr
    s = plist[9]
    if not is_replicant(s):
        raise "ERROR"
    info = replicant_info(s)
    if info != ('frozenset','t_containers','SFrozenSet_noattr') or \
       not 567 in s.__coredata__ or not 6.78 in s.__coredata__ or \
       not 1+23j in s.__coredata__ or \
       s.aaa != '.zyx' or s.bbb[:3] != ('.r','.s','.t') or \
       id(s) != id(s.bbb[3]):
        raise "ERROR"		

    OK += 1
    
print "** OK (%d) **" % OK
    
