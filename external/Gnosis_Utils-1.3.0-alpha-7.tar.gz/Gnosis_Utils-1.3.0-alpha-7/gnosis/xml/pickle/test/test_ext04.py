"""
This demo shows how ClassExtensions easily handle self-referencing data.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.extensions import ClassExtension, register_extension, \
     unregister_extension

class BazList(list):
    def __init__(self,l,a,b):
        list.__init__(self,l)
        self.a = a
        self.b = b

    def __str__(self):
        s = "BazList:\n\tMy list is: %s\n\ta = %s\n\tb = %s" % \
            (self[:],repr(self.a),repr(self.b))
        return s
    
class BazListExt(ClassExtension):
    "BazList has a mutable core, so have to implement the mutable-core API here."

    def __init__(self):
        ClassExtension.__init__(self, 'BazListExtension')
        
    def pickle(self, obj):
        """
        Turn BazList coredata into a regular list, and
        store its attributes into the property list.
        """
        if not isinstance(obj,BazList):
            return self.ignore(obj)
        
        return (obj[:], {}, obj.__dict__)

    def unpickle_begin_nocore(self, *unused):
        "Create empty BazList"
        return BazList([],None,None)

    def unpickle_set_coredata(self, typestr, obj, coredata):
        "Set coredata of BazList"
        obj[:] = coredata

    def unpickle_finalize(self, obj, propmap):
        "Turn propmap back into BazList attributes."
        for key,val in propmap.items():
            setattr(obj, key, val)

register_extension(BazListExt())

o = BazList([1,2],None,None)
# selfref in coredata
o.append(o)
# selfref in 1st level attr
o.a = o
# selfref inside a tuple in 1st level attr
o.b = (5,6,o)
#print o

x = xml_pickle.dumps(o)
#print x

p = xml_pickle.loads(x)
#print p

# check data
if p[:2] != o[:2] or p.b[:2] != o.b[:2]:
    raise "ERROR"

# check that refs are maintained
if id(p) != id(p[2]) or id(p) != id(p.a) or \
   id(p) != id(p.b[2]):
    raise "ERROR"

print "** OK **"

