"""
Here, a ClassExtension returns metadata that is further mutated
by other ClassExtensions.
"""

from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT, XMLPicklingError
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, \
     unregister_extension, ClassExtension

class Foo:
    def __init__(self,a):
        self.a = a

class Bar:
    def __init__(self,a):
        self.a = a

class Baz:
    def __init__(self,m):
        self.meta = m

class FooExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "FooExt")
        
    def pickle(self, obj):
        if not isinstance(obj,Foo):
            return self.ignore(obj)

        b = Bar(222)
        metadata = {'aaa': b, 'bbb': Baz(333), 'ccc': b}
        propmap = {'ccc':987, 'ddd':654}
        return (obj, metadata, propmap)

    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        #print "GOT META ",metadata
        # make sure it is correct
        if not isinstance(metadata['aaa'],Bar) or metadata['aaa'].a != 222 or \
           id(metadata['aaa']) != id(metadata['ccc']):
            raise "ERROR"
        
        return Foo(None)

    def unpickle_finalize(self, obj, propmap):
        if propmap != {'ccc':987, 'ddd':654}:
            raise "ERROR"
        
class BarExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "BarExt")
    
    def pickle(self, obj):
        if not isinstance(obj,Bar):
            return self.ignore(obj)

        meta = {'bar-meta': 12.34}
        return (obj, meta, {'a':111,'b':222})

    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        #print "GOT META ",metadata
        if metadata != {'bar-meta': 12.34}:
            raise "ERROR"
        
        return Bar(None)

    def unpickle_finalize(self, obj, propmap):
        #print "GOT PROPS ",propmap
        if propmap != {'a':111,'b':222}:
            raise "ERROR"
        
class BazExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "BazExt")
    
    def pickle(self, obj):
        if not isinstance(obj,Baz):
            return self.ignore(obj)

        meta = {'baz-meta': 12.34}
        return (obj, meta, {'a':(87,65,43),'b':[9.23,8.45]})

    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        #print "GOT META ",metadata
        if metadata != {'baz-meta': 12.34}:
            raise "ERROR"
        
        return Baz(None)

    def unpickle_finalize(self, obj, propmap):
        #print "GOT PROPS ",propmap
        if propmap != {'a':(87,65,43),'b':[9.23,8.45]}:
            raise "ERROR"

register_extension(FooExt())
register_extension(BarExt())
register_extension(BazExt())

b = Foo(111)
x = dumps(b,short_ids=1)
print x
p = loads(x,0) # tests are in the classes above

if p.a != 111:
    raise "ERROR"

print "** OK **" 
