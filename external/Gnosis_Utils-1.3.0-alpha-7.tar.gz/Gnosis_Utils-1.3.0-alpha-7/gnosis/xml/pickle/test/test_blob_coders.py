
#
# Demonstration of gnosis.xml.xmlcoder --fpm
#

from gnosis.xml import xmlcoder

def runit( obj, binary, compress ):
    """
    Call encode() with (obj,binary,compress), decode result, and
    make sure they match.
    """
    print "Original: ",repr(obj)

    try:
        ucoded, coder = xmlcoder.encode( obj, binary, compress )
        print "  Coded: %s, %s" % (coder, repr(ucoded))

        val = xmlcoder.decode_as( ucoded, coder )
        print "  Decoded: %s" % repr(val)

        print ""
    except:
        print "******** UNSUPPORTED CODEC (binary=%d, compress=%s) *****" % \
              (binary,compress)
        val = obj # so below will pass

    # make sure decoded value AND class matches original (check type,
    # because Python will coerce in a unicode/string comparison)
    if val != obj or type(val) != type(obj):
        raise Exception("Bad decoding!")		
    
vals = [
    # tuple format: value, binary, compress
    # the full set of tests for each type is:
    #            (0,0), (0,1), (1,0), (1,1), (2,0), (2,1)
    # strings
    ("a plain string", 0, 0),
    ("plain string, to compress", 0, 1 ),
    ("string \x88 with \x87 some binary \x99", 1, 0 ),
    ("string \x88 with \x87 some binary \x99, to compress", 1, 1 ),	
    ("string \x12\x87\x99 lots of \x12\x87\x99 binary", 2, 0 ),
    ("string \x12\x87\x99 lots of \x12\x87\x99 binary, to compress", 2, 1 ),

    # unicode
    (u'plain unicode', 0, 0),
    (u'plain unicode, to compress', 0, 1 ),
    (u'unicode, some binary, low \u1234\u5678 high \U00012345\U00104321', 1, 0 ),
    (u'unicode, zlib, some binary, low \u1234\u5678 high \U00012345\U00104321', 1, 1 ),	
    (u'unicode, much binary, \u1234\u5678\U00012345\U0010FEDC\ufefe\uf012', 2, 0 ),
    (u'unicode, zlib, much binary, \u1234\u5678\U00012345\U0010FEDC\ufefe\uf012', 2, 1 ),

    # pickle (can pass anything except string/unicode; binary flag won't matter)
    
    ({'a': 1, 'b': 2, 'c': 3}, 0, 0),
    ({'a': 1, 'b': 2, 'c': 3}, 0, 1)	
    ]

for val, binary, compress in vals:
    runit( val, binary, compress )

# now just some unicode strings to test unicode/xml-escape
uvals = [
    # these all contain XML-legal chars, so will pass through non-escaped
    u'plain unicode',
    u'plain unicode, to compress',
    u'unicode, some binary, low \u1234\u5678 high \U00012345\U00104321',
    u'unicode, zlib, some binary, low \u1234\u5678 high \U00012345\U00104321',
    u'unicode, much binary, \u1234\u5678\U00012345\U0010FEDC\ufefe\uf012',
    u'unicode, zlib, much binary, \u1234\u5678\U00012345\U0010FEDC\ufefe\uf012',

    # now mix in some non-legal XML chars
    u'unicode with \u0019 non-legal \ud800 chars',

    # and some %'s
    u'unicode % with %% \u0019 non-legal %%% \ud800 chars'	
    ]

print "\n** Testing 'optimal' escaping vs. URL-encoding **"

# do unicode/xml-escape manually, showing size comparison w/URL coding
for val in uvals:
    print "Unicode     (%d): %s" % (len(val),repr(val))
    x = xmlcoder.encode_as( val, 'unicode/xml-escape' )

    print '  XML-Coded (%d): %s' % (len(x),repr(x))
    
    # show same with straight URL-coding
    uc = xmlcoder.encode_as( val, 'unicode/utf8-url' )
    print '  URL-coded (%d): %s' % (len(uc),repr(uc))

    u = xmlcoder.decode_as( x, 'unicode/xml-escape' )
    print '  Decoded: ',repr(u)

    if u != val:
        raise Exception("Codec failed")

# test cPickle coders
class Foo:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c

    def __str__(self):
        return "FOO: %s, %s, %s" % (str(self.a),str(self.b),str(self.c))
    
print "**** Testing cPickle encoding ***"
# no compression
f = Foo((3,4,5),{'a':1,'b':2,'c':3},
        """hello world from Foo. 
        this is a long line to make sure that the pickle will have
        to split across at least 3 base64 lines.
        blah blah here is some more text blah blah
        whee this is fun""")
enc,s = xmlcoder.encode( f, 1, 0 )
print "Got encoding: ",s
print "Encoded: ",enc
g = xmlcoder.decode_as( enc, s )
print g
if f.__dict__ != g.__dict__:
    raise "ERROR"
else:
    print "** OK **"

# with compression
f = Foo((3,4,5),{'a':1,'b':2,'c':3},
        """hello world from Foo. 
        this is a long line to make sure that the pickle will have
        to split across at least 3 base64 lines.
        blah blah here is some more text blah blah
        whee this is fun""")
enc,s = xmlcoder.encode( f, 1, 1 )
print "Got encoding: ",s
print "Encoded: ",enc
g = xmlcoder.decode_as( enc, s )
print g
if f.__dict__ != g.__dict__:
    raise "ERROR"
else:
    print "** OK **"	
    

