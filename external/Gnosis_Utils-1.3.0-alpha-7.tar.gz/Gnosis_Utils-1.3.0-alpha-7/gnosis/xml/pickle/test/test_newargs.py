"""
Test pickling when __new__ and possibly __newargs__ are present.

Technically, this should be part of test_protorules, but there are
a lot of cases, so this is long enough by itself.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps,loads,dumps_stats,loads_stats,is_replicant,\
     SEARCH_NO_IMPORT, add_class_to_store, replicant_info, SEARCH_STORE, SEARCH_NONE, \
     remove_class_from_store, XMLPicklingError, XMLUnpicklingError, SEARCH_ALL
import sys, re

ORDER = ''

def add(s):
    global ORDER
    ORDER += s

class Foo(tuple):
    """
    Normally, it's illegal to redefine __init__ for immutable
    subclasses like this, but with __new__ you can.

    In this first case, Foo defines __new__ and __getnewargs__.
    So, the __getnewargs__ return value will be stored in <meta '#newargs'>
    and the coredata will be ignored.

    Note that the standard pickle module requires you to pass protocol=2
    if you want __getnewargs__ to be honored. xml.pickle takes a different
    approach: it calls __getnewargs__ if it is not inherited from its
    baseclass.
    """
    def __init__(self,a,b,the_tuple):
        add('i')
        tuple.__init__(the_tuple)

        self.a = a
        self.b = b

    def __new__(cls, a, b, the_tuple):
        add('n')
        return tuple.__new__(Foo, the_tuple)

    def __getnewargs__(self):
        """Note that in this situation, __getnewargs__ is
        mandantory (try commenting it out - pickle will
        fail)."""
        add('g')
        return (self.a,self.b,self[:])

SET_CORE = (9.34,3.24,6.45)
SET_A = {'a':111,'b':222}
SET_B = [2.3456,['h','e','l','l','o']]

f = Foo(SET_A, SET_B, SET_CORE)

# test with standard pickle to make sure we agree on ordering
ORDER = ''

import pickle

# older Pythons don't do this right (needs protocol=2)
if pickle.format_version >= '2.0':
    # !! standard pickle, have to pass protocol=2 here !!
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != 'gn':
        print f[:], g[:]
        print f.__dict__, g.__dict__
        print repr(ORDER)
        raise "ERROR"

ORDER = ''

x = dumps(f,short_ids=1)
# make sure #newargs is in pickle
if not re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x

p = loads(x,0)
#print "CORE ",p[:], p.__dict__

if p[:] != f[:] or p.__dict__ != f.__dict__ or ORDER != 'gn':
    print p[:],p.__dict__,ORDER
    raise "ERROR"


class Bar(tuple):
    """
    2nd case -- __new__ without __newargs__. For standard pickle,
    this requires you to specify protocol=0. It would fail for
    protocol=2.

    xml.pickle on the other hand sees that __getnewargs__ was inherited
    from tuple and ignores it.
    """
    def __init__(self,a,b,the_tuple):
        add('i')
        tuple.__init__(the_tuple)

        self.a = a
        self.b = b

    def __new__(cls, a, b, the_tuple):
        add('n')
        return tuple.__new__(Bar, the_tuple)


f = Bar(SET_A, SET_B, SET_CORE)
ORDER = ''
# !! standard pickle, have to pass protocol=0 here; protocol=2 would fail !!
s = pickle.dumps(f)
g = pickle.loads(s)

# neither __init__ nor __new__ should have been called
if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"

#print ORDER

#print dir(f)

ORDER = ''
x = dumps(f,short_ids=1)
# make sure #newargs NOT in pickle
if re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x

g = loads(x,0)
#print ORDER

if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"

class FooBar(object):
    """
    A 'regular' class with __getnewargs__
    """
    def __init__(self,a,b,c):
        add("i")
        self.a = a
        self.b = b
        self.c = c

    def __new__(cls, a, b, c):
        add("n")
        return object.__new__(FooBar)

    def __getnewargs__(self):
        add("g")
        return (self.a,self.b,self.c)
    
f = FooBar(['a','b','c'],{'a':111,'b':222,'c':333},('aaa',1234,43.567))
#print f.__dict__

if pickle.format_version >= '2.0':
    ORDER = ''
    # !! standard pickle, have to pass protocol=2 here !!
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    if g.__dict__ != f.__dict__ or ORDER != 'gn':
        raise "ERROR"

ORDER = ''
x = dumps(f)
# make sure #newargs is in pickle
if not re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x
g = loads(x,0)
#print ORDER

if g.__dict__ != f.__dict__ or ORDER != 'gn':
    raise "ERROR"

class FooBar(object):
    """
    A 'regular' class with __new__ but not __getnewargs__
    """
    def __init__(self,a,b,c):
        add("i")
        self.a = a
        self.b = b
        self.c = c

    def __new__(cls, a, b, c):
        add("n")
        return object.__new__(FooBar)

f = FooBar(['a','b','c'],{'a':111,'b':222,'c':333},('aaa',1234,43.567))

ORDER = ''
# !! standard pickle, have to pass protocol=0 here; 2 would fail !!
s = pickle.dumps(f)
g = pickle.loads(s)

if g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"

ORDER = ''
x = dumps(f)
# make sure #newargs NOT in pickle
if re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x
g = loads(x,0)
#print ORDER

if g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"


class FooList(list):
    """
    Try it with a mutable core type, since that's a different
    path in objmodel.
    """
    def __init__(self,a,b,the_list):
        add('i')
        list.__init__(the_list)

        self.a = a
        self.b = b

    def __new__(cls, a, b, the_list):
        add('n')
        return list.__new__(FooList, the_list)

    def __getnewargs__(self):
        add('g')
        return (self.a,self.b,self[:])

f = FooList(['a','b','c'],{'a':111,'b':222,'c':333},['aaa',1234,43.567])
#print f.__dict__

if pickle.format_version >= '2.0':
    ORDER = ''
    # !! standard pickle, have to pass protocol=2 here !!
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != 'gn':
        raise "ERROR"

ORDER = ''
x = dumps(f)
# make sure #newargs is in pickle
if not re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x
g = loads(x,0)
#print ORDER

if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != 'gn':
    raise "ERROR"

class FooList(list):
    """
    Ditto, without newargs.
    """
    def __init__(self,a,b,the_list):
        add('i')
        list.__init__(the_list)

        self.a = a
        self.b = b

    def __new__(cls, a, b, the_list):
        add('n')
        return list.__new__(FooList, the_list)

f = FooList(['a','b','c'],{'a':111,'b':222,'c':333},['aaa',1234,43.567])
#print f.__dict__

ORDER = ''
# !! standard pickle, have to pass protocol=0 here !!
s = pickle.dumps(f)
g = pickle.loads(s)
#print ORDER

if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"

ORDER = ''
x = dumps(f)
# make sure #newargs NOT in pickle
if re.search('<meta name="#newargs"',x):
    raise "ERROR"
#print x
g = loads(x,0)
#print ORDER

if g[:] != f[:] or g.__dict__ != f.__dict__ or ORDER != '':
    raise "ERROR"

"""
This is a case where a subclass overrides __new__ and __getnewargs__ of
its baseclass.
"""
class Foo(object):
    def __new__(cls, a, b):
        add('Fn')
        add('%d%d' % (a,b))
        o = object.__new__(cls, a, b)
        o.a = a
        o.b = b
        return o

    def __getnewargs__(self):
        add('Fg')
        return (self.a,self.b)
    
class Bar(Foo):
    def __init__(self,a,b):
        add('Bi')
        Foo.__init__(self,a,b)

    def __new__(self,a,b):
        add('Bn')
        add('%d%d' % (a,b))
        return Foo.__new__(Bar,a,b)
    
    def __getnewargs__(self):
        add('Bg')
        return (111,222)
    
ORDER = ''
f = Bar(333,444)
#print "FDICT ",f,f.__dict__
#print ORDER

if pickle.format_version >= '2.0':
    ORDER = ''
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    # hardcode the values to make sure it worked like
    # I *think* it worked :-)
    if g.__dict__ != {'a':333, 'b':444} or ORDER != 'BgBn111222Fn111222':
        raise "ERROR"

ORDER = ''
x = dumps(f)
#print x
# make sure #newargs is in pickle
if not re.search('<meta name="#newargs"',x):
    raise "ERROR"
g = loads(x,0)
#print ORDER

if g.__dict__ != {'a':333, 'b':444} or ORDER != 'BgBn111222Fn111222':
    raise "ERROR"

#
# Here is the case that xml.pickle can't resolve without
# the pickle 'protocol' flag. You can pickle this two different
# ways. If protocol=0, then __getinitargs__ is not called,
# and __new__ is not called.
#
# If protocol=2, then Foo.__getinitargs__ is called,
# and Bar.__new__ is called when unpickling.
#
# xml.pickle doesn't know which to choose, so bails out.
# The solution is for the user to add __getnewargs__ to
# Bar, returning either Foo.__getnewargs__, or None, if
# no newargs are needed.
#

class Foo(object):
    def __new__(cls, a, b):
        add('Fn')
        add('%d%d' % (a,b))
        o = object.__new__(cls, a, b)
        o.a = a
        o.b = b
        return o

    def __getnewargs__(self):
        add('Fg')
        return (888,999)
    
class Bar(Foo):
    def __init__(self,a,b):
        add('Bi')
        Foo.__init__(self,a,b)

    def __new__(self,a,b):
        add('Bn')
        add('%d%d' % (a,b))
        return Foo.__new__(Bar,a,b)

# try w/protocol=0 ...

ORDER = ''
f = Bar(11.1,22.2)
#print ORDER

ORDER = ''
s = pickle.dumps(f)
g = pickle.loads(s)
#print ORDER

# hardcode the values to make sure it worked like
# I *think* it worked :-)
if g.__dict__ != {'a':11.1, 'b':22.2} or ORDER != '':
    raise "ERROR"

if pickle.format_version >= '2.0':
    # now with protocol=2
    ORDER = ''
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    # hardcode the values to make sure it worked like
    # I *think* it worked :-)
    if g.__dict__ != {'a':11.1, 'b':22.2} or ORDER != 'FgBn888999Fn888999':
        raise "ERROR"

try:
    x = dumps(f)
    raise "ERROR" # should not work
except XMLPicklingError,exc:
    #print "Got expected error: %s" % str(exc)
    pass

#
# Fixed version #1 - call Foo.__getnewargs__
#

class Foo(object):
    def __new__(cls, a, b):
        add('Fn')
        add('%d%d' % (a,b))
        o = object.__new__(cls, a, b)
        o.a = a
        o.b = b
        return o

    def __getnewargs__(self):
        add('Fg')
        return (888,999)
    
class Bar(Foo):
    def __init__(self,a,b):
        add('Bi')
        Foo.__init__(self,a,b)

    def __new__(self,a,b):
        add('Bn')
        add('%d%d' % (a,b))
        return Foo.__new__(Bar,a,b)

    def __getnewargs__(self):
        add('Bg')
        return Foo.__getnewargs__(self)

f = Bar(11.1,22.2)

if pickle.format_version >= '2.0':
    ORDER = ''
    s = pickle.dumps(f,2)
    g = pickle.loads(s)

    if g.__dict__ != {'a':11.1, 'b':22.2} or ORDER != 'BgFgBn888999Fn888999':
        raise "ERROR"

ORDER = ''
x = dumps(f)
#print x
g = loads(x,0)
#print ORDER

if g.__dict__ != {'a':11.1, 'b':22.2} or ORDER != 'BgFgBn888999Fn888999':
    raise "ERROR"

#
# Fixed version #2 - return 'None' to say 'no args' (this is
# an xml.pickle extension - None isn't allow with the standard pickler)
#

class Foo(object):
    def __new__(cls, a, b):
        add('Fn')
        add('%d%d' % (a,b))
        o = object.__new__(cls, a, b)
        o.a = a
        o.b = b
        return o

    def __getnewargs__(self):
        add('Fg')
        return (888,999)
    
class Bar(Foo):
    def __init__(self,a,b):
        add('Bi')
        Foo.__init__(self,a,b)

    def __new__(self,a,b):
        add('Bn')
        add('%d%d' % (a,b))
        return Foo.__new__(Bar,a,b)

    def __getnewargs__(self):
        add('Bg')
        return None

f = Bar(11.1,22.2)

# can't test with standard pickle; it doesn't allow None from __getnewargs__

ORDER = ''
x = dumps(f)
#print x
g = loads(x,0)
#print ORDER

if g.__dict__ != {'a':11.1, 'b':22.2} or ORDER != 'Bg':
    raise "ERROR"

print "** OK **"

