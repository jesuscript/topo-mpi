# 
# Randomly generate a variety of objects.
#
# Generally, rand_obj() is the main entry point, but the other pieces
# are modular for easy use.
#

# Tailoring

# xml.pickle slows down with large blocks of text,
# especially large blocks of binary data. It is
# interesting to try runs with and without large blocks.
LARGE_STRINGS = 0
USE_UNICODE = 1

from random import randint, choice, random
import string
from types import *
import t_classes

def rand_attr_name( minlen, maxlen ):
    s = ''
    nr = randint(minlen, maxlen)
    s += choice(string.letters+'_')
    nr -= 1
    while nr > 0:
        s += choice(string.letters+string.digits+'_')
        nr -= 1
 		
    return s
        
def rand_ascii_word( minlen, maxlen ):
    s = ''
    nr = randint(minlen,maxlen)
    for i in range(nr):
        s += choice(string.letters+string.digits)

    return s

def rand_ascii_block( nrlines, maxlength ):

    t = ''
    
    for i in range(nrlines):
        s = ''
        nr = randint(0, maxlength)
        while len(s) < nr:
            s += rand_ascii_word(2, 8) + ' '

        if len(s):
            s = s[:-1]
            s += '\n'

        t += s

    return t

# pregenerating a string gives a 2x speed bump over
# doing chr() each time
bin256 = ''
for i in range(256):
    bin256 += chr(i)
    
def rand_binary_str(length):
    # using a list is faster on Python <= 2.3.
    # doesn't matter on 2.4
    s = []
    for i in range(length):
        s.append(choice(bin256))

    return ''.join(s)

# pregenerate all chars, for speed
ubin256 = u''
for i in range(0xffff):
    ubin256 += unichr(i)
    
def rand_unicode_str(length):
    s = []
    for i in range(length):
        s.append(choice(ubin256))

    return u''.join(s)

# some random funcs, named by 'type='
def rand_numeric():
    i = randint(0,3)

    if i == 0: # int
        return randint(-1e6, 1e6)
    elif i == 1: # long
        return 4L**63 * (random()-0.5)
    elif i == 2: # float
        return random() - 0.5
    elif i == 3: # complex
        return ((random()-0.5) + (random()-0.5)*1j)
    else:
        raise "ERROR"
    
def rand_string():
    i = randint(0,2)
    if i == 0:
        return rand_ascii_block(randint(0, [3,10][LARGE_STRINGS]),
                                randint(0, [10,70][LARGE_STRINGS]) )
    elif i == 1:
        if USE_UNICODE:
            return unicode(rand_ascii_block(randint(0,[3,10][LARGE_STRINGS]),
                                            randint(0, [10,70][LARGE_STRINGS]) ))
        else:
            return rand_ascii_block(randint(0,[3,10][LARGE_STRINGS]),
                                    randint(0, [10,70][LARGE_STRINGS]) )											
    elif i == 2:
        # decide on little/big binary block
        if random() < 0.85:
            maxnr = [10,256][LARGE_STRINGS]
        else:
            maxnr = [256,10000][LARGE_STRINGS]			
            
        i = randint(0,1)
        if (i == 0 or not USE_UNICODE):
            return rand_binary_str(randint(0,maxnr))
        else:
            return rand_unicode_str(randint(0,maxnr))
    else:
        raise "ERROR"

# pick some functions available everywhere
import zlib, UserList, UserDict, UserString
# note: cannot use string.* since in Python2.0 they are aliased
# under urlparse.*, and the routine happens to find those first,
# making the pickling inconsistent between Python versions
#
# don't use type() builtin since it changed from a function->class in Py2.2
func_class_set = [chr, dir, pow, ord, zlib.compress]
func_class_set += t_classes.SampleClasses.values()
func_class_set += [UserList.UserList, UserDict.UserDict, UserString.UserString]

def rand_func_or_class():
    return choice(func_class_set)
    
def rand_atom():
    # make an atom
    i = randint(0,2)
    if i == 0:
        return rand_numeric()
    elif i == 1:
        return rand_string()
    elif i == 2:
        return rand_func_or_class()
    else:
        raise "ERROR"
    
def rand_hashable():
    # note: must be hashable AND sortable, so certain things
    # are excluded

    ok = 0
    while not ok:
        i = randint(0,1)
        if i == 0:
            obj = rand_atom()
        elif i == 1:
            obj = rand_tuple(0)

        ok = 1
        
        if type(obj) is ComplexType:
            # complex numbers aren't sortable
            ok = 0
    
def rand_list(depth_left):
    nr = randint(0,10)
    l = []
    for i in range(nr):
        l.append(rand_obj(depth_left-1))

    return l

def rand_tuple(depth_left):
    return tuple(rand_list(depth_left))

def rand_dict(depth_left):
    nr = randint(0,10)
    d = {}
    
    for i in range(nr):
        key = rand_hashable()
        d[key] = rand_obj(depth_left-1)

    return d

class FlatObj:
    pass

def rand_attr_names():
    nr_attrs = randint(0,20)
    attrs = []
    for i in range(nr_attrs):
        attr = None
        while attr is None or attr in attrs:
            attr = rand_attr_name(1,10)

        attrs.append(attr)

    return attrs

def rand_attr_dict(depth_left):
    attrs = {}

    for k in rand_attr_names():
        attrs[k] = rand_obj(depth_left)

    return attrs

def rand_flat_obj(depth_left):
    obj = FlatObj()
    for k,v in rand_attr_dict(depth_left-1).items():
        setattr(obj,k,v)

    return obj

def rand_container(depth_left):
    i = randint(0,3)
    if i == 0:
        return rand_list(depth_left)
    elif i == 1:
        return rand_tuple(depth_left)
    elif i == 2:
        return rand_dict(depth_left)
    elif i == 3:
        return rand_flat_obj(depth_left)		
    else:
        raise "ERROR"
    
def rand_obj(depth_left):

    # should I make a container, or an atom?
    # when more depth is left, give a greater chance of making
    # a container
    if (depth_left >= 3 and random() > 0.1) or \
           (depth_left > 0 and random() >= 0.4):
        return rand_container(depth_left)
    else:
        return rand_atom()
    
class Client:
    "A sample flat object"
    def __init__(self, first, middle, last, addr1, addr2, city, state, zipcode, notes):
        self.first = first
        self.middle = middle
        self.last = last
        self.addr1 = addr1
        self.addr2 = addr2
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.notes = notes

def rand_client():
    c = Client(rand_ascii_word(5, 10), rand_ascii_word(5, 10), rand_ascii_word(5, 10),
               rand_ascii_block(1, 30), rand_ascii_block(1, 30),
               rand_ascii_word(5, 10), rand_ascii_word(2, 2), randint(10000,99999),
               rand_ascii_block(randint(10, 20), 72))
    return c			

