"""
Demo/test of replicants.

Shows several things:
  1) Replicants contain the same attributes as the real classes
     they represent.
  2) Replicants contain the 'core' data of the real class in __coredata__.
  3) Replicants know what type= and class= they represent, so you
     can tell what *should* have been loaded.
  4) Replicants can be repickled, and produce the same XML stream
     as the real classes, with limitations in some cases.
     
Here, SEARCH_NONE is used when loading to force replicants to be
created for all classes.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps, loads, add_class_to_store, SEARCH_NONE, \
     SEARCH_STORE, dumps_stats, XMLPicklingError
from gnosis.pyconfig import pyconfig
from gnosis.xml.pickle.replicants import is_replicant, replicant_info, \
     make_replicant_class, make_module_path
from gnosis.xml.pickle.objmodel import get_data_attrs, get_classtag

import sys
sys.path.insert(0,'.')
import t_containers, t_classes

# Before getting started, do a little sanity check on replicants.py.
# Create some fake classes and make sure their info is preserved.
def sanity_check_replicants():
    # try: root module, single dotted name, double dotted, type=None, etc.
    for inf in [(None,'TestRep1','list'),
                ('TestMod1','TestRep2','dict'),
                ('TestMod2.TestMod3','TestRep3','pyobj'),
                ('TestMod1.TestMod4.TestMod5','TestRep4',None)]:
        k = make_replicant_class( *inf )
        for v in [k,k()]: # check info from both class & object
            i = replicant_info(k)
            if ((inf[2] == None and i[0] != 'unknown') or (inf[2] != None and inf[2] != i[0])) or \
                   i[1] != inf[0] or i[2] != inf[1]:
                print i,inf
                raise "ERROR"

    # now use make_module_path() to create a fake class *NOT* underneath
    # gnosis.xml.pickle.replicants.
    import imp
    # create fake root module
    mod = imp.new_module('Testing123')
    # create AAA.BBB.CCC modules under fake root
    sub = make_module_path('AAA.BBB.CCC',mod)
    # create a class Foo in Testing123.AAA.BBB.CCC
    exec('class Foo: pass') in sub.__dict__
    # make sure it's in the right namespace
    if get_classtag(sub.Foo) != 'Testing123.AAA.BBB.CCC.Foo':
        raise "ERROR"

    # Testing123 should not be visible from sys.modules
    if 'Testing123' in sys.modules.keys():
        raise "ERROR"
    
sanity_check_replicants()

# one class in __main__, just as a check
class Foo:
    pass

if pyconfig.Have_Slots():
    class FooSlots(object):
        __slots__ = ('aaa','bbb','ccc')

olist = []

o = Foo()
o.aaa = ('123',u'ijk',(1.23,2.34),{4.56:7.89,9.32:u'iiii'})

olist.append(o)

# add classes to store, but tell loads() to ignore the
# store (just as a check that SEARCH_NONE is working)
add_class_to_store(Foo)

if pyconfig.Have_ObjectClass():
    o = t_classes.SampleNewClass()
    o.xyz = [543,4.3323,34+23j,'abcde',u'jkli']
    olist.append(o)
    add_class_to_store(t_classes.SampleNewClass)
    
    o = t_containers.SList_noattr([(88,77,66),{'abc':'xyz'}])
    o.zzz = (54,43,32)
    olist.append(o)
    add_class_to_store(t_containers.SList_noattr)
    
    o = t_containers.SDict_noattr({(65,54,43):'oo oo oo',u'ijkijk':3.2+4.3j})
    o.yyy = [(1,2),(3,4),(5,6)]
    olist.append(o)
    add_class_to_store(t_containers.SDict_noattr)
    
if pyconfig.Have_BuiltinSet():
    o = t_containers.SSet_noattr((91.43,'abcdef',0))
    o.fff = 'ggg'
    olist.append(o)
    add_class_to_store(t_containers.SSet_noattr)
    
x = dumps(olist)
print x

# force replicants to be created by not allowing loads()
# to search for the classes
zlist = loads(x,SEARCH_NONE)

# -- check Foo --
o = zlist[0]

# make sure it's a replicant
if not is_replicant(o):
    print repr(o)
    raise "ERROR"

# attributes should match
if get_data_attrs(o) != get_data_attrs(olist[0]):
    print o, olist[0]
    print get_data_attrs(o)
    print get_data_attrs(olist[0])
    raise "ERROR"

# make sure it's the right type of replicant
# replicant_info() gives you a tuple:
#      (typestr, module, classname)
#
# so you can see what was SUPPOSED to be loaded

i = replicant_info(o)
if i != ('pyobj','__main__','Foo'):
    raise "ERROR"

if pyconfig.Have_ObjectClass():
    
    # -- check SampleNewClass --
    o = zlist[1]

    # make sure it's a replicant
    if not is_replicant(o):
        print repr(o)
        raise "ERROR"

    # attributes should match
    if get_data_attrs(o) != get_data_attrs(olist[1]):
        raise "ERROR"

    # make sure it's the right type of replicant
    i = replicant_info(o)
    if i != ('pyobj','t_classes','SampleNewClass'):
        raise "ERROR"

    # -- check SList_noattr --
    o = zlist[2]

    # make sure it's a replicant
    if not is_replicant(o):
        print repr(o)
        raise "ERROR"

    # coredata should match __coredata__
    if o.__coredata__ != olist[2][:]:
        raise "ERROR"
    
    del o.__coredata__ # convenience for below ..
 	
    # attributes should match
    if get_data_attrs(o) != get_data_attrs(olist[2]):
        raise "ERROR"

    # make sure it's the right type of replicant
    i = replicant_info(o)
    if i != ('list','t_containers','SList_noattr'):
        raise "ERROR"

    # -- check SDict_noattr --
    o = zlist[3]

    # make sure it's a replicant
    if not is_replicant(o):
        print repr(o)
        raise "ERROR"

    # coredata should match __coredata__
    if o.__coredata__ != olist[3]:
        raise "ERROR"
    
    del o.__coredata__ # convenience for below ..
    
    # attributes should match
    if get_data_attrs(o) != get_data_attrs(olist[3]):
        raise "ERROR"

    # make sure it's the right type of replicant
    i = replicant_info(o)
    if i != ('dict','t_containers','SDict_noattr'):
        raise "ERROR"		

if pyconfig.Have_BuiltinSet():
    # -- check SSet_noattr --
    o = zlist[4]

    # make sure it's a replicant
    if not is_replicant(o):
        print repr(o)
        raise "ERROR"

    # coredata should match __coredata__
    l1 = o.__coredata__
    l1.sort()
    l2 = list(olist[4])
    l2.sort()
    if l1 != l2:
        raise "ERROR"
    
    del o.__coredata__ # convenience for below ..
    
    # attributes should match
    if get_data_attrs(o) != get_data_attrs(olist[4]):
        raise "ERROR"

    # make sure it's the right type of replicant
    i = replicant_info(o)
    if i != ('set','t_containers','SSet_noattr'):
        raise "ERROR"		

# load all from store to ensure all are found
zlist = loads(x,SEARCH_STORE)
if len(zlist) != len(olist):
    raise "ERROR"

for o in zlist:
    if is_replicant(o):
        raise "ERROR"

#------------------------------------------------------------------
# Show that olist can be dumped, reloaded as replicants, redumped,
# reloaded with real classes, dumped again, and the original/final
# XML will match
#-------------------------------------------------------------------

# dump normally
x1,st = dumps_stats(olist, short_ids=1, sorted=1)
# load all as replicants
bb = loads(x1,SEARCH_NONE)
for o in bb:
    # sanity check
    if not is_replicant(o):
        raise "ERROR"

# re-pickle replicants
try:
    # should fail by default (allow_replicants=0)
    x2,st = dumps_stats(bb, short_ids=1, sorted=1)
    raise "ERROR"
except XMLPicklingError:
    pass

# allow repickling of replicants
x2,st = dumps_stats(bb, short_ids=1, sorted=1, allow_replicants=1)

# now reload with real classes
cc = loads(x2,SEARCH_STORE)
# spot-check
if cc[0].__class__ != Foo:
    raise "ERROR"

# and redump
x3,st = dumps_stats(cc, short_ids=1, sorted=1, allow_replicants=1)

# original & final XML should be identical, despite being
# unpickled & repickled as replicants
if x1 != x3:
    raise "ERROR"

print "** OK **"

