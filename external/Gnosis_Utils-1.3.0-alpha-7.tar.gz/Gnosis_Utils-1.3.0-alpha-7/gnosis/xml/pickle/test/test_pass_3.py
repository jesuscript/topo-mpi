# used for sanity checking the test harness
# a "pass" test that prints something

print "** OK **"
