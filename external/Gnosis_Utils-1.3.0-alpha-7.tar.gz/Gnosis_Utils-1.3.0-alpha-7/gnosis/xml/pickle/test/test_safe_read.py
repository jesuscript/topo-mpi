"""
This demo shows how you can safely read completely untrusted data.
It also demonstrates how you can modify AND REWRITE the data, and get back
the same XML as if you had modified the original objects, without ever having
to load untrusted classes.

Assumes Python >= 2.2 (the same technique works for older Pythons,
but this demo uses newstyle objects).
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps, dumps_stats, loads, SEARCH_NONE
from gnosis.xml.pickle.misc import pprint_replicant
import t_classes, t_atoms, t_containers

def make_test_object():
    "Create the test object."
    
    # an oldstyle class
    obj = t_classes.SampleOldClass()

    # subclassed from object
    obj.aa = t_classes.SampleNewClass()
    obj.aa.mm = {'aaa':1, 'bbb':2}
    obj.aa.nn = {'ccc': ('a','b','c')}

    # with __slots__
    obj.bb = t_classes.SampleSlotsClass()
    obj.bb.aaa = (111,222,333)
    obj.bb.bbb = ['d','e','f']

    # subclassed from list
    obj.cc = t_containers.SList_noattr(['x',123,u'y'])
    obj.cc.aa = "hello cc.aa"
    obj.cc.bb = u"u hello cc.bb"

    # subclassed from dict
    obj.dd = t_containers.SDict_noattr({12.34:'aaaa',32.45:'bbbb'})
    obj.dd.aa = ('dd','dot','aa')
    obj.dd.bb = (u'dd',u'dot',u'bb')

    # subclassed from int
    obj.ee = t_atoms.SInt_noattr(918273)
    obj.ee.aa = 'int ee aa'
    obj.ee.bb = [u'int',u'ee',u'bb']

    # subclased from unicode
    obj.ff = t_atoms.SUnicode_noattr(u'an SUnicode_noattr')
    obj.ff.aa = 'sunicode ff aa'
    obj.ff.gg = (u'sunicode ff gg',)

    # subclased from string
    obj.gg = t_atoms.SUnicode_noattr('an SString_noattr')
    obj.gg.hh = 'sstring gg hh'
    obj.gg.ii = (u'sstring gg ii',)	
    
    return obj

# dump as XML, with real class information
obj = make_test_object()
xml,stats = dumps_stats( obj )
print stats.__dict__

# load with class_search=SEARCH_NONE: This will ensure that
# *NO* real classes are loaded, only replicants. The only
# real objects loaded will be builtins like int,float,dict,etc.
# (Only native Python baseclasses are trusted - subclasses will be
# replaced with replicants as well.)

o2 = loads(xml,SEARCH_NONE)

# Pretty-print info about each replicant
pprint_replicant(o2,'[ Root object ]')
pprint_replicant(o2.aa,'[ .aa object ]')
pprint_replicant(o2.bb,'[ .bb object ]')
pprint_replicant(o2.cc,'[ .cc object ]')
pprint_replicant(o2.dd,'[ .dd object ]')
pprint_replicant(o2.ee,'[ .ee object ]')
pprint_replicant(o2.ff,'[ .ff object ]')
pprint_replicant(o2.gg,'[ .gg object ]')

# Given certain restrictions, you can REPICKLE a replicant object,
# and get the exact same XML as from the original object:
#
#  |Note that #1 is the critical one - #2 only affects the text
#  |comparison of the two dumps().
#  |
#  |As long as you satisfy #1, you can rewrite replicants and still
#  |get back the 'real' objects.
#
# Requirements for this to happen:
#
#   1. No XMLPickleExtensions must have been involved in
#      pickling the original object.
#
#   2. Due to Python's "hidden references" (see DESIGN), inserting
#      certain immutable types into the object can cause it
#      to not match the references of the original.
#
#      For example, if you pickled this:
#            l = ['aaa','bbb','ccc']
#
#      Read it back as a replicant, then did:
#            l.append('ccc')
#
#      ... and then repickled, the two XML streams will most
#      likely NOT match. The string 'ccc' will match a "hidden
#      reference" in either the original object, the replicant,
#      neither, or both, so they will (most likely) have mismatching
#      references. This is *NOT* a bug in xml.pickle - this is 100%
#      correct behavior, and is just the way Python works.
#      Both objects are correct, but they may not both have the
#      same reference to 'ccc' (which is OK, since you didn't
#      explicitly set a reference to begin with).
#
#      Think of it another way: The string 'ccc' on two different
#      *machines* will likely never have the same id(), so you can't
#      expect to be able to send a 'ccc' from one machine to another
#      and have their ids match.
#
#    BOTTOM LINE: Nothing about this will ever cause your code
#    to be incorrect. It is just a matter of whether you can
#    expect the XML stream from two objects to match byte-for-byte.
#
# Note the "allow_replicants" flag is required: In general,
# re-pickling replicants CAN cause data loss (if XMLPickleExtensions
# were used), so it is disabled by default.

def modify_object(obj):
    # careful not to reuse any strings/integers that might exist
    # in the original object (see above)
    obj.aa.mm['yyyy'] = 34.58674
    obj.bb.bbb.append('gggg')
    # modify the SList
    if hasattr(obj.cc,'__coredata__'):
        # it's a replicant
        obj.cc.__coredata__.append('eeeeee')
    else:
        # it's the real object
        obj.cc.append('eeeeee')

# modify both objects in the same way, and show that
# the resulting XML still matches
modify_object(obj)
modify_object(o2)
# create a fresh test object also, just to show that
# the pickling process didn't affect 'obj'
obj0 = make_test_object()
modify_object(obj0)

# The 'short_ids' and 'sorted' flags ensure that the pickle
# ordering is determinisitic.
xml_r = dumps(o2, allow_replicants=1, short_ids=1, sorted=1)

# pickle original object deterministically as well
xml_0 = dumps(obj0, short_ids=1, sorted=1)

# extra paranoia -- pickling should never change the object
xml_1 = dumps(obj, short_ids=1, sorted=1)

if xml_0 != xml_r:
    open('x0.xml','w').write(xml_0)
    open('x1.xml','w').write(xml_1)
    open('xr.xml','w').write(xml_r)	
    raise "ERROR"

print "XML matches!"
