
#
# demo all cases of objmodule.compose()
#

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle.objmodel import demo_compose, decompose, UElement
from gnosis.xml.pickle import XMLPicklingError, XMLUnpicklingError,\
     PARANOIA_0
from gnosis.xml import xmlcoder
from gnosis.pyconfig import pyconfig
import re

class int_noattr(int): pass
class int_attr(int):
    def __init__(self, a):
        int.__init__(self,a)
        
        self.a = None
        self.b = None

class float_noattr(float): pass
class float_attr(float):
    def __init__(self, f):
        float.__init__(self,f)
        
        self.x = None
        self.y = None

class long_noattr(long): pass
class long_attr(long):
    def __init__(self, f):
        long.__init__(self,f)
        
        self.x = None
        self.y = None

class complex_noattr(complex): pass
class complex_attr(complex):
    def __init__(self, f):
        complex.__init__(self,f)
        
        self.x = None
        self.y = None

class str_noattr(str): pass
class str_attr(str):
    def __init__(self, f):
        str.__init__(self,f)
        
        self.x = None
        self.y = None

class unicode_noattr(unicode): pass
class unicode_attr(unicode):
    def __init__(self, f):
        unicode.__init__(self,f)
        
        self.x = None
        self.y = None

class list_noattr(list): pass
class list_attr(list):
    def __init__(self, f):
        list.__init__(self,f)
        
        self.x = None
        self.y = None

class tuple_noattr(tuple): pass
class tuple_attr(tuple):
    def __init__(self, f):
        tuple.__init__(self,f)
        
        self.x = None
        self.y = None

if pyconfig.Have_BuiltinSet():
    class frozenset_noattr(frozenset): pass
    class frozenset_attr(frozenset):
        def __init__(self, f):
            frozenset.__init__(self,f)
        
            self.x = None
            self.y = None

    class set_noattr(set): pass
    class set_attr(set):
        def __init__(self, f):
            set.__init__(self,f)
        
            self.x = None
            self.y = None

class dict_noattr(dict): pass
class dict_attr(dict):
    def __init__(self, f):
        dict.__init__(self,f)
        
        self.x = None
        self.y = None																		

# Note: I use PARANOIA_0 so compose() can load all my
# imported classes.

#-----------------------------------------------------------
#
# All three cases (base, subclass-noattr, subclass-attr)
# for each of the numeric types.
#
#-----------------------------------------------------------

# base int
o = demo_compose('numeric', None, u'123', {}, **PARANOIA_0 )
print o, o.__class__

# subclass int, no attr
o = demo_compose('numeric', '__main__.int_noattr', u'123', {},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass int w/attr
o = demo_compose('numeric', '__main__.int_attr', u'123', {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# base float
o = demo_compose('numeric', None, u'123.456', {}, **PARANOIA_0 )
print o, o.__class__

# subclass float, no attr
o = demo_compose('numeric', '__main__.float_noattr', u'123.456',{},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass float w/attr
o = demo_compose('numeric', '__main__.float_attr', u'123.456', {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# base long
o = demo_compose('numeric', None, u'123456L', {}, **PARANOIA_0 )
print o, o.__class__

# subclass long, no attr
o = demo_compose('numeric', '__main__.long_noattr', u'123456L', {},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass long w/attr
o = demo_compose('numeric', '__main__.long_attr', u'123456L', {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# base complex
o = demo_compose('numeric', None, u'123:456', {}, **PARANOIA_0 )
print o, o.__class__

# subclass complex, no attr
o = demo_compose('numeric', '__main__.complex_noattr', u'123:456', {},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass complex w/attr
o = demo_compose('numeric', '__main__.complex_attr', u'123:456', {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

#-----------------------------------------------------------
#
# All three cases (base, subclass-noattr, subclass-attr)
# for each of the string types.
#
#-----------------------------------------------------------

# base string
o = demo_compose('string', None, 'a string', {}, **PARANOIA_0 )
print o, o.__class__

# subclass string, no attr
o = demo_compose('string', '__main__.str_noattr', 'a string', {},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass string w/attr
o = demo_compose('string', '__main__.str_attr', 'a string', {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# pass several strings via UElement
slist = ['a nonattr-safe string\nwith some\n linebreaks only',
         'and now some \x04 binary %% data \x15 there',
         # make > 40 so it'll figure out it needs base64+z
         'majority binary ' + '\x00\x01\x02\x03\x04'*8]

for s in slist:
    # pass string coredata via UElement
    u = UElement( plain=s )
    u.encode()
    print u.encoding
    print repr(u.encoded)
    o = demo_compose('string', '__main__.str_attr', u, {'a':1,'b':2},
                     **PARANOIA_0 )
    print repr(o), o.__class__, o.__dict__	

# Unicode always comes back in a <u>

# base unicode
u = UElement(u'a unicode')
u.encode()
o = demo_compose('string', None, u, {}, **PARANOIA_0 )
print o, o.__class__

# subclass unicode, no attr
u = UElement(u'a unicode')
u.encode()
o = demo_compose('string', '__main__.unicode_noattr', u, {},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# subclass unicode w/attr
u = UElement(u'a unicode')
u.encode()
o = demo_compose('string', '__main__.unicode_attr', u, {'a':1,'b':2},
            **PARANOIA_0 )
print o, o.__class__, o.__dict__

# pass several unicodes via UElement
slist = [u'a regular unicode\nline breaks\nare okay\n',
         u'and now an \u0019 illegal \ud800 char or two',
         # make > 40 so it'll figure out it needs base64+z
         u'majority binary ' + u'\x00\x01\x02\x03\x04'*8]

for s in slist:
    # pass string coredata via UElement
    u = UElement( plain=s )
    u.encode()
    print u.encoding
    print repr(u.encoded)
    o = demo_compose('string', '__main__.unicode_attr', u, {'a':1,'b':2},
                     **PARANOIA_0 )
    print repr(o), o.__class__, o.__dict__	

#
# The 'unique' types that can have no subclasses/coredata/attrs
#
o = demo_compose('None', None, None, {}, **PARANOIA_0)
print o

o = demo_compose('True', None, None, {}, **PARANOIA_0)
print o

o = demo_compose('False', None, None, {}, **PARANOIA_0)
print o

#
# 'function' types, no subclasses/coredata/attrs
#

def aaa(): pass

o = demo_compose('function', '__main__.aaa', None, {}, **PARANOIA_0)
print o, o.__module__

o = demo_compose('function', '__builtin__.float', None, {}, **PARANOIA_0)
print o, o.__module__

o = demo_compose('function', '__builtin__.chr', None, {}, **PARANOIA_0)
print o, o.__module__

from gnosis.xml import xmlmap

o = demo_compose('function', 'xmlmap.is_legal_xml', None, {}, **PARANOIA_0)
print o, o.__module__

#
# 'class' types, no subclasses/coredata/attrs
#

o = demo_compose('class', '__main__.int_noattr', None, {}, **PARANOIA_0)
print o, o.__module__

o = demo_compose('class', 'gnosis.xml.pickle.XMLUnpicklingError', None, {},
            **PARANOIA_0)
print o, o.__module__

o = demo_compose('class', '__builtin__.int', None, {}, **PARANOIA_0)
print o, o.__module__

o = demo_compose('class', '__builtin__.object', None, {}, **PARANOIA_0)
print o, o.__module__

#
# 'list'
#

o = demo_compose('list', None, [1,2,3], {}, **PARANOIA_0)
print o, o.__class__

o = demo_compose('list', '__main__.list_noattr', [1,2,3], {}, **PARANOIA_0)
print o, o.__class__, o.__dict__

o = demo_compose('list', '__main__.list_attr', [1,2,3], {'a': 888, 'b': 111},
                 **PARANOIA_0)
print o, o.__class__, o.__dict__


#
# 'tuple'
#

o = demo_compose('tuple', None, [1,2,3], {}, **PARANOIA_0)
print o, o.__class__

o = demo_compose('tuple', '__main__.tuple_noattr', [1,2,3], {}, **PARANOIA_0)
print o, o.__class__, o.__dict__

o = demo_compose('tuple', '__main__.tuple_attr', [1,2,3], {'a': 888, 'b': 111},
                 **PARANOIA_0)
print o, o.__class__, o.__dict__

if pyconfig.Have_BuiltinSet():
    #
    # 'frozenset'
    #
    
    o = demo_compose('frozenset', None, [1,2,3], {}, **PARANOIA_0)
    print o, o.__class__

    o = demo_compose('frozenset', '__main__.frozenset_noattr', [1,2,3], {}, **PARANOIA_0)
    print o, o.__class__, o.__dict__

    o = demo_compose('frozenset', '__main__.frozenset_attr', [1,2,3], {'a': 888, 'b': 111},
                     **PARANOIA_0)
    print o, o.__class__, o.__dict__

    #
    # 'set'
    #

    o = demo_compose('set', None, [1,2,3], {}, **PARANOIA_0)
    print o, o.__class__

    o = demo_compose('set', '__main__.set_noattr', [1,2,3], {}, **PARANOIA_0)
    print o, o.__class__, o.__dict__

    o = demo_compose('set', '__main__.set_attr', [1,2,3], {'a': 888, 'b': 111},
                     **PARANOIA_0)
    print o, o.__class__, o.__dict__

#
# 'dict'
#

o = demo_compose('dict', None, {'a':1,'b':2,'c':3}, {}, **PARANOIA_0)
print o, o.__class__

o = demo_compose('dict', '__main__.dict_noattr', {'a':1,'b':2,'c':3}, {}, **PARANOIA_0)
print o, o.__class__, o.__dict__

o = demo_compose('dict', '__main__.dict_attr', {'a':2,'b':2,'c':3},
                 {'a': 888, 'b': 111}, **PARANOIA_0)
print o, o.__class__, o.__dict__

class Foo_old:
    def __init__(self):
        self.a = None
        self.b = None

class Foo_new(object):
    def __init__(self):
        object.__init__(self)
        
        self.a = None
        self.b = None

class Foo_slots(object):
    def __init__(self):
        object.__init__(self)
        __slots__ = ('a','b')

#
# 'pyobj' cases
#

# 'object' instances can't have attributes - weird!
o = demo_compose('pyobj', None, None, {}, **PARANOIA_0)
print o, o.__class__

o = demo_compose('pyobj', '__main__.Foo_old', None, {'a':123,'b':456}, **PARANOIA_0)
print o, o.__class__, o.__dict__

o = demo_compose('pyobj', '__main__.Foo_new', None, {'a':123,'b':456}, **PARANOIA_0)
print o, o.__class__, o.__dict__

o = demo_compose('pyobj', '__main__.Foo_slots', None, {'a':123,'b':456}, **PARANOIA_0)
print o, o.__class__, o.__dict__

#
# 'blob'
#

# pick something that requires cPickling
orig = re.compile('abc')

args = decompose( orig, allow_rawpickles=1, allow_replicants=0 )
print repr(orig)
print args
print args[2].encoding,repr(args[2].encoded)
o = demo_compose( *args, **PARANOIA_0 )

print orig,'--->',o


