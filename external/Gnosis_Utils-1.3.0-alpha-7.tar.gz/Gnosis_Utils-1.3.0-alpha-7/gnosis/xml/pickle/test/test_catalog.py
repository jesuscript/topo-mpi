"""
'Catalog' test - pickle/unpickle 'one of everything', in
a variety of ways.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import gnosis.xml.pickle as xml_pickle
from gnosis.xml.pickle.getclass import add_class_to_store
from gnosis.pyconfig import pyconfig
from gnosis.xml.pickle.extras import object_slowcmp

import sys
sys.path.insert(0,'.')
import t_atoms, t_containers

from types import *

def test_values( valuesMap, classOld, classNew, classSlots ):
    """
    valuesMap = dict of values to try pickling/unpickling
    classOld = an old-style class
    classNew = a new-style class, without slots
    classSlots = a new-style class, with slots
                 (caller is responsible for setting __slots__
                 to match valuesMap.keys())
    """
    print valuesMap
    
    # test #1 - pickle valuesMap at toplevel
    print "---- TEST #1 - pickled at toplevel ---"
    x = xml_pickle.dumps( valuesMap )
    #print x
    o = xml_pickle.loads( x,0 )

    if o != valuesMap:
        for key in valuesMap.keys():
            if o[key] != valuesMap[key]:
                print "DIFF ",key,o[key],valuesMap[key]

        raise "ERROR(1)"
    
    # test #2 - pickle inside a toplevel list
    print "---- TEST #2 - pickled inside toplevel builtin ----"
    x = xml_pickle.dumps( [valuesMap] )
    #print x
    o = xml_pickle.loads( x,0 )

    if o[0] != valuesMap:
        raise "ERROR(2)"

    # test #3 - set values as attributes in an old-style class
    print "---- TEST #3 - Attributes of an old-style class ----"
    o = classOld()
    for k,v in valuesMap.items():
        setattr(o,k,v)
    
    x = xml_pickle.dumps(o)
    #print x

    o2 = xml_pickle.loads(x,0)

    # note that o2 != o, even though they are equal

    # test equality
    if o2.__class__ != o.__class__:
        raise "ERROR(3)"

    for k,v in valuesMap.items():
        if getattr(o2,k) != v:
            raise "ERROR(4)"

    if not object_slowcmp(o,o2):
        raise "ERROR (4.5)"
        
    # test #4 - set values as attributes in a new-style class
    print "---- TEST #4 - Attributes of a new-style class ----"	
    o = classNew()
    for k,v in valuesMap.items():
        setattr(o,k,v)
    
    x = xml_pickle.dumps(o)
    #print x
    o2 = xml_pickle.loads(x,0)

    # test equality
    if o2.__class__ != o.__class__:
        raise "ERROR(5)"

    for k,v in valuesMap.items():
        if getattr(o2,k) != v:
            raise "ERROR(6)"

    if not object_slowcmp(o,o2):
        raise "ERROR (6.5)"
            
    # test #5 - set values as attributes in a class with __slots__
    print "---- TEST #5 - Attributes of a new-style class with __slots__ ----"
    o = classSlots()
    for k,v in valuesMap.items():
        setattr(o,k,v)
    
    x = xml_pickle.dumps(o)
    #print x
    o2 = xml_pickle.loads(x,0)

    # test equality
    if o2.__class__ != o.__class__ or \
           o2.__slots__ != o.__slots__:
        print o.__class__,o.__slots__
        print o2.__class__,o2.__slots__		
        raise "ERROR(7)"

    for k,v in valuesMap.items():
        if getattr(o2,k) != v:
            raise "ERROR(8)"

    if not object_slowcmp(o,o2):
        raise "ERROR (8.5)"
            
    failed_toplevel_pickle = []
    failed_toplevel_unpickle = []
    
    # test #6, test each item as a toplevel
    for k,v in valuesMap.items():
        #print k,v
        try:
            x = xml_pickle.dumps(v)
        except:
            failed_toplevel_pickle.append( (k,v) )

        v2 = xml_pickle.loads(x,0)
        if v != v2:
            failed_toplevel_unpickle.append( (k,v) )			

    if len(failed_toplevel_pickle):
        raise "FAILED TOPLEVEL PICKLE "+str(failed_toplevel_pickle)

    if len(failed_toplevel_unpickle):
        raise "FAILED TOPLEVEL UNPICKLE " + str(failed_toplevel_unpickle)
    
class ClassOldStyle:
    pass

if pyconfig.Have_ObjectClass():
    class ClassNewStyle(object):
        pass
else:
    # just fake it for older Pythons
    class ClassNewStyle:
        pass

def makeClassSlots( valuesMap ):
    if pyconfig.Have_Slots():
        # new a new ClassSlots for each set of values
        exec("class ClassSlots(object): __slots__ = %s" % \
             repr(tuple(valuesMap.keys())))
    else:
        # fake it for older Pythons
        exec("class ClassSlots: __slots__ = ('fake slots')")

    # interesting .. although ClassSlots.__module__ is __main__,
    # it cannot be found in the __main__ namespace (due to being
    # defined in a function; if the above exec() were in inline
    # below, it ClassSlots WOULD be in the __main__ namespace.

    # anyways, in order for the unpickler to find it, it has
    # to be put into the store manually
    add_class_to_store(ClassSlots,'__main__.ClassSlots')
    return ClassSlots

print "**************************************************************************"
print "****** Atoms                                                     *********"
print "**************************************************************************"

def MyMainFunction(): pass

# add a function from __main__ since that's a different code path, for Python <= 2.2
all_atoms = t_atoms.Atoms
all_atoms['atom_mymain_function'] = MyMainFunction

test_values(all_atoms, ClassOldStyle, ClassNewStyle,
            makeClassSlots( all_atoms ))

print "**************************************************************************"
print "****** SubclassAtoms, NO attributes                              *********"
print "**************************************************************************"

test_values(t_atoms.SubclassAtoms_NoAttr, ClassOldStyle, ClassNewStyle,
            makeClassSlots( t_atoms.SubclassAtoms_NoAttr ))


print "**************************************************************************"
print "****** SubclassAtoms, WITH attributes                            *********"
print "**************************************************************************"

test_values(t_atoms.SubclassAtoms_Attr, ClassOldStyle, ClassNewStyle,
            makeClassSlots( t_atoms.SubclassAtoms_Attr ))

print "**************************************************************************"
print "****** Containers                                                *********"
print "**************************************************************************"

test_values(t_containers.Containers, ClassOldStyle, ClassNewStyle,
            makeClassSlots( t_containers.Containers ))

print "**************************************************************************"
print "****** SubclassContainers, NO attributes                         *********"
print "**************************************************************************"

test_values(t_containers.SubclassContainers_NoAttr, ClassOldStyle, ClassNewStyle,
            makeClassSlots( t_containers.SubclassContainers_NoAttr ))

print "**************************************************************************"
print "****** SubclassContainers, WITH attributes                       *********"
print "**************************************************************************"

test_values(t_containers.SubclassContainers_Attr, ClassOldStyle, ClassNewStyle,
            makeClassSlots( t_containers.SubclassContainers_Attr ))

print "** OK **"
