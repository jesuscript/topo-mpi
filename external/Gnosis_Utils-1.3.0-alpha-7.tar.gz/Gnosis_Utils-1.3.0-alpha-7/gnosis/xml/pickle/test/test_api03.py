"""
load(), loads() can be called in 6 different ways, for purposes
of backward compatibility. Test them all.

(Note: load/loads use 'grok_load_args' to figure out which
API the user meant to call, so that is used here for testing.)
"""

from gnosis.xml.pickle.api import grok_load_args
from gnosis.xml.pickle import SEARCH_STORE, SEARCH_NO_IMPORT, \
     SEARCH_ALL, SEARCH_NONE, \
     XMLUnpicklingError, setParanoia
import gnosis.xml.pickle

# silence the deprecation warnings
gnosis.xml.pickle.NO_DEPRECATION_MSGS = 1

parms = [
    (-1,SEARCH_ALL,1),(0,SEARCH_NO_IMPORT,1),
    (1,SEARCH_STORE,1),(2,SEARCH_STORE,0)
    ]

# load(xml,paranoia=..), positional arg
for paranoia,class_search,allow_replicants in parms:
    opts = grok_load_args(paranoia)
    if opts != {'allow_replicants':allow_replicants,
                'class_search': class_search}:
        print allow_replicants,class_search,opts
        raise "ERROR"	

# load(xml,paranoia=..), keyword arg
for paranoia,class_search,allow_replicants in parms:
    opts = grok_load_args(paranoia=paranoia)
    if opts != {'allow_replicants':allow_replicants,
                'class_search': class_search}:
        print allow_replicants,class_search,opts
        raise "ERROR"

# load(xml,class_search=SEARCH_..), positional arg
for flag in [SEARCH_ALL,SEARCH_NO_IMPORT,SEARCH_STORE,SEARCH_NONE]:	
    opts = grok_load_args(flag)
    if opts != {'class_search': flag}:
        print opts
        raise "ERROR"

# load(xml,class_search=SEARCH_..), keyword arg
for flag in [SEARCH_ALL,SEARCH_NO_IMPORT,SEARCH_STORE,SEARCH_NONE]:	
    opts = grok_load_args(None,class_search=flag)
    if opts != {'class_search': flag}:
        print opts
        raise "ERROR"	

# load(xml), without setting global paranoia first - it should
# use default of paranoia=1
opts = grok_load_args(None)
if opts != {'allow_replicants':1, 'class_search': SEARCH_STORE}:
    raise "ERROR"

# load(xml) after an explicit setParanoia will use that value
parms = [
    (-1,SEARCH_ALL,1),(0,SEARCH_NO_IMPORT,1),
    (1,SEARCH_STORE,1),(2,SEARCH_STORE,0)
    ]
for paranoia,class_search,allow_replicants in parms:
    setParanoia(paranoia)
    opts = grok_load_args(None)
    if opts != {'allow_replicants':allow_replicants,
                'class_search': class_search}:
        raise "ERROR"	

# do a full set of class_search & allow_replicants to ensure
# they all pass thru OK
for flag in [SEARCH_ALL,SEARCH_NO_IMPORT,SEARCH_STORE,SEARCH_NONE]:

    # allow_replicants = 0
    opts = grok_load_args(None,class_search=flag, allow_replicants=0)
    if opts != {'allow_replicants':0,
                'class_search': flag}:
        raise "ERROR"

    # allow_replicants = 1
    opts = grok_load_args(None,class_search=flag, allow_replicants=1)
    if opts != {'allow_replicants':1,
                'class_search': flag}:
        raise "ERROR"			

# do the same with positional args
for flag in [SEARCH_ALL,SEARCH_NO_IMPORT,SEARCH_STORE,SEARCH_NONE]:

    # allow_replicants = 0
    opts = grok_load_args(flag, 0)
    if opts != {'allow_replicants':0,
                'class_search': flag}:
        raise "ERROR"

    # allow_replicants = 1
    opts = grok_load_args(flag, 1)
    if opts != {'allow_replicants':1,
                'class_search': flag}:
        raise "ERROR"
    
# not allowed to mix paranoia & (class_search|allow_replicants) like this
try:
    grok_load_args(0,class_search=SEARCH_STORE)
    raise "ERROR"
except XMLUnpicklingError:
    pass

# not allowed to mix paranoia & (class_search|allow_replicants) like this
try:
    grok_load_args(SEARCH_STORE,paranoia=0)
    raise "ERROR"
except XMLUnpicklingError:
    pass

# not allowed to mix paranoia & (class_search|allow_replicants) like this
try:
    grok_load_args(0,allow_replicants=1)
    raise "ERROR"
except XMLUnpicklingError:
    pass

# not allowed to give paranoia as both positional & kwarg
try:
    grok_load_args(0,paranoia=1)
    raise "ERROR"
except XMLUnpicklingError:
    pass

print "** OK **"
