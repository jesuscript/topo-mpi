"""
  idmaker - Given an integer, create a short id for it.
            The smaller the number, the shorter the id.
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

i_to_alpha = ['']*52
alpha_to_i = {}
initted = 0

def init():
    global initted, i_to_alpha, alpha_to_i
    
    if initted:
        return
    
    for i in range(26):
        i_to_alpha[i] = chr(ord('A')+i)
        i_to_alpha[i+26] = chr(ord('a')+i)
        alpha_to_i[chr(ord('A')+i)] = i
        alpha_to_i[chr(ord('a')+i)] = i+26		

    initted = 1
    
def id_to_alpha( n ):

    txt = ''
    
    # special case
    if n == 0: return 'A'
    
    while n >= 52:
        n,r = divmod( n, 52 )
        txt = i_to_alpha[r] + txt

    if n > 0:
        txt = i_to_alpha[n] + txt

    return txt

def alpha_to_id( txt ):
    n = 0
    
    for c in txt:
        n *= 52
        n += alpha_to_i[c]

    return n

def check_range( a,b ):
    print "Check [%d,%d]" % (a,b)
    for i in range(a,b):
        s = id_to_alpha(i)
        j = alpha_to_id(s)

        if i != j:
            raise Exception("ERROR %s,%s,%s" % (i,s,j))

def test():

    #init()

    # sample some regions over 32-bit space
    check_range(         0,     100000)
    check_range(   1000000,    1100000)
    check_range(  10000000,   10100000)
    check_range( 100000000,  100100000)
    check_range(1000000000, 1000100000)
    check_range(2**32-100001, 2**32-1)

    print id_to_alpha(2**32-1)
    print '%X' % (2**32-1)

    #print "OK"

    #for i in range(60):
    #	print i, id_to_alpha(i), alpha_to_id(id_to_alpha(i))

    from time import time

    NR = 500000

    t1 = time()

    for i in range(NR):
        s = id_to_alpha(i)

    td = time()-t1
    print "%.1f/sec" % (NR/td)

# auto-init on import
init()

if __name__ == '__main__':
    test()
    
    
