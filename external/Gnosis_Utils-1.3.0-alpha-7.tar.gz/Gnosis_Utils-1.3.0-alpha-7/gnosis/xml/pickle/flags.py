#
# ** DEPRECATED FUNCTIONS **
#
# These will hopefully go away in a few xml.pickle revisions --fpm
#

from gnosis.xml.pickle import deprecation

PARANOIA = 1            # default: security model of xml_pickle-0.51

HAVE_SET_PARANOIA = 0

def setParanoia(val):
    global PARANOIA, HAVE_SET_PARANOIA
    PARANOIA = val
    HAVE_SET_PARANOIA = 1
    deprecation("Global setParanoia() is deprecated; pass class_search & allow_replicants parameters to load/loads instead.")
    
def getParanoia():
    # this is called internally - don't warn again
    return PARANOIA




