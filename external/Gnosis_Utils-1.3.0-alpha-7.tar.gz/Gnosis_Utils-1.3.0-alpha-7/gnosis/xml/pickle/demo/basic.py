"""
Drop-in replacements for pickle.loads() and pickle.dumps().

These offer NONE of the extra features of xml.pickle, but are 
useful if you want to get a quick-start and learn more later.

See "basic_safe.py" for a version of this demo that does use some of
the extra features.

FYI - you can replace pickle.load()/dump() in the same way, I just did loads/dumps here.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

#=====================================================================================
# You can cut & paste this into your code ...
#=====================================================================================
from gnosis.xml.pickle import dumps as xml_dumps, loads as xml_loads, SEARCH_ALL

def dumps(obj):
    """
    Pickle obj and return XML string.
    
    Drop-in replacement of pickle.dumps().
    Offers NO extra safety or other features of xml.pickle.
    """
    return xml_dumps(obj,
                    # allow fallback on cPickle if I can't handle data
                    allow_rawpickles=1)

def loads(xml):
    """
    Take XML string from dumps() and return original object.
    
    Drop-in replacement for pickle.loads().
    NO extra safety or other features of xml.pickle.
    """
    return xml_loads(xml,
                    # allow xml.pickle to import any needed modules
                    class_search=SEARCH_ALL,
                    # want to bail out if it cannot load classes (like pickle.loads() does)
                    allow_replicants=0,
                    # allow data from previous xml.pickle versions
                    min_accept='1.1',
                    # allow fallback on cPickle if I can't handle data
                    allow_rawpickles=1)
                    
#=============================================================================
# End of cut & paste code.
#
# Show a little demo ...
#=============================================================================

class Foo:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
        
    def __str__(self):
        return "Hello from Foo! A=%s, B=%s, C=%s" % (repr(self.a),repr(self.b),repr(self.c))

# Put a couple of Foo objects in a compound object
l = {
        "aaa": Foo(123, "Hello", u"World"),
        "bbb": [1, 2, Foo(456, (4,5,6), "4 5 6")]
        }
        
print "ORIGINAL OBJECTS: "
print "-----------------"

# print Foo objects
print l['aaa']
print l['bbb'][2]

# pickle to XML
xml = dumps(l)
del l # delete original, to make sure nothing cheats! :-)

print "\nUNPICKLED OBJECTS:"
print   "------------------"

# unpickle
obj = loads(xml)
# show that Foo objects are alive
print obj['aaa']
print obj['bbb'][2]

