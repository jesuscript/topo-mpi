"""
One typical chore when maintaining a long-lived codebase is having
to gracefully upgrade user data to match changes in internal data structures.

This demo shows a way to use xml.pickle to make it easier. Using this method, 
you don't have to plan for upgrades - you can add them as needed along the way.

Here, I'm using a Client data structure that changes over time:
---------------------------------------------------------------
# version 1 - naive, no versioning info
class Client:
    def __init__(self, first, last):
        self.first = first
        self.last = last

# version 2: adds version info & email address
class Client:
    def __init__(self, first, last, email):
        self.version = 2
        self.first = first
        self.last = last
        self.email = email

# version 3: rename first->first_name and last->last_name
class Client:
    def __init__(self, first, last, email):
        self.version = 3
        self.first_name = first
        self.last_name = last
        self.email = email		
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import loads as xml_loads, dumps as xml_dumps, SEARCH_NO_IMPORT
from gnosis.xml.pickle.extensions import LoadOnlyExtension

class Client(object):
    def __str__(self):
        # assume a version 3 Client for printing purposes
        s = "Client, version=%d:\n" % self.version
        s += "   First: %s\n" % self.first_name
        s += "   Last: %s\n" % self.last_name
        s += "   Email: %s\n" % self.email
        
        return s
    
# make a version-1 Client
c1 = Client()
c1.first = "Joe"
c1.last = "Smith"

# make a version-2 Client
c2 = Client()
c2.version = 2
c2.first = "Mary"
c2.last = "Doe"
c2.email = "marydoe@doe.a.deer"

# make a version-3 Client
c3 = Client()
c3.version = 3
c3.first_name = "John"
c3.last_name = "Core"
c3.email = "john@core.dump"

# put clients in some arbitrary data structure
clients = {
    "main": ['blah', c1, 'hello world', c2],
    "extra": [1, 2, c3, 4]
}

"""
An xml.pickle extension to auto-upgrade Client data.

Note that the old data does NOT have to be tagged in any special way 
to be recognized. You can start a project without any consideration given
to future upgrade needs, and add a LoadOnlyExtension if needed later.
"""
class ClientUpgrader(LoadOnlyExtension):
    """
    This is called by the unpickler.
    Note that it doesn't matter how deeply the Client is nested in
    the pickled data. All I have to worry about is handling one
    Client object at a time.
    """
    def loader(self, obj):
        if isinstance(obj, Client):
            # is it version 1?
            if not hasattr(obj,'version'):
                self.v1_to_v2(obj)
                
            # is it version 2?
            if obj.version == 2:
                self.v2_to_v3(obj)
                
            # can add more versions in the future ...
            return obj
        else:
            # not a Client - return unmodified object
            return obj
            
    def v1_to_v2(self, client):
        "Convert version 1 to version 2"
        client.version = 2   # add version number
        client.email = None  # add email address
        
    def v2_to_v3(self, client):
        "Convert version 2 to version 3"
        client.version = 3  # bump version to 3
        
        # renamed from v2
        client.first_name = client.first
        client.last_name = client.last
        
        # remove old attributes
        del client.first
        del client.last

# save as a collection of mixed version {1,2,3} clients
xml = xml_dumps(clients)

# Pass my upgrader extension to the unpickler, so all clients will be
# updated to version 3 upon unpickling.
#
# FYI: You can either use 'register_extension(ext)' to globally register
#      the extension, or pass it on case-by-case basis to loads() as 'extensions=[ext]'.
ext = ClientUpgrader()

# Unpickle & auto-upgrade data.
#  FYI on flags:
#    SEARCH_NO_IMPORT = Unpickler is allowed to load any classes I've imported.
#    allow_replicants=0: I only want real classes - raise Exception if it cannot load them.
o = xml_loads(xml, SEARCH_NO_IMPORT, allow_replicants=0, extensions=[ext])

# show that all were converted to version 3
print o['main'][1]
print o['main'][3]
print o['extra'][2]

