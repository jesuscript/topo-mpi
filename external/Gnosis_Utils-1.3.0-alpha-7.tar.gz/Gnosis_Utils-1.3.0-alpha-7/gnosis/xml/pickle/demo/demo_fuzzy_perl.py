"""
Similar to demo_fuzzy.py, but goes even further and performs extra-permissive
type coercion ("Perl-ish"):
    
    o Rounds numeric values
    
    o Treats strings like "123.12" as numbers.
    
    o [1,2,3] == (1,2,3)
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, unregister_extension
from gnosis.xml.pickle.extras import xmlequal, norm_xml
from gnosis.pyconfig import pyconfig
from types import *
import math, re, sys

class PerlishFuzzifier(StackableExtension):
    """
    An extension that performs a Perl-ish sort of data coercion, in addition
    to rounding values as in demo_fuzzy.py
    
    Like demo_fuzzy.py, this is a "write-only" extension - you 
    probably wouldn't want to unpickle the resulting stream.
    """
    def __init__(self, eps):
        StackableExtension.__init__(self, 'PerlishFuzzifier')	
        self.eps = eps

    def set_eps(self, eps):
        "Set rounding precision"
        self.eps = eps
        
    def roundfloat(self, f, eps):
        "Round a floating point number to the closest eps increment."
        
        #print "ROUND %f, eps=%f" % (f,eps)
        
        mf = f/eps
        r = mf - math.floor(mf)
        if r >= 0.5:
            rounded = (math.floor(mf)+1.0)*eps
        else:
            rounded = math.floor(mf)*eps
        
        #print "ROUNDED ",rounded
        
        return rounded
        
    def pickle(self, obj):
        if type(obj) in [IntType,LongType]:
            # convert ints & longs to (rounded) floats
            return (self.roundfloat(float(obj), self.eps), None, {})

        elif type(obj) is FloatType:
            # round floats to eps precision
            return (self.roundfloat(obj, self.eps), None, {})

        elif type(obj) in [StringType,UnicodeType]:
            # strip leading/trailing spaces
            text = obj.rstrip().lstrip()
            
            # does it look numeric?
            if re.match('^[+\-]?[0-9\.]+$',text):
                return (self.roundfloat(float(text), self.eps), None, {})
            
            # use case-insensitive string comparisons
            return (text.upper(), None, {})

        elif type(obj) in [TupleType,ListType]:
            # have to coerce BOTH tuples and lists so they'll have the
            # same XML stream representation 
            return (list(obj), None, {})			
            
        # I don't know what to do with obj, so ignore it
        return self.ignore(obj)

#
# Create two objects that will be equal after lots of data coercion
#
objA = [
            "123.42",  # will be coerced to numeric
            
            # the dict keys will be converted to uppercase
            {'pounds': 4.81,
             'meters': 32.12,
             'LiteRs': u"132.76"},
             
            # lists & tuples are coerced to the same thing
            (1.12, 2.61, 6.43)
        ]
        
objB = [
            123.4,
            {'PouNds': 4.77,
             'MEteRs': 32.08,
             'liters': 132.82},
             
            [1.08, 2.58, 6.37]
        ]
        
# add a set() if Python supports it.
if pyconfig.Have_BuiltinSet():
    objA.append( set(["aA", 'BB', 'cc', 'Dd', 'Ee', '198.76', -443.12]) )

if pyconfig.Have_BuiltinSet():
    objB.append( set(['eE', 'bB', 198.81, 'AA',u"-443.09",'Cc','dd']) )

# just for fun, make objA a tuple instead of a list
objA = tuple(objA)

# There is a subtlety here that is difficult to explain, but the
# bottom line is that if you write an Extension that changes dict keys
# or set/frozenset items, and you want two non-equal objects to
# produce the same XML stream after coercion, then pass deepcopy=1.
#
# This subtlety only affects comparison of NON-equal objects that have
# been coerced into equal objects. It does NOT affect single object
# pickling (i.e. the object_sha() for objA and objB are each deterministic,
# even if not equal to each other).

# round values to 0.1 precision
ext = PerlishFuzzifier(0.1)

# should be equal with 0.1 precision (note I have to pass 'ext_basictypes=1' here
# so that my extension will get basic types like int,float,etc.)
print "Expect 'True':",xmlequal(objA, objB, deepcopy=1, extensions=[ext], ext_basictypes=1)

#xA = norm_xml(objA, deepcopy=1, extensions=[ext])
#xB = norm_xml(objB, deepcopy=1, extensions=[ext])
#from difflib import unified_diff
#print '\n'.join(list(unified_diff(xA.splitlines(),xB.splitlines())))

# should NOT be equal with 0.01 precision
ext.set_eps(0.01)
print "Expect 'False':",xmlequal(objA, objB, deepcopy=1, extensions=[ext], ext_basictypes=1)

