"""
Here, an Extension is created to round all numeric data within an object.
This allows you to easily compare two non-equal objects to within a 
given numeric precision.

This could also be useful when comparing objects across different
CPU architectures, where the floating point precision isn't the same.
You could round the values to a precision that both machines support,
and do the comparison.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.extensions import StackableExtension, register_extension, unregister_extension
from gnosis.xml.pickle.extras import xmlequal, norm_xml
from types import *
import re, sys
import math

class NumericFuzzifier(StackableExtension):
    """
    An extension to round all numeric data to 'eps' precision.
    This is a "write-only" extension, i.e. the objects are only pickled,
    never unpickled, so I don't have to implement the full interface here.
    """
    def __init__(self, eps):
        StackableExtension.__init__(self, 'NumericFuzzifier')		
        self.eps = eps

    def set_eps(self, eps):
        "Set rounding precision"		
        self.eps = eps

    def roundfloat(self, f):
        "Round a floating point number to the closest eps increment."
        
        #print "ROUND %f, eps=%f" % (f,eps)
        
        mf = f/self.eps
        r = mf - math.floor(mf)
        if r >= 0.5:
            rounded = (math.floor(mf)+1.0)*self.eps
        else:
            rounded = math.floor(mf)*self.eps
        
        #print "ROUNDED ",rounded
        
        return rounded
        
    def pickle(self, obj):
        if type(obj) in [IntType,LongType]:
            # convert ints & longs to rounded floats
            return (self.roundfloat(float(obj)), None, {})
        elif type(obj) is FloatType:
            # round floats
            return (self.roundfloat(obj), None, {})
        elif type(obj) is ComplexType:
            # round each part of complex value
            return ("%s:%s" % (self.roundfloat(obj.real),self.roundfloat(obj.imag)), None, {})
            
        # I don't know what to do with obj, so ignore it
        return self.ignore(obj)
        
# Create two test objects that are equal when rounded to integer values.
#
# note that it doesn't matter how deeply nested the
# structure is - the values are passed one-by-one to the extension

objA = [
            123, 
            345L,
            {
                "apples": 3,
                "pears": 9.5,
                "grapes": 3.9
            },
            21.45+87.43j
        ]

    
objB = [
            123.143, 
            345.499,
            {
                "apples": 3.48,	
                "pears": 10,
                "grapes": 4,		
            },
            21.22+87.13j
        ]

# convert objects to integer precision (0 decimal digits)
ext = NumericFuzzifier(1)
register_extension(ext)

# they should be equal (note I have to pass 'ext_basictypes=1' here
# so that my extension will get basic types like int,float,etc.)
print "Expect 'True': ",xmlequal(objA, objB, ext_basictypes=1)

# try again with precision of 0.1
ext.set_eps( 0.1 )

# they should NOT be equal at 0.1 precision
print "Expect 'False': ",xmlequal(objA, objB, ext_basictypes=1)

# try a different object, with 0.01 precision
ext.set_eps(0.01)

objA = [12.3445, 2.3387, (3.4213, 4.5551), 574.321+485.234j]
objB = [12.3412, 2.3412, (3.4192, 4.5612), 574.318+485.227j]

# they should be equal with 0.01 precision
print "Expect 'True': ",xmlequal(objA, objB, ext_basictypes=1)

# remove extension so I can try something else
unregister_extension(ext)

# if you don't want to bother with registering/unregistering the extension, 
# you can also do it this like ...
ext.set_eps(0.01)

# should be equal
print "Expect 'True': ",xmlequal(objA, objB, extensions=[ext], ext_basictypes=1)

# run again at 0.001 and they should not be equal
ext.set_eps(0.001)

# should not be equal
print "Expect 'False': ",xmlequal(objA, objB, extensions=[ext], ext_basictypes=1)

