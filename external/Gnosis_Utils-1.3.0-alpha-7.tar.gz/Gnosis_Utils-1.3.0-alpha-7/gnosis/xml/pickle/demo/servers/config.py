
# Pick two addresses that the servers can use on the local machine.

# address for ObjectServer
OBJ_SERVER_ADDR = ('127.0.0.1',8080)

# address for SourceServer
SOURCE_SERVER_ADDR =  ('127.0.0.1', 8081)

#-----------------------------------------------------------------
# The rest of these use the values above.
# Shouldn't need to edit these, unless you want to customize.
#-----------------------------------------------------------------

# URIs for Pyro server - demo does NOT use the Pyro NameServer,
# so use absolute URIs.
PYRO_OBJ_SERVER = 'PYROLOC://%s:%d/ObjectServer' % (OBJ_SERVER_ADDR[0],
                                                    OBJ_SERVER_ADDR[1])
PYRO_SOURCE_SERVER = 'PYROLOC://%s:%d/SourceServer' % (SOURCE_SERVER_ADDR[0],
                                                       SOURCE_SERVER_ADDR[1])

