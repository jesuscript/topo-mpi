
# make '..' visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from libserv_xmlrpc import ObjServerThread, SourceServerThread
from config import OBJ_SERVER_ADDR, SOURCE_SERVER_ADDR
from baseserver import BaseDemoServer

class XMLRPCDemoServer(BaseDemoServer):

    def run(self):
        BaseDemoServer.run(self,
                           ObjServerThread, OBJ_SERVER_ADDR,
                           SourceServerThread, SOURCE_SERVER_ADDR,
                           'http://%s:%d' % (SOURCE_SERVER_ADDR[0],
                                             SOURCE_SERVER_ADDR[1]))

if __name__ == '__main__':
    XMLRPCDemoServer().run()
