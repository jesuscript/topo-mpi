
# make '..' visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from gnosis.xml.pickle import dumps, loads
from gnosis.xml.pickle.extensions import register_extension
from ext import PyroSourceFetcher
from config import PYRO_OBJ_SERVER, PYRO_SOURCE_SERVER
import Pyro.core

Pyro.core.initClient()

oserv = Pyro.core.getProxyForURI(PYRO_OBJ_SERVER)
ext = PyroSourceFetcher()

register_extension(ext)

got_list = []

while 1:
    # Get the next XML pickled object from the server
    # by calling method 'get()' over XML-RPC
    xml = oserv.get()
    if not len(xml):
        break # no more objects, exit loop

    print xml

    # Once PyroSourceFetcher is registered, a simple loads()
    # does all the magic of fetching source as needed.
    obj = loads(xml)
    print "GOT OBJ ",obj
    got_list.append(obj)

# stop both servers
oserv.quit()

sserv = Pyro.core.getProxyForURI(PYRO_SOURCE_SERVER)
sserv.quit()

# got_list is: [test_function, list] - pass list to test_function
got_list[0](got_list[1])

xml = dumps(got_list[1],short_ids=1,sorted=1)
# When I dumps, I'll see 'SourceFetcher_Store.' on the front of
# the objects that SourceFetcher created. This is intentional, to
# not step on surrounding namespace, but I need to strip them out
# so I can do an XML compare.
xml = xml.replace('SourceFetcher_Store.','')

# Now the XML from the original object (server side), and my
# unpickled object should match!
if xml != got_list[2]:
    open('a.xml','w').write(got_list[2])
    open('b.xml','w').write(xml)
    raise "ERROR"

print "** OK **"
