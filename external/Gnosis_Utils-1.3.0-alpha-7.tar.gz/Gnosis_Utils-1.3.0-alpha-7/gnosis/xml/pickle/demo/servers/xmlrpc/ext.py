from extbase import BaseSourceFetcher
from xmlrpclib import ServerProxy

class XMLRPCSourceFetcher(BaseSourceFetcher):
    """
    Specialization of BaseSourceFetcher to use an XML-RPC connection.

    It assumes that it is talking to an xmlrpc.serv_source.SourceServer.
    """
    
    def __init__(self):
        # set my extension name
        BaseSourceFetcher.__init__(self, 'SourceProvider')
    
    def get_class_src(self, server_addr, name):
        "Fetch source code for the named class from the server."
        server = ServerProxy(server_addr)
        src = server.get_class(name)
        return src

    def get_function_src(self, server_addr, name):
        "Fetch source code for the named function from the server."
        server = ServerProxy(server_addr)
        src = server.get_function(name)
        return src

