from threading import Thread
from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.objmodel import get_classtag
import inspect
import Pyro.core

class ObjServer(Pyro.core.ObjBase):
    """
    ObjServer -

    Takes a list of objects and sends them one at a time over a Pyro
    connection, in reponse to the client calling 'get()'.

    Note that the ObjServer has NO IDEA that source code will eventually
    be sent over to the client. It simply calls dumps() and sends the XML.
    """
    
    def __init__(self, objlist):
        Pyro.core.ObjBase.__init__(self)		
        self.objlist = objlist

        self.want_exit = 0
        
    def get(self):
        "Pop next obj from list and return its XML"
        if len(self.objlist):
            o = self.objlist[0]
            self.objlist = self.objlist[1:]

            # I have no idea that dumps() will do all the magic
            # to call the SourceTagger_Ext
            xml = dumps(o,short_ids=1)
            return xml
        else:
            return ''

    def quit(self):
        print "ObjServer quitting ..."
        self.want_exit = 1
        
class SourceServer(Pyro.core.ObjBase):
    """
    SourceServer -

    Supplies source code for classes & functions to clients over
    a Pyro connection.

    Methods:
       get_class( full_dotted_name )
       get_function( full_dotted_name )
   """
    def __init__(self, export_classes, export_funcs):
        Pyro.core.ObjBase.__init__(self)
        
        self.export_classes = export_classes
        self.export_funcs = export_funcs

        self.want_exit = 0
        
    # I made 'get_function' and 'get_class' seperate functions,
    # so that theoretically a class and a function can have
    # the same name if needed.
    
    def get_function(self, name):
        """Called from the client to get source code for the named
        function (name is basename, for simplicity here.)"""
        for f in self.export_funcs:
            if get_classtag(f) == name:
                return inspect.getsource(f)

        raise "FUNCTION %s NOT FOUND" % name
    
    def get_class(self, name):
        """Called from the client to get source code for named
        class (name is basename, for simplicity here.)"""
        for k in self.export_classes:
            if get_classtag(k) == name:
                return inspect.getsource(k)

        raise "CLASS %s NOT FOUND" % name

    def quit(self):
        print "SourceServer quitting ..."		
        self.want_exit = 1
        
class ObjServerThread(Thread):
    
    def __init__(self, serv_addr, objlist):
        Thread.__init__(self)
        self.addr = serv_addr
        self.objlist = objlist

    def keep_going(self):
        return self.server.want_exit != 1
    
    def run(self):
        self.server = ObjServer(self.objlist)
        daemon = Pyro.core.Daemon(host=self.addr[0],
                                  port=self.addr[1])
        uri = daemon.connect(self.server, 'ObjectServer')
        print "OBJECT SERVER RUNNING on %s:%d" % (self.addr[0],self.addr[1])
        print "(URI = %s)" % uri
        
        daemon.requestLoop(condition=self.keep_going,timeout=1)

class SourceServerThread(Thread):
    def __init__(self, serv_addr, export_classes, export_funcs):
        Thread.__init__(self)
        self.addr = serv_addr
        self.export_classes = export_classes
        self.export_funcs = export_funcs

    def keep_going(self):
        return self.server.want_exit != 1
    
    def run(self):
        self.server = SourceServer(self.export_classes, self.export_funcs)
        
        daemon = Pyro.core.Daemon(host=self.addr[0],
                                  port=self.addr[1])
        uri = daemon.connect(self.server, 'SourceServer')

        print "SOURCE SERVER RUNNING on %s:%d" % (self.addr[0],self.addr[1])
        print "(URI = %s)" % uri
        
        daemon.requestLoop(condition=self.keep_going, timeout=1)


