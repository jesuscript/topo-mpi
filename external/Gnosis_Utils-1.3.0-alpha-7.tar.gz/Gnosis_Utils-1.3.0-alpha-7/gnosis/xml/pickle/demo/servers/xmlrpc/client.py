# make .. visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from gnosis.xml.pickle import dumps, loads
from gnosis.xml.pickle.extensions import register_extension
import netbase
from ext import XMLRPCSourceFetcher
from config import OBJ_SERVER_ADDR, SOURCE_SERVER_ADDR
from xmlrpclib import ServerProxy

oserv = ServerProxy('http://%s:%d' % (OBJ_SERVER_ADDR[0], OBJ_SERVER_ADDR[1]))

ext = XMLRPCSourceFetcher()

register_extension(ext)

got_list = []

while 1:
    # Get the next XML pickled object from the server
    # by calling method 'get()' over XML-RPC
    xml = oserv.get()
    if not len(xml):
        break # no more objects, exit loop

    print xml

    obj = loads(xml)
    print "GOT OBJ ",obj
    got_list.append(obj)

# stop both servers
oserv.quit()
sserv = ServerProxy('http://%s:%d' % (SOURCE_SERVER_ADDR[0], SOURCE_SERVER_ADDR[1]))
sserv.quit()

# got_list is: [test_function, list] - pass list to test_function
got_list[0](got_list[1])

xml = dumps(got_list[1],short_ids=1,sorted=1)
# When I dumps, I'll see 'SourceFetcher_Store.' on the front of
# the objects that SourceFetcher created. This is intentional, to
# not step on surrounding namespace, but I need to strip them out
# so I can do an XML compare.
xml = xml.replace('SourceFetcher_Store.','')

# Now the XML from the original object (server side), and my
# unpickled object should match!
if xml != got_list[2]:
    open('a.xml','w').write(got_list[2])
    open('b.xml','w').write(xml)
    raise "ERROR"

print "** OK **"
