
from gnosis.xml.pickle import dumps

#----------------------------------------------------------------------
# Here are the classes/functions to be pickled and sent over
# the network.
#----------------------------------------------------------------------
class Foo:
    """An oldstyle class with no coredata or attrs, to make sure
    the parser gets the state transitions correct."""
    def run(self):
        print "Hello from Foo", self.__dict__

class Bar:
    """An oldstyle class with attributes."""
    def __init__(self,a,b):
        self.a = a
        self.b = b
        
    def run(self):
        print "Hello from Bar", self.__dict__

class FooList(list):
    def run(self):
        print "Hello from FooList", self[:], self.__dict__

class FooDict(dict):
    def run(self):
        print "Hello from FooDict", self.items(), self.__dict__

def func_add1(n):
    return n+1

def test_function1(objlist):
    """Test function that runs on the *client* side.
    Checks the list of objects that was sent from the server.

    Expects: [Foo(), func_add1, Foo]
    """

    print "** Test Function 1 is running **"

    # show that class-instance relationships were maintained

    # get Foo() and Foo from list
    foo_i = objlist[0]['bbb']
    foo_c = objlist[1][1][1]

    # make sure Foo() is an instance of Foo
    if not isinstance(foo_i, foo_c):
        raise "ERROR"

    # make sure run Foo.run() works
    foo_i.run()

    # get Bar() and Bar from list
    bar_i = objlist[2][1]['eee']
    bar_c = objlist[2][2][2][3]

    # make sure Bar() is instance of Bar
    if not isinstance(bar_i, bar_c):
        raise "ERROR"

    # check attrs
    if bar_i.a != 'hello' or bar_i.b != 'Bar':
        raise "ERROR"
    
    # make sure Bar.run() works
    bar_i.run()
    
    print "** Test Function 1 - OK **"

#--------------------------------------------------------------------------
# Create a list of objects to pass to the client.
#
# This is intentionally convoluted to show that it doesn't matter how
# deeply an object is nested, the SourceTagger_Ext will find the objects
# that it is supposed to handle.
#
# Note that test_function1 (above) needs to be synced with
# any changes made here.
#--------------------------------------------------------------------------
def get_objlist():
    objlist = [{'aaa':12.34j, 'bbb': Foo(), 'ccc': func_add1},
               ['hello world', (123, Foo, 456)],
               ('abcd', {'ddd': 1111, 'eee': Bar('hello','Bar')},
                [555,444,(0,1,2,Bar,3,4),333])]

    return objlist

def get_testfunc():
    return test_function1

def get_class_exports():
    return [Foo, Bar, FooList, FooDict]	

def get_func_exports():
    return [func_add1, test_function1]

    
