
# a few handy network things

import socket

class Socket:
    "Convenience wrapper."
    def __init__(self, server_addr):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(server_addr)
        self.rfile = self.socket.makefile('rb',-1)
        self.wfile = self.socket.makefile('wb',0)

    def __del__(self):
        self.socket.close()

def send(server_addr, msg):
    """
    Send 'msg\n' to server without expecting a response.
    """
    s = Socket(server_addr)
    s.wfile.write('%s\n' % msg)

def send_get(server_addr, msg):
    """
    A simple send-get sequence:
        Connect to server_addr
        Write 'msg\n'
        Read 'size\n' (where size=integer)
        Read size bytes.

    Returns bytes from server.
    """
    s = Socket(server_addr)
    # send msg
    s.wfile.write('%s\n' % msg)
    # read size of response
    size = int(s.rfile.readline())
    # read response
    resp = s.rfile.read(size)
    return resp

#
# Base classes for TCP servers.
#

import SocketServer

class TCPBaseServer(SocketServer.TCPServer):
    allow_reuse_address = 1
    do_exit = 0

    def __init__(self, *args):
        SocketServer.TCPServer.__init__(self, *args)

    def signal_quit(self):
        self.do_exit = 1
        
    def serve_till_quit(self):
        "Serve requests until do_exit is set."
        while not self.do_exit:
            self.handle_request()

class TCPBaseHandler(SocketServer.StreamRequestHandler):

    def handle_cmd(self,cmd):
        raise "Must be implemented in subclass."
    
    def handle(self):
        # read command from client
        cmd = self.rfile.readline()

        print "Server %s got req: %s" % (str(self),cmd)
        
        if cmd[:4] == 'quit':
            # tell server to exit
            self.server.signal_quit()
            return
        else:
            self.handle_cmd(cmd)

#-----------------------------------------------------
# XML-RPC wrapper
#-----------------------------------------------------
from SimpleXMLRPCServer import SimpleXMLRPCServer

class XMLRPCBaseServer(SimpleXMLRPCServer):
    """
    Small wrapper for SimpleXMLRPCServer so it won't
    fail with 'address already in use' when stopping/starting
    the server (seems to happen mainly on posix).
    See:
       http://mail.python.org/pipermail/python-list/2002-October/126178.html
    """
    allow_reuse_address = 1
    do_exit = 0

    def serve_till_quit(self):
        while not self.do_exit:
            self.handle_request()

    def _dispatch(self, method, params):
        # call 'quit()' to tell server to exit
        if method == 'quit':
            self.do_exit = 1
            return ''
        else:
            return SimpleXMLRPCServer._dispatch(self, method, params)	
