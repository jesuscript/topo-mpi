from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.extensions import register_extension
from extbase import SourceTagger_Ext
import userobj

class BaseDemoServer:

    def run(self,
            ObjServerThreadClass, ObjServerAddr,
            SourceServerThreadClass, SourceServerAddr,
            SourceFetchAddr ):
        
        #-----------------------------------------------------------------
        # Create & register the xml.pickle ClassExtension
        #-----------------------------------------------------------------

        # SourceTagger_Ext takes a list classes/functions that it should transform
        # for client-side fetching. It won't touch anything else.

        class_exports = userobj.get_class_exports()
        func_exports = userobj.get_func_exports()
        objlist = userobj.get_objlist()

        # Create XML from objlist *before* registering the SourceTagger
        # extension. The client should be able to recreate this same
        # XML stream. [Dump here instead of in userobj, since items need
        # to be dumped as 'userobj.' instead of '__main__.']
        xml_before = dumps(objlist,short_ids=1,sorted=1)

        send_list = [userobj.get_testfunc(), objlist, xml_before]

        print "BEFORE ",xml_before

        # Create extension.
        ext = SourceTagger_Ext( SourceFetchAddr,
                                export_classes = class_exports,
                                export_funcs = func_exports )


        # Register extension.
        #
        # Note that the Extension must be registered under the same name
        # on the client side (it doesn't matter that it's a different
        # class on the client side - matching is by name).
        #
        # After this point, a simple dumps() will do all the magic.
        register_extension(ext)

        #-----------------------------------------------------
        # Create Object Server thread
        #-----------------------------------------------------

        # ObjServerThread takes a list of objects to send to the client
        t1 = ObjServerThreadClass(ObjServerAddr, send_list)
        t1.start()

        #-----------------------------------------------------
        # Create Source Server thread
        #-----------------------------------------------------
        t2 = SourceServerThreadClass(SourceServerAddr,
                                     class_exports, func_exports)
        t2.start()

        # Run servers until the client tells them to stop.
        t1.join()
        t2.join()
    
