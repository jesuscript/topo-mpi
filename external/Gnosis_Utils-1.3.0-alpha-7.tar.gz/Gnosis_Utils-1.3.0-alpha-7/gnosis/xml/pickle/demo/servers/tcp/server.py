# make '..' visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from config import OBJ_SERVER_ADDR, SOURCE_SERVER_ADDR
from baseserver import BaseDemoServer
from libserv_tcp import ObjServerThread, SourceServerThread
        
class TCPDemoServer(BaseDemoServer):

    def run(self):
        BaseDemoServer.run(self,
                           ObjServerThread, OBJ_SERVER_ADDR,
                           SourceServerThread, SOURCE_SERVER_ADDR,
                           SOURCE_SERVER_ADDR)

if __name__ == '__main__':
    TCPDemoServer().run()
    
