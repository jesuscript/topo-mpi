"""
The ClassExtensions that do the work of transforming
the object to be sent over the network.
"""

from gnosis.xml.pickle.extensions import ClassExtension
from gnosis.xml.pickle.objmodel import get_classtag
from netbase import Socket

class SourceTagger_Ext(ClassExtension):
    """
    SourceTagger_Ext takes a list of classes and functions
    whose source it should export over the network. They are
    transformed such that a SourceFetcher_Ext on the client
    end can handle them.
    """
    
    def __init__(self, source_server, export_classes, export_funcs):
        """
        source_server = Address of the server that will actually
                        provide the source code when the client
                        requests it.

                        It should be (addr,port) if the source
                        server is a TCP server, a URL if the
                        source server is an XML-RPC server, etc.
                        
        export_classes = A list of classes that are to
                         be transformed.
                         
        export_funcs = A list of functions that are to
                       be transformed.
        """
        
        # set my extension name
        ClassExtension.__init__(self, 'SourceProvider')
        
        self.source_server = source_server
        self.export_classes = export_classes
        self.export_funcs = export_funcs
        self.have_seen = {}

    #
    # Note: SourceTagger_Ext lives on the server side, so only
    # has to implement the 'pickle' portion of the protocol.
    # The client will implement the 'unpickle' portion.
    #
    
    def pickle(self, obj):
        # metadata will contain the server address, etc.
        # The client side will use this in order to fetch
        # the source code from the source_server.
        metadata = {}

        # attach server address
        metadata['server_addr'] = self.source_server

        matched = 0

        # is it a class I want to handle?
        if obj in self.export_classes:
            ref_obj = obj
            mtype = 'class'
            matched = 1

        # is it an instance of a class I want to handle?
        for k in self.export_classes:
            if not matched and isinstance(obj,k):
                # keep a reference to the *CLASS*, not the object,
                # since it the source code for CLASSES that is
                # being sent to the client
                ref_obj = k	 
                mtype = 'instance'
                matched = 1
                break

        # is it a function I want to handle?
        for f in self.export_funcs:
            if not matched and obj == f:
                ref_obj = f
                mtype = 'function'
                matched = 1
                
        if matched:
            # If I've already sent the given ref_obj, don't send it
            # over again - just send a reference. This is not just
            # to save bandwidth -- primarily this is to ensure that,
            # e.g. all "Foo" classes are the same on the other end.
            if self.have_seen.has_key(id(ref_obj)):
                metadata['type'] = mtype
                metadata['refid'] = '%s' % id(ref_obj)
            else:
                metadata['type'] = mtype
                metadata['name'] = get_classtag(ref_obj)
                metadata['id'] = '%s' % id(ref_obj)

                self.have_seen[id(ref_obj)] = ref_obj				

            # note the object is returned *as-is*; only some metadata
            # has been attached
            return (obj, metadata, {})
        else:
            # not a class/function I'm supposed to handle
            return self.ignore(obj)

import sys, imp, new
from gnosis.xml.pickle.replicants import make_module_path
from gnosis.xml.pickle.objmodel import split_classtag, compose_top_nocore
from gnosis.xml.pickle import add_class_to_store, SEARCH_STORE

class BaseSourceFetcher(ClassExtension):
    """
    A SourceFetcher is the ClassExtension that runs on the client side,
    retrieving class/function source code as needed, using the metadata
    provided by the SourceTagger.

    The majority of the code is independent of the physical/logical
    connection type, so is placed in this base class.
    """
    
    def __init__(self, ext_name):
        
        # set my extension name
        ClassExtension.__init__(self, ext_name)
        
        # create an empty & non-publicly visible module
        # to store classes & functions in
        self.root_module = imp.new_module('SourceFetcher_Store')
        self.have_seen = {}

    def pickle(self,obj):
        return self.ignore(obj)
    
    def get_class_src(self, server_addr, name):
        raise "Subclass must implement method."

    def get_function_src(self, server_addr, name):
        raise "Subclass must implement method."

    def get_object_src(self, server_addr, metadata):
        "Fetch source code for the class or function given by the metadata."
        if metadata['type'] == 'function':
            return self.get_function_src(server_addr, metadata['name'])
        elif metadata['type'] in ['class','instance']:
            return self.get_class_src(server_addr, metadata['name'])
        else:
            raise "Bad metadata[type]"
        
    def fetch_object(self, metadata):
        """Retrieve the class or function specified by metadata, either
        by requesting it from the server, or getting from the have_seen map."""
        if metadata.has_key('refid'):
            # I've seen it before, get the existing class
            class_or_func = self.have_seen[metadata['refid']]
        else:
            # Haven't seen it before, retrieve source code from server
            src = self.get_object_src( metadata['server_addr'], metadata )
            modname,classname = split_classtag(metadata['name'])

            # create (or get existing) fake module path under
            # my root_module
            submod = make_module_path(modname, self.root_module)

            # create class inside submodule namespace
            exec(src) in submod.__dict__
            class_or_func = getattr(submod, classname)

            # save to refmap
            self.have_seen[metadata['id']] = class_or_func
            
        return class_or_func
    
    def unpickle_begin_nocore(self, typestr, metadata, *unused):

        if metadata['type'] in ['class','instance']:

            klass = self.fetch_object(metadata)

            # am I unpickling a class or an instance?
            if metadata['type'] == 'class': # class
                return klass
            else: # instance
                
                # Add class to store under its *FULL* name, i.e.
                # SourceFetcher_Store.Whatever.Name, *NOT* Whatever.Name,
                # so that it won't override any other modules with
                # the same name.
                add_class_to_store(klass)

                # now let objmodel do the hard part :-)
                obj = compose_top_nocore(typestr, get_classtag(klass),
                                         metadata.get('#newargs',None),
                                         # has to be in the store; no replicants
                                         SEARCH_STORE, 0)[0]
                return obj

        elif metadata['type'] == 'function':
            func = self.fetch_object(metadata)
            return func
        
        else:
            raise "Unknown extension type."

    def unpickle_finalize(self, obj, propmap):
        # note that all attributes have been set into obj, all the
        # setstate, initargs, etc. stuff is already done, so all
        # I need to do is add anything from my propmap. I didn't
        # add anything, so I'm done.
        pass

