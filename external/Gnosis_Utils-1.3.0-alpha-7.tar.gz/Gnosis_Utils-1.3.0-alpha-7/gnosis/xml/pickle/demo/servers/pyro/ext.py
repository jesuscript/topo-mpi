
from extbase import BaseSourceFetcher
import Pyro.core

class PyroSourceFetcher(BaseSourceFetcher):
    """
    Specialization of BaseSourceFetcher to use a Pyro connection.

    It assumes that it is talking to a pyro.libserv_pyro.SourceServer
    """	
    def __init__(self):
        BaseSourceFetcher.__init__(self, 'SourceProvider')
    
    def get_class_src(self, server_addr, name):
        "Fetch source code for the named class from the server."
        server = Pyro.core.getProxyForURI(server_addr)
        src = server.get_class(name)
        return src

    def get_function_src(self, server_addr, name):
        "Fetch source code for the named function from the server."
        server = Pyro.core.getProxyForURI(server_addr)
        src = server.get_function(name)
        return src

