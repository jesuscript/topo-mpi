
from netbase import XMLRPCBaseServer
from threading import Thread
from gnosis.xml.pickle import dumps
import inspect
from gnosis.xml.pickle.objmodel import get_classtag

class ObjServer(XMLRPCBaseServer):
    """
    ObjectServer -

    Takes a list of objects and sends them one at a time over XML-RPC
    in reponse to the client calling 'get()'.

    Note that the ObjServer has NO IDEA that source code will eventually
    be sent over to the client. It simply calls dumps() and sends the XML.
    """
    def __init__(self, *args):
        XMLRPCBaseServer.__init__(self, *args)
        print "OBJECT SERVER RUNNING"
        
class ObjServerRequestHandler:

    def __init__(self, objlist):
        self.objlist = objlist

    def get(self):
        "Pop next obj from list and return its XML"
        if len(self.objlist):
            o = self.objlist[0]
            self.objlist = self.objlist[1:]

            xml = dumps(o,short_ids=1)
            return xml
        else:
            return ''
        
class ObjServerThread(Thread):

    def __init__(self, serv_addr, objlist):
        Thread.__init__(self)
        self.addr = serv_addr
        self.objlist = objlist
        
    def run(self):
        s = ObjServer(self.addr)
        self.handler = ObjServerRequestHandler(self.objlist)
        s.register_instance(self.handler)
        s.serve_till_quit()

class SourceServer(XMLRPCBaseServer):
    """
    SourceServer -

    Supplies source code for classes & functions to clients.
    Commands:

        get_class full_dotted_name
        get_function full_dotted_name

    Sends response as:
        size (int)
        data
    """
    def __init__(self, *args):
        XMLRPCBaseServer.__init__(self, *args)
        print "SOURCE SERVER RUNNING"

class SourceServerHandler:
    def __init__(self, export_classes, export_funcs):
        self.export_classes = export_classes
        self.export_funcs = export_funcs

    # I made 'get_function' and 'get_class' seperate functions,
    # so that theoretically a class and a function can have
    # the same name if needed.
    
    def get_function(self, name):
        """Called from the client to get source code for the named
        function (name is basename, for simplicity here.)"""
        for f in self.export_funcs:
            if get_classtag(f) == name:
                return inspect.getsource(f)

        raise "FUNCTION %s NOT FOUND" % name
    
    def get_class(self, name):
        """Called from the client to get source code for named
        class (name is basename, for simplicity here.)"""
        print "GET CLASS ",name
        for k in self.export_classes:
            if get_classtag(k) == name:
                return inspect.getsource(k)

        raise "CLASS %s NOT FOUND" % name
        
class SourceServerThread(Thread):

    def __init__(self, serv_addr, export_classes, export_funcs):
        Thread.__init__(self)
        self.addr = serv_addr
        self.export_classes = export_classes
        self.export_funcs = export_funcs
        
    def run(self):
        s = SourceServer(self.addr)
        self.handler = SourceServerHandler(self.export_classes,
                                           self.export_funcs)
        s.register_instance(self.handler)
        s.serve_till_quit()		
