
from netbase import TCPBaseServer, TCPBaseHandler
from threading import Thread
from gnosis.xml.pickle import dumps
import re, inspect
from gnosis.xml.pickle.objmodel import get_classtag

class ObjServer(TCPBaseServer):
    """
    ObjectServer -

    Takes a list of objects and sends them one at a time as XML,
    in reponse to the client sending a 'get' command.

    Note that the ObjServer has NO IDEA that source code will eventually
    be sent over to the client. It simply calls dumps() and sends the XML.
    """
    def __init__(self, objlist, *args):
        TCPBaseServer.__init__(self, *args)
        self.objlist = objlist

        print "OBJECT SERVER RUNNING"
        
    def getnext(self):
        "Pop next obj from list and return its XML"
        if len(self.objlist):
            o = self.objlist[0]
            self.objlist = self.objlist[1:]

            xml = dumps(o,short_ids=1)
            return xml
        else:
            return ''

class ObjServerRequestHandler(TCPBaseHandler):

    def handle_cmd(self, cmd):
        if cmd[:3] == 'get':
            # send the next object to the client
            xml = self.server.getnext()
            self.wfile.write('%d\n' % len(xml))
            self.wfile.write(xml)

class ObjServerThread(Thread):

    def __init__(self, serv_addr, objlist):
        Thread.__init__(self)
        self.addr = serv_addr
        self.objlist = objlist
        
    def run(self):
        s = ObjServer(self.objlist, self.addr, ObjServerRequestHandler)
        s.serve_till_quit()

class SourceServer(TCPBaseServer):
    """
    SourceServer -

    Supplies source code for classes & functions to clients.
    Commands:

        get_class full_dotted_name
        get_function full_dotted_name

    Sends response as:
        size (int)
        data
    """
    def __init__(self, export_classes, export_funcs, *args):
        TCPBaseServer.__init__(self, *args)
        
        self.export_classes = export_classes
        self.export_funcs = export_funcs

        print "SOURCE SERVER RUNNING"

    # I made 'get_function' and 'get_class' seperate functions,
    # so that theoretically a class and a function can have
    # the same name if needed.
    
    def get_function_source(self, name):
        """Called from the client to get source code for the named
        function (name is basename, for simplicity here.)"""
        for f in self.export_funcs:
            if get_classtag(f) == name:
                return inspect.getsource(f)

    def get_class_source(self, name):
        """Called from the client to get source code for named
        class (name is basename, for simplicity here.)"""
        for k in self.export_classes:
            if get_classtag(k) == name:
                return inspect.getsource(k)

class SourceServerHandler(TCPBaseHandler):

    def handle_cmd(self, cmd):

        src = None

        m = re.match('get_class\s+(\S+)', cmd)
        if m:
            src = self.server.get_class_source(m.group(1))

        m = re.match('get_function\s+(\S+)', cmd)
        if m:
            src = self.server.get_function_source(m.group(1))

        if src is None:
            self.wfile.write('BAD COMMAND: %s\n' % cmd)
        else:
            self.wfile.write('%d\n' % len(src))
            self.wfile.write(src)
            
class SourceServerThread(Thread):

    def __init__(self, serv_addr, export_classes, export_funcs):
        Thread.__init__(self)
        self.addr = serv_addr
        self.export_classes = export_classes
        self.export_funcs = export_funcs
        
    def run(self):
        s = SourceServer(self.export_classes, self.export_funcs,
                         self.addr, SourceServerHandler)
        s.serve_till_quit()		
