# make '..' visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from extbase import BaseSourceFetcher
from netbase import Socket

class TCPSourceFetcher(BaseSourceFetcher):
    """
    Specialization of BaseSourceFetcher to run over a
    basic TCP/IP connection.

    It assumes that it is talking to a tcp.serv_source.SourceServer.
    """	
    def __init__(self):
        # set my extension name
        BaseSourceFetcher.__init__(self, 'SourceProvider')

    def get_class_src(self, server_addr, name):
        "Fetch source code for the named class from the server."
        s = Socket(server_addr)
        s.wfile.write('get_class %s\n' % name)
        size = int(s.rfile.readline())
        src = s.rfile.read(size)
        return src

    def get_function_src(self, server_addr, name):
        "Fetch source code for the named function from the server."
        s = Socket(server_addr)
        s.wfile.write('get_function %s\n' % name)
        size = int(s.rfile.readline())
        src = s.rfile.read(size)
        return src	

