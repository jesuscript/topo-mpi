
# make '..' visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from libserv_pyro import ObjServerThread, SourceServerThread
from config import PYRO_SOURCE_SERVER, OBJ_SERVER_ADDR, SOURCE_SERVER_ADDR
import Pyro.core
from baseserver import BaseDemoServer

class PyroDemoServer(BaseDemoServer):

    def run(self):
        Pyro.core.initServer()
        
        BaseDemoServer.run(self,
                           ObjServerThread, OBJ_SERVER_ADDR,
                           SourceServerThread, SOURCE_SERVER_ADDR,
                           PYRO_SOURCE_SERVER)

if __name__ == '__main__':
    PyroDemoServer().run()
