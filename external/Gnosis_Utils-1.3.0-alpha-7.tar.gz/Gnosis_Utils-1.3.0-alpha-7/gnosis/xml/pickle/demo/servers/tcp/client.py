
# make .. visible in sys.path
import sys, os
sys.path.insert(0,os.path.abspath('..'))

from gnosis.xml.pickle import dumps, loads
from gnosis.xml.pickle.extensions import register_extension
import netbase
from ext import TCPSourceFetcher
from config import OBJ_SERVER_ADDR, SOURCE_SERVER_ADDR

class TCPDemoClient:

    def run(self):
        
        ext = TCPSourceFetcher()

        # Note that the Extension must be registered under the same name
        # as on the server side (it doesn't matter that it's a different
        # class on the client side - matching is by name).
        register_extension( ext )

        got_list = []

        while 1:
            # Get the next XML pickled object from the server
            # by sending command 'get'
            xml = netbase.send_get(OBJ_SERVER_ADDR, 'get')
            if not len(xml):
                # no more objects - exit loop
                break

            print xml
            obj = loads(xml)
            print "GOT OBJ ",obj
            got_list.append(obj)

        # cleanup by stopping the two servers
        netbase.send( OBJ_SERVER_ADDR, 'quit' )
        netbase.send( ('127.0.0.1',8081), 'quit' )

        # got_list is: [test_function, list] - pass list to test_function
        got_list[0](got_list[1])

        xml = dumps(got_list[1],short_ids=1,sorted=1)
        # When I dumps, I'll see 'SourceFetcher_Store.' on the front of
        # the objects that SourceFetcher created. This is intentional, to
        # not step on surrounding namespace, but I need to strip them out
        # so I can do an XML compare.
        xml = xml.replace('SourceFetcher_Store.','')

        # Now the XML from the original object (server side), and my
        # unpickled object should match!
        if xml != got_list[2]:
            open('a.xml','w').write(got_list[2])
            open('b.xml','w').write(xml)
            raise "ERROR"

        print "** OK **"

if __name__ == '__main__':
    TCPDemoClient().run()
    
