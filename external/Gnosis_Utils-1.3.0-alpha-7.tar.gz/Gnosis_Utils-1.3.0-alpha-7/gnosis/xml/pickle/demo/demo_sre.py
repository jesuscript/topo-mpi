from gnosis.xml.pickle.extensions import StackableExtension, register_extension
from gnosis.xml.pickle import dumps, loads
import re

re_type = type(re.compile('aaa'))

class FancyRegexPlugin(StackableExtension):
    "Turn a compiled regex into type='string'"
    def __init__(self):
        StackableExtension.__init__(self, 'sre.fancy')
        
        self.flags_list = [(re.I,'I'),(re.L,'L'),(re.M,'M'),(re.S,'S'),
                            (re.U,'U'), (re.X,'X')]
        
    def pickle(self, obj):
        "Turn a compiled regex into a string"
        if type(obj) != re_type:
            return self.ignore(obj) # not a regex, ignore
        
        # turn flags into a verbose string
        flags = []
        for f,s in self.flags_list:
            if obj.flags & f:
                flags.append( s )

        if len(flags):
            return (obj.pattern, None, {'flags': ','.join(flags)})
        else:
            return (obj.pattern, None, {})
    
    def unpickle(self, obj, coredata, propmap):
        "Take data from pickle() and recreate the compiled regex."
        flag = 0

        # split flag string
        flags = propmap.get('flags','').split(',')

        for f in flags:
            for g in self.flags_list:
                if g[1] == f:
                    flag += g[0]

        return re.compile(obj,flag)

re_list = [
    re.compile('aaa', re.I),
    re.compile('abc[d-z]def', re.M|re.I|re.S),
    ]

print "Stock extension"
print dumps(re_list)

register_extension(FancyRegexPlugin())

print "With 'fancy' extension"
print dumps(re_list)


