"""
See README. This is the server side. It must be run with Python 2.2+.

Since xmlrpclib isn't available on earlier Pythons, this uses a simple TCPServer.
"""

# pick some unused port on the local machine
SERVER_ADDRESS = ('127.0.0.1',8080)

import sys, os
sys.path.insert(0,os.path.join('..','..','test'))
import t_atoms, t_containers, t_classes

from gnosis.xml.pickle import dumps, loads, SEARCH_STORE, add_class_to_store
from gnosis.xml.pickle.misc import pprint_obj
import SocketServer

class MyServer(SocketServer.TCPServer):
    allow_reuse_address = 1
    do_exit = 0
    
    def signal_quit(self):
        self.do_exit = 1
        
    def serve_till_quit(self):
        "Serve requests until 'signal_quit()' is called."
        while not self.do_exit:
            self.handle_request()
            
    def __init__(self, *args):
        SocketServer.TCPServer.__init__(self, *args)

        # create some objects to send to the client
        self.objlist = []
        self.expect = None
        
        # int+attrs
        o = t_atoms.SInt_noattr(1234)
        o.aaa = 'hello'

        self.objlist.append(o)

        # be explicit and put classes in store
        add_class_to_store(t_atoms.SInt_noattr)
        
        # with __slots__ *AND* __dict__
        o = t_classes.SampleSlotsDictClass()
        # aaa,bbb,ccc are the __slots__
        o.aaa = 34.56789
        o.bbb = 45.6789
        # leave .ccc unused & add some __dict__ items also
        o.ddd = 11.22222
        o.eee = 22.33333
    
        self.objlist.append(o)

        add_class_to_store(t_classes.SampleSlotsDictClass)

        self.objlist.reverse()
        
    def get(self):
        "Get next object to send to client (as XML)"
        if len(self.objlist):
            o = self.objlist.pop()
            self.expect = o
            # print o verbosely, for information
            print "Server is sending:"
            pprint_obj(o)			
                
            xml = dumps(o)
            return xml
        else:
            self.expect = None
            return ''

    def put(self,xml):
        """
        The client unpickles the XML returned from 'get()', which creates
        replicants, then repickles the replicants and sends me the
        resulting XML stream. When *I* load this stream, it should match
        the original object (saved in self.expect).

        Returns 'OK' or 'ERROR'.
        """
        
        try:
            # SEARCH_STORE is the default, but be explicit for demo purposes.
            # Since I put all the classes in the store, set allow_replicants=0.
            # This will make xml.pickle raise an exception if it can't
            # load the real class.			
            o = loads(xml,SEARCH_STORE,allow_replicants=0)
        except XMLUnpicklingError:
            return "ERROR"

        # modify self.expect in the same way that the client modified 'o'
        self.expect.xxyyzz = ('here is',u'a sample','modification',['whee'])

        # now, dump o & self.expect and see if they match
        x1 = dumps(o,short_ids=1,sorted=1)
        x2 = dumps(self.expect,short_ids=1,sorted=1)

        if x1 != x2:
            return "ERROR"

        # object matched
        return 'OK'
        
class MyRequestHandler(SocketServer.StreamRequestHandler):

    def handle(self):
        # read command from client
        cmd = self.rfile.readline()
        
        if cmd[:3] == 'get':
            # send the next object to the client
            xml = self.server.get()
            self.wfile.write('%d\n' % len(xml))
            self.wfile.write(xml)
            
        elif cmd[:3] == 'put':
            # client is sending XML back to me			
            size = int(self.rfile.readline())
            xml = self.rfile.read(size)
            msg = self.server.put(xml)
            self.wfile.write(msg)
            
        elif cmd[:4] == 'quit':
            # tell server to exit
            self.server.signal_quit()
            
#----------------------------------------------------------------
# Start the server
#----------------------------------------------------------------

s = MyServer(SERVER_ADDRESS, MyRequestHandler)
s.serve_till_quit()
