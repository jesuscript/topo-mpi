"""
See README. This is the client side. It can be run with any Python 2.0+.
"""
from gnosis.xml.pickle import loads, is_replicant, replicant_info, dumps
from gnosis.xml.pickle.misc import pprint_replicant

SERVER_ADDR = ('127.0.0.1',8080)

import socket
import sys

class Socket:
    "Convenience wrapper."
    def __init__(self, server_addr):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect( SERVER_ADDR )
        self.rfile = self.socket.makefile('rb',-1)
        self.wfile = self.socket.makefile('wb',0)

    def __del__(self):
        self.socket.close()
        
def get_xml( server_addr ):
    s = Socket(server_addr)
    s.wfile.write('get\n')
    size = int(s.rfile.readline())
    xml = s.rfile.read(size)
    return xml

def put_xml( server_addr, xml ):
    s = Socket(server_addr)
    s.wfile.write('put\n%s\n%s\n' % (len(xml),xml))
    # return server response
    return s.rfile.readline()

def send_quit( server_addr ):
    s = Socket(server_addr)
    s.wfile.write('quit\n')
    
while 1:
    # Get the next XML pickled object from the server
    xml = get_xml(SERVER_ADDR)
    if not len(xml):
        # no more objects - tell server to exit
        send_quit(SERVER_ADDR)
        break
    else:
        # Unpickle the XML. Since no classes are in the store,
        # this will always create replicants, regardless of Python version.
        # (SEARCH_STORE is the default.)
        o = loads(xml)
        if not is_replicant(o):
            raise "ERROR" # should NOT have created real object

        # pretty-print the replicant
        pprint_replicant(o)

        # Now, do a simple modification, redump the replicant & send back
        # to server. The server will then be able to reload the ORIGINAL object,
        # and see the modification.
        o.xxyyzz = ('here is',u'a sample','modification',['whee'])
        
        xml = dumps(o,allow_replicants=1)
        msg = put_xml(SERVER_ADDR, xml)
        if msg != 'OK':
            raise "ERROR"

print "** OK **"

        
        
        
