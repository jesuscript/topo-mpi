"""
Shows how to use statistics from dump/load.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import dumps_stats, loads_stats, SEARCH_NONE

class Foo:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c 
        
class Bar:
    pass
    
class Baz:
    def __init__(self):
        self.aaa = 111
    
d1 = {
        'aaa': 123.45,
        'bbb': ['hello','world'],
        'ccc': (6,5,4,3,2,1)
        }
        
f = Foo(d1, Bar(), Baz() )

xml,stats = dumps_stats(f)
#print xml

print "*** STATS from pickling ..."
print stats

# force replicants to be loaded to show those stats work
print "\n*** STATS from unpickling ..."
print "*** (Expect three replicants)"

o,stats = loads_stats(xml, SEARCH_NONE)
print stats

        

