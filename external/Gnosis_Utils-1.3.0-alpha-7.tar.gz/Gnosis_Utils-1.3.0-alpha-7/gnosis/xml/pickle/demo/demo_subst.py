"""
Demo showing how you can substitute one class for another
while unpickling.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import loads, dumps, SEARCH_STORE, add_class_to_store

class FooList(list):
    pass

f = FooList( [1,2,3,'Hello',(4,5,6)] )

xml = dumps(f)

class BarList(list):
    def show(self):
        print "Hello from BarList"
        print "My items are: ",self[:]
        
# tell unpickler to substitute BarList for FooList by
# registering BarList under the name '__main__.FooList'
add_class_to_store(BarList,'__main__.FooList')

o = loads(xml,SEARCH_STORE)
o.show()


