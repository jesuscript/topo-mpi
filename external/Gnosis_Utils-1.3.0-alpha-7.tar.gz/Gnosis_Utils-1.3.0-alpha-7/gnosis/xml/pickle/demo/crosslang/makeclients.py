
from gnosis.xml.pickle import dumps
from client import Client

class Blank(object):
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

# Create a data structure with Clients scattered through it. The various
# mining scripts will dig through and find them regardless of where they are.

my_big_dataset = {
    "In a list": [1, 2.3, Client('Mary', 'Doe', '123 Doe Lane', 12345)],
    "In a dict": {'aaa': 234, 'bbb': Client('John', 'Jones', '234 Blank Circle', 23456)},
    "In an object": Blank(12.34, Client('Joe', 'Doe', '345 Road Way', 34567), "hello world"),
    'by itself': Client('Jane', 'Jonesbury', '456 Drive Way', 45678)}

# using deepcopy=True lets the reader grab only the portion of the XML they want,
# without having to worry about back-references to data they don't want to parse
xml = dumps(my_big_dataset, deepcopy=True)

open('clients.xml', 'wb').write(xml)


