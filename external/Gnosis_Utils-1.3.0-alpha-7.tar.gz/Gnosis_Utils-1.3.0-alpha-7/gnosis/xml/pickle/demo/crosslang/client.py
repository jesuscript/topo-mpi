
class Client(object):
    def __init__(self, first='', last='', addr='', zipcode=''):
        self.first = first
        self.last = last
        self.addr = addr
        self.zipcode = zipcode

    def __str__(self):
        s =  "Client:\n"
        s += '-------\n'
        s += 'Name: %s %s\n' % (self.first,self.last)
        s += 'Address: %s\n' % self.addr
        s += 'ZIP: %d\n' % self.zipcode
        return s

