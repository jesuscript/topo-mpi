#
# Simple reader using ElementTree
#

from elementtree.ElementTree import Element, SubElement, ElementTree
from client import Client

tree = ElementTree(None, open('clients.xml','rb'))

client_list = []

# I don't care WHERE a client.Client is (or how deeply nested), 
# just find and extract them.
clients = [node for node in tree.getiterator() if node.attrib.get('class') == 'client.Client']

# extract each client
for client in clients:
    c = Client()
    # Here, I don't care what a 'client.Client' is, all I have to know
    # are the attributes I want to extract. They are stored in <attr> tags.
    for attr in client.findall('attr'):
        if attr.attrib['name'] == 'addr':				
            c.addr = attr.attrib['value']
            
        if attr.attrib['name'] == 'last':				
            c.last = attr.attrib['value']
    
        if attr.attrib['name'] == 'first':				
            c.first = attr.attrib['value']

        if attr.attrib['name'] == 'zipcode':				
            c.zipcode = int(attr.attrib['value'])
            
    client_list.append(c)
            
# show results
for c in client_list:
    print c


