
from array import array as pyarray
from gnosis.xml.pickle.extensions import StackableExtension, ClassExtension
from gnosis.xml.pickle import dumps, loads

class PyArrayStackable(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, 'array.b')
        self.mytype = type(pyarray('c',['a']))
        
    def pickle(self, obj):
        if type(obj) != self.mytype:
            return self.ignore(obj)
            
        return (obj.tostring(), obj.typecode, {})
        
    def unpickle(self, obj, coredata, propmap):
        return pyarray(coredata, obj)
        
class PyArrayClassExt(ClassExtension):
    def __init__(self):
        ClassExtension.__init__(self, 'array.b')
        self.mytype = type(pyarray('c',['a']))

    def pickle(self, obj):
        if type(obj) != self.mytype:
            return self.ignore(obj)

        # typecode is needed to create bare object, so must be in metadata
        return (obj.tostring(), {'typecode': obj.typecode}, {})

    def unpickle_begin_core(self, typestr, metadata, coredata, 
                    class_search, allow_replicants):
        
        return pyarray(metadata['typecode'], coredata)

    def unpickle_finalize(self, obj, propmap):
        return obj
        
all_arrays = {
    'char': pyarray('c', ['1','2','3','4']),
    'signed char': pyarray('b', [1,2,3,4]),
    'unsigned char': pyarray('B', [10,11,12,13]),
    'Unicode': pyarray('u', [unichr(123), unichr(456), unichr(789)]),
    'signed short': pyarray('h', [1234, 5678, 9012, 8234]),
    'unsigned short': pyarray('H', [1111,2222,3333,4444]),
    'signed int': pyarray('i', [-4321, -5432, -6543, -7654]),
    'unsigned int': pyarray('I', [4321, 5432, 6543, 7654]),
    'signed long': pyarray('l', [-54321, -65432, -76543, -87654]),
    'unsigned long': pyarray('L', [54321, 65432, 76543, 87654]),
    'float': pyarray('f', [1.234, 2.345, 3.456, 4.567]),	
    'double': pyarray('d', [1.234e12, 2.345e23, 3.456e34, 4.567e45]),
    }
    
print "ORIGINAL ",all_arrays

ext = PyArrayStackable()

xml = dumps(all_arrays, extensions=[ext], sorted=1)
print xml
print len(xml)

obj = loads(xml, extensions=[ext])
print obj

ext = PyArrayClassExt()

xml = dumps(all_arrays, extensions=[ext], sorted=1)
print xml
print len(xml)

obj = loads(xml, extensions=[ext])
print obj

