"""
Like "basic.py", but limits pickling/unpickling to only those classes that
are specifically marked as 'trusted'.

See "basic_even_safer.py" for an even safer (yet very flexible) way.
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import dumps as xml_dumps, loads as xml_loads, SEARCH_STORE, \
                        add_class_to_store

def dumps(obj):
    """
    Pickle obj and return XML string.
    """
    return xml_dumps(obj,
                    # do NOT allow fallback on cPickle if I can't handle data
                    # (this is the default value)
                    allow_rawpickles=0)

def loads(xml):
    """
    Take XML string from dumps() and return original object.
    """
    return xml_loads(xml,
                    # load only those classes that the caller says are OK
                    # (this is the default value)
                    class_search=SEARCH_STORE,
                    # bail out if I cannot load the real classes
                    allow_replicants=0,								
                    # do NOT allow data from previous xml.pickle versions
                    # (this is the default value)
                    min_accept='1.3',  
                    # do NOT allow fallback on cPickle if I can't handle data
                    # (this is the default value)
                    allow_rawpickles=0  )
                            
#=============================================================================
# Demo
#=============================================================================

class Foo:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
        
    def __str__(self):
        return "Hello from Foo! A=%s, B=%s, C=%s" % (repr(self.a),repr(self.b),repr(self.c))
        
# Tell xml.pickle that I trust class Foo, else it will refuse to load it
# due to setting 'class_search=SEARCH_STORE'
add_class_to_store(Foo)

# Put a couple of Foo objects in a compound object
l = {
        "aaa": Foo(123, "Hello", u"World"),
        "bbb": [1, 2, Foo(456, (4,5,6), "4 5 6")]
        }
        
print "ORIGINAL OBJECTS: "
print "-----------------"

# print Foo objects
print l['aaa']
print l['bbb'][2]

# pickle to XML
xml = dumps(l)
del l # delete original, to make sure nothing cheats! :-)

print "\nUNPICKLED OBJECTS:"
print   "------------------"

# unpickle
obj = loads(xml)
# show that Foo objects are alive
print obj['aaa']
print obj['bbb'][2]


