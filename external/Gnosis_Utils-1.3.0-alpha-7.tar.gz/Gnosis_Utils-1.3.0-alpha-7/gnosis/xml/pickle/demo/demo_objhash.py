"""
This demonstrates that xml.pickle can be used to generate an object
hash (SHA-1) that is repeatable over multiple runs and multiple Python versions.

By contrast, it demonstrates that pickle/cPickle cannot be used for this purpose,
since they will generate different streams between Python versions/OS and even
over multiple runs of the same version! (This is NOT a bug - the pickles
are correct, but pickle/cPickle make no guarantees on ordering.)

There is a possibility of the object_sha() varying across different CPUs, 
due (for example) to different floating point hardware/software implementations.
If that should occur, you can use a technique like that shown in demo_fuzzy.py 
to massage the data as appropriate for your application, to make a repeatable hash 
across different CPU types.

Here are the results of a sample run (using the randseed shown below). Test
object was generated on Python 2.0.
    
xml.pickle:
-----------
Python             object_sha(obj)                            object_sha(loads(dumps(obj)))
 2.0-x86-win32     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.1-x86-win32     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.2-x86-win32     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.3-x86-win32     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.4-x86-win32     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.4-x86-linux     e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.4-x86-freebsd   e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.4-alpha-osf1    e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 2.5a1-x86-win32   e9bf9c397339256aa32fb386a06812bf2a7e177f   e9bf9c397339256aa32fb386a06812bf2a7e177f
 
pickle:
-------
Python             SHA-1 of dumps()                           SHA-1 of dumps(loads(dumps()))
 2.0-x86-win32     86e8d140c034ec547f2ca156c9d3f430a8f4f415   4dcd2a7ab0abf9c22da7c1be2e22b625aa131026
 2.1-x86-win32     9c541305f2f0a00fd37e9bea7cc2943df42f64ed   ada81ec472fecd411a4a6ac13e5ede2d0a9b8915
 2.2-x86-win32     41147b98affdc06ec6531d6b255851a3a92783ec   d90e2c95fb3637aaf8c9741552af472a5440e290
 2.3-x86-win32     95fe7f3f90645fcbf14ddbff181cf6f356e4d8ad   59fb40f0c1cea5ced0b5b77798a329b19f5e0b8a
 2.4-x86-win32     f814f5ba7c60ec618cee672eb7e676bf6940d5b9   5d882441109d1af27a2a108d4c7d6244317788ba
 2.4-x86-linux     00fa93733b838eb8b25fbe51c801f1fc6cc438f8   93ae9b4b7c725a1a7ac1c2f9297f797be6a62eb4
 2.4-x86-freebsd   00fa93733b838eb8b25fbe51c801f1fc6cc438f8   93ae9b4b7c725a1a7ac1c2f9297f797be6a62eb4
 2.4-alpha-osf1    00fa93733b838eb8b25fbe51c801f1fc6cc438f8   93ae9b4b7c725a1a7ac1c2f9297f797be6a62eb4
 2.5a1-x86-win32   f814f5ba7c60ec618cee672eb7e676bf6940d5b9   5d882441109d1af27a2a108d4c7d6244317788ba
 
cPickle:
--------
Python             SHA-1 of dumps()                           SHA-1 of dumps(loads(dumps()))
 2.0-x86-win32     e9e8ec127fa927be4873cc691bb6b0c957a0dba5   5aac8515ab60f7561becac78a55a559ede613a34
 2.1-x86-win32     49b5ed73dcdd5733097f2912224392aedd143892   4fe9a10fb8fb5e56fd2d655f975d642edbdc17fc
 2.2-x86-win32     1fdab5fc67d74ec026edb2b91495b673bcdd1a31   03a21808eeb5e9b5a2d2ae1dc0da8669329b5f22
 2.3-x86-win32     b6e4a52997fcf3dca45954a7048274cfa189b4fd   651fdf4f774e5db1f9727233b3beebf8430f06e1
 2.4-x86-win32     73761ddc8dce388d241e8bf684923675eec9cddb   c1e5a280b7a3e1b1af72a3b72e0d368eeed41f65
 2.4-x86-linux     c14ff8f2129fe4ee94e9e86afe604cdea11e1773   da278a42658c3d099b60c9b7c96367f6e752ccb0
 2.4-x86-freebsd   c14ff8f2129fe4ee94e9e86afe604cdea11e1773   da278a42658c3d099b60c9b7c96367f6e752ccb0
 2.4-alpha-osf1    c14ff8f2129fe4ee94e9e86afe604cdea11e1773   da278a42658c3d099b60c9b7c96367f6e752ccb0
 2.5a1-x86-win32   73761ddc8dce388d241e8bf684923675eec9cddb   c1e5a280b7a3e1b1af72a3b72e0d368eeed41f65
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

import os, sys
import random
from gnosis.xml.pickle import dumps as xml_dumps, dumps_stats as xml_dumps_stats, loads as xml_loads, SEARCH_ALL
from gnosis.xml.pickle.extras import norm_xml, object_sha
import pickle, cPickle
import sha

sys.path.insert(0,os.path.abspath(os.path.join('..','test')))
import randstuff

TEST_XML_FILE = "hash_testobj.xml"

# Since different Python versions have slightly different random() functions,
# the generated test object would vary between Pythons. I want to be able to
# check the object_sha() consistency over a number of Python versions, so just
# create the test object once and reuse on subsequent runs.
def create_test_object():

    # pick a random seed so runs are repeatable (at least on a given Python version)
    random.seed(874593847534L)
    obj = randstuff.rand_obj(5)
    xml,st = xml_dumps_stats(obj, allow_replicants=0)
    print "# objects: %d" % st.nr_objects
    open(TEST_XML_FILE,'wb').write(xml)
    
def load_test_object():
    if not os.path.isfile(TEST_XML_FILE):
        print "*** CREATING TEST OBJECT ***"
        create_test_object()
        
    obj = xml_loads(open(TEST_XML_FILE,'rb').read(), SEARCH_ALL,
                    allow_replicants=0)
    return obj
    
# calc SHA-1 for a string (used to make SHA of pickle/cPickle streams)
def calc_sha(s):
    ssha = sha.new()
    ssha.update(s)
    return ssha.hexdigest()
    
obj = load_test_object()
h1 = object_sha(obj)

# dump to XML, unpickle, and show that the SHA-1 of the original
# matches the SHA-1 of the unpickled one
xml = xml_dumps(obj)
o2 = xml_loads(xml,SEARCH_ALL, allow_replicants=0)
h2 = object_sha(o2)
print "xml.pickle SHA:\n    orig:      %s\n    repickled: %s" % (h1, h2)

# dump obj, unpickle, then redump to show that the pickle changes!
p1 = pickle.dumps(obj)
o2 = pickle.loads(p1)
p2 = pickle.dumps(o2)
print "Pickle SHA:\n    orig:      %s\n    repickled: %s" % (calc_sha(p1),calc_sha(p2))

# dump obj, unpickle, then redump to show that the cPickle changes as well!
p1 = cPickle.dumps(obj)
o2 = cPickle.loads(p1)
p2 = cPickle.dumps(o2)
print "CPickle SHA:\n    orig:      %s\n    repickled: %s" % (calc_sha(p1),calc_sha(p2))

# finally, show that o2 still equals obj - wasn't messed up by cPickling
print "Still equal?:\n    orig:      %s\n    repickled: %s" % (object_sha(load_test_object()), object_sha(o2))

