"""
Sort of a 'Turing-completeness' test. This shows that 13 of the 16
basic types are technically redundant. By using ClassExtensions,
the 16 types can be recoded into a minimal set of 3.

The complete set of types is:
   int,float,complex,long,None,True,False,string,unicode,
   list,dict,set,frozenset,pyobj,function,class

They can be reduced to the minimum set:
   unicode, list, tuple
   
By folding the types as follows (note that NO data is lost!):

string, int, float, complex, long, None, True, False, class, function --> unicode
pyobj, dict, set, frozenset --> list
tuple --> tuple (unchanged)

[Note that both tuple and list are required, since they have
different coretypes. Although it would be possible to hack the
pickle core to make it possible to fold tuples into lists, that
makes the general case ugly. Having an object change core-type
(immutable vs. mutable) after creation (without changings obj id())
doesn't make sense on a basic level anyways. If it ever becomes
possible in Python to change a list into a tuple (or ANY object
into ANY other object) without changing its id(), then of course
a lot of assumptions will break .. and not just in xml.pickle :-)]
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle import loads,dumps
from gnosis.xml.pickle.extensions import ClassExtension, register_extension, \
     unregister_extension
from gnosis.xml.pickle.objmodel import get_data_attrs, get_classtag, \
     maketop_empty_core, maketop_immutable, decompose, maketop_class, \
     maketop_function
from gnosis.pyconfig import pyconfig

class SanityCheck(ClassExtension):
    """Just a sanity check to make sure nothing slips past the
    other two extension. The only things that should reach this point
    are lists, tuples, and unicode values."""
    
    def __init__(self):
        ClassExtension.__init__(self,'SanityCheck')
        
    def pickle(self, obj):
        typestr,classtag,coredata,attrs = decompose(obj,0,0)
        if (typestr not in ['tuple','list','string']) or \
            (typestr == 'string' and not isinstance(obj,unicode)):
            raise "You missed '%s' (%s)" % (typestr,repr(obj))

        return self.ignore(obj)

#--------------------------------------------------------------------
# Technically, ThingToUnicode and ThingToList could be combined in
# a single class. However, they are split here since they have
# difference coretypes (mutable vs. immutable). Makes it a little
# clearer to write it this way.
#--------------------------------------------------------------------

class ThingToUnicode(ClassExtension):
    """
    Turns the following things into unicode:
       string, int, float, complex, long, None, True, False, class, function

    Since unicode is returned, the immutable-core API has to be implemented here.
    (See extensions.py for more on that.)
    """
    def __init__(self):
        ClassExtension.__init__(self,'ThingToUnicode')
    
    def pickle(self, obj):
        # use decompose so I don't confuse ints & bools
        typestr,classtag,coredata,attrs = decompose(obj,0,0)
        
        if typestr == 'True':
            return (u'True', {}, {})
        elif typestr == 'False':
            return (u'False', {}, {})
        elif typestr == 'None':
            return (u'None', {}, {})
        elif typestr == 'class':
            return (unicode(get_classtag(obj)),
                    {'real-thing': u'class'},
                    {})
        elif typestr == 'function':
            return (unicode(get_classtag(obj)),
                    {'real-thing': u'function'},
                    {})		

        elif typestr == 'string' and isinstance(obj,str):
            return (unicode(obj),
                    # attach metadata
                    {'real-class': unicode(get_classtag(obj)),
                     'base-class': str },
                    # turn attrs into a property map
                    get_data_attrs(obj))

        elif typestr == 'numeric':
            for k in [int,long,float,complex]:
                if isinstance(obj,k):
                    # pickle numeric into a string. note this is insecure,
                    # and is NOT how xml.pickle does it normally.
                    # this is for demo purposes only :-)
                    metadata = 	{'real-class':unicode(get_classtag(obj)),
                                 'base-class':k}
                    return( unicode(repr(obj)), metadata,
                            get_data_attrs(obj))

            raise Exception("Unknown numeric??")
        
        else:
            return self.ignore(obj)

    def unpickle_begin_core(self, typestr, metadata, coredata,
                            class_search, allow_replicants):
        
        if metadata.get('real-class',None) != None:
            return maketop_immutable(metadata['base-class'],
                                     metadata['real-class'],
                                     coredata, None,
                                     class_search, allow_replicants,
                                     None)[0]
        
        if metadata.get('real-thing',None) == 'class':
            return maketop_class(coredata, None, class_search, allow_replicants)[0]

        if metadata.get('real-thing',None) == 'function':
            return maketop_function(coredata, None, class_search, allow_replicants)[0]
        
        if coredata == 'True':
            return True
        elif coredata == 'False':
            return False
        elif coredata == 'None':
            return None
        else:
            raise Exception("Huh?")

    def unpickle_finalize(self, obj, propmap):
        # restore attrs
        for key,val in propmap.items():
            setattr(obj, key, val)

class ThingToList(ClassExtension):
    """
    Turns the following things into lists:

       pyobj, dict, set, frozenset.

    Since it returns a list, the mutable-core API has to
    be implemented here.
    """
    def __init__(self):
        ClassExtension.__init__(self,'ThingToList')
    
    def pickle(self, obj):
        typestr,classtag,coredata,attrs = decompose(obj,0,0)

        if typestr == 'dict':
            return (obj.items(), # mutate to a list
                    # attach metadata
                    {'real-class': unicode(get_classtag(obj)),
                     'base-class': dict },
                    # turn attrs into a property map
                    attrs)

        if typestr == 'set':
            return (list(obj), # mutate to a list
                    # attach metadata
                    {'real-class': unicode(get_classtag(obj)),
                     'base-class': set },
                    # turn attrs into a property map
                    attrs)

        if typestr == 'frozenset':
            return (list(obj), # mutate to a list
                    # attach metadata
                    {'real-class': unicode(get_classtag(obj)),
                     'base-class': frozenset },
                    # turn attrs into a property map
                    attrs)		

        if typestr == 'pyobj':
            return [ chr, # mutate to anything w/out coredata
                     {'real-class': unicode(get_classtag(obj)), 
                      'base-class': object },
                     attrs]
            
        return self.ignore(obj)
    
    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        obj,is_replicant = maketop_empty_core(metadata['base-class'],  \
                           metadata['real-class'], None, \
                           class_search, allow_replicants, None)
        return obj
    
    def unpickle_set_coredata(self, typestr, obj, coredata):
        # remember: coredata is a list
        
        if isinstance(obj,dict):			
            for key,val in coredata: 
                obj[key] = val
        else:
            # it's a set/frozenset
            obj.update(coredata)
            
    def unpickle_finalize(self, obj, propmap):
        # restore attrs
        for key,val in propmap.items():
            setattr(obj, key, val)

class myDict(dict):
    pass

if pyconfig.Have_BuiltinSet():
    class mySet(set):
        pass

class myStr(str):
    pass

class myObj(object):
    pass

d1 = {'a':1,'b':2,'c':3}
d2 = myDict({'d':4,'e':5,'f':6})
d2.aaa = 111
d2.bbb = 222

if pyconfig.Have_BuiltinSet():
    s1 = set([201,202,203])
    s2 = mySet([301,302,303])
    s2.eee = 'hello s2 eee'
    s2.fff = 'hello s2 fff'
    
t = (True,False,None)
z1 = myStr('hello z1')
z1.xxx = 'z1 xxx'
z1.yyy = 'z1 yyy'
o = myObj()
o.abcd = 123
o.efgh = 456
o.ijkl = 789

test_obj = [d1,d2,t,z1,o,ord]
if pyconfig.Have_BuiltinSet():
    test_obj += [s1,s2]

# before registering extensions, pickle normally so I can
# do a size comparison later
x0 = dumps(test_obj, short_ids=1)

# register extensions

# SanityCheck is registered *first* so that it will be called *last*.
# Order doesn't matter on the other two, since they use decompose()
# to match types.
register_extension(SanityCheck())
register_extension(ThingToList())
register_extension(ThingToUnicode())

# pickle with extensions (note I have to pass 'ext_basictypes=1' here
# so that my extension will get basic types like int,float,etc.)
x = dumps(test_obj, short_ids=1, ext_basictypes=1)
#print x
l = loads(x,0)

u1 = l[0]
u2 = l[1]
u3 = l[2]
u4 = l[3]
u5 = l[4]
u6 = l[5]
if pyconfig.Have_BuiltinSet():
    u7 = l[6]
    u8 = l[7]

# check them
if get_data_attrs(d1) != get_data_attrs(u1) or \
   get_data_attrs(d2) != get_data_attrs(u2) or \
   get_data_attrs(z1) != get_data_attrs(u4) or \
   get_data_attrs(o) != get_data_attrs(u5) or \
   u3 != (True,False,None) or \
   u1.__class__ != dict or u2.__class__ != myDict or \
   u4.__class__ != myStr or u5.__class__ != myObj or \
   u6 != ord:
    raise "ERROR"

if pyconfig.Have_BuiltinSet() and \
       (get_data_attrs(s1) != get_data_attrs(u7) or \
        get_data_attrs(s2) != get_data_attrs(u8) or \
        u7.__class__ != set or u8.__class__ != mySet):
    raise "ERROR"

# using "minimal" types causes the pickle to bloat quite a bit! :-)
print "Normal pickle size: ",len(x0)
print "Size with 'minimal types': ",len(x)

print "** OK **"



