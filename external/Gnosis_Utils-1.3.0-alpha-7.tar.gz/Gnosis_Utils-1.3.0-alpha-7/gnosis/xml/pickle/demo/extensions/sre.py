#----------------------------------------------------------------
# An extension to handle SREs (compiled regular expressions)
#
# Just import this module to enable it.
#----------------------------------------------------------------
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle.extensions import StackableExtension, register_extension

import re
re_type = type(re.compile('aaa'))

class RegexToString(StackableExtension):
    "Turn a compiled regex into type='string'"
    def __init__(self):
        StackableExtension.__init__(self, 'sre')
        
        self.flags_list = [(re.I,'I'),(re.L,'L'),(re.U,'U'),(re.M,'M'),
                           (re.S,'S'),(re.X,'X')]
        
    def pickle(self, obj):
        "Turn a compiled regex into a string"
        if type(obj) != re_type:
            return self.ignore(obj) # not a regex, ignore
        
        # turn flags into a verbose string
        flags = []
        for f,s in self.flags_list:
            if obj.flags & f:
                flags.append( s )

        if len(flags):
            return (obj.pattern, None, {'flags': ','.join(flags)})
        else:
            return (obj.pattern, None, {})
    
    def unpickle(self, obj, coredata, propmap):
        "Take data from pickle() and recreate the compiled regex."
        flag = 0

        # split flag string
        flags = propmap.get('flags','').split(',')

        for f in flags:
            for g in self.flags_list:
                if g[1] == f:
                    flag += g[0]

        return re.compile(obj,flag)

register_extension(RegexToString())



