"""
The __reduce__ protocol is too unsafe to include in the xml.pickle core by default
(since it allows arbitrary code execution, by design). However, it can be implemented
outside of the core as an extension. This demo shows one way to do that.
"""
from gnosis.xml.pickle import StackableExtension, register_extension, dumps as xdumps, \
            loads as xloads, SEARCH_ALL
from pickle import dumps, loads

"""
An xml.pickle extension that implements the __reduce__ protocol.
"""
class ReduceExtension(StackableExtension):
    def __init__(self):
        StackableExtension.__init__(self, "__reduce__")
        
    def pickle(self, obj):
        try:
            fn, args, kwargs = obj.__reduce__()
        except (AttributeError, TypeError):
            # if no __reduce__ or __reduce__ failed, ignore object
            return self.ignore(obj)

        return ((fn, args, kwargs), {}, {})
        
    def unpickle(self, obj, coredata, propmap):		
        return apply(*obj)
    
"""
Example class from Salim Fadhley that prompted creation of this demo.
"""
class _apply( object ):
    """
    A class which reduces in such a way that allows a function to be called remotely.
    """
    
    def __init__(self, fn, args=None, kwargs=None):
        """
        Just store a bunch of arguments, it's deliberately generic.
        """
        assert callable( fn )
        
        self.fn = fn
        
        if args == None:
            self.args == ()
        else:
            self.args = args
            
        if kwargs == None:
            self.kwargs = {}
        else:
            self.kwargs = kwargs
        
    def __repr__(self):
        """
        Identify this object
        """
        return "<%s.%s %s %s %s>" % ( self.__class__.__module__,
                                      self.__class__.__name__,
                                      self.fn.__name__ ,
                                      repr.repr(self.args),
                                      repr.repr(self.kwargs) )
                                      		
    def __reduce__(self):
        """
        An unusual reduce function, it will result in something completely other than itself
        being injected into the pickle stream. Unpickling this object will result in 
        apply(fn, *args, **kwargs) being executed.
        """
        returncode = ( self.fn, self.args, self.kwargs )
        return returncode
    
# Another example I added ...
def multlist(numbers):
    return reduce(lambda x,y: x*y, numbers)

# create & register __reduce__ extension
register_extension(ReduceExtension())
        
# Make some apply objects
somedata = range(0,3)
deferred = _apply( set, ( somedata, ) , {} )

somedata2 = range(0,6)
deferred2 = _apply( set, ( somedata2, ) , {} )

# This multiplication doesn't happen till unpickling (look at XML to see)
deferred3 = _apply(multlist, ([1.2,2.3,3.4,4.5],), {})

dlist = (deferred, deferred2, deferred3)

# standard pickle
s = dumps(dlist)
print "STANDARD pickle got:",loads(s)

# xml.pickle
xml = xdumps(dlist)
#print xml
o = xloads(xml, SEARCH_ALL)
print "XML pickle got:     ",o

            
    
