"""
Even safer version of basic_safe.py

This version loads only builtin data types (list, int, string, etc.) - NO user classes.
Any user-defined objects are loaded as 'replicants'.

This shows how unknown or untrusted data can be loaded, manipulated, and repickled safely (as the
ORIGINAL objects), without ever having to load a user-defined class. This is useful in 
situations where loading the classes could pose a security risk, but also in the case of simply
not having some package installed on your machine, and not wanting to install it just to
grab some data from a pickle.
"""

__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle import loads as xml_loads, dumps as xml_dumps, \
                            replicant_info, SEARCH_NONE, SEARCH_NO_IMPORT, add_class_to_store

# define convenience routines
def dumps(obj):
    """
    Pickle obj and return XML string.
    """
    return xml_dumps(obj,
                    # do NOT allow fallback on cPickle if I can't handle data
                    # (this is the default value)
                    allow_rawpickles=0)
    
def loads(xml):
    """
    Take XML string from dumps() and return original object.
    """
    return xml_loads(xml,
                    # do not load ANY non-builtin classes
                    class_search=SEARCH_NONE,
                    # All (non-builtin) objects will be replicants now
                    allow_replicants=1,								
                    # do NOT allow data from previous xml.pickle versions
                    # (this is the default value)
                    min_accept='1.3',  
                    # do NOT allow fallback on cPickle if I can't handle data
                    # (this is the default value)
                    allow_rawpickles=0  )
                            
#=============================================================================
# Demo
#=============================================================================

class Foo:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
        
    def __str__(self):
        return "Hello from Foo! A=%s, B=%s, C=%s" % (repr(self.a),repr(self.b),repr(self.c))
        
# Put a couple of Foo objects in a compound object
l = {
        "aaa": Foo(123, "Hello", u"World"),
        "bbb": [1, 2, Foo(456, (4,5,6), "4 5 6")]
        }
        
print "ORIGINAL OBJECTS: "
print "-----------------"

# print Foo objects
print l['aaa']
print l['bbb'][2]

# pickle to XML
xml = dumps(l)
del l # delete original, to make sure nothing cheats! :-)

print "\nUNPICKLED OBJECTS:"
print   "------------------"

# unpickle - Foo objects are loaded as replicants
obj = loads(xml)

o = obj['aaa']

# The "Foo" objects are now replicants - substitute classes holding only the data.
#
# replicants know which module & class they are SUPPOSED to be ...
rtype,rmod,rclass = replicant_info(o)
print "I'm a replicant representing: %s.%s" % (rmod,rclass) 

# the "Foo" replicants have no __str__ function like the real Foo, so have to print them manually
print "Hello from replicant! A=%s, B=%s, C=%s" % (repr(o.a),repr(o.b),repr(o.c))
o = obj['bbb'][2]
print "Hello from replicant! A=%s, B=%s, C=%s" % (repr(o.a),repr(o.b),repr(o.c))

# Now ... this is neat -- you can repickle the replicant data, using the 'allow_replicants'
# flag to dumps, then unpickle the REAL Foo objects again! So i.e. a client machine could send
# data to a server, the server could unpickle safely (using replicants), manipulate,
# repickle, send back to the client, and the client would never see anything but the real classes.

# change the data a bit, just to show it works ...
obj['aaa'].a = "Changed!!"

print "\nChanging obj['aaa'].a to 'Changed!!'\n"

xml = xml_dumps(obj, allow_replicants=1)

print "\nRepickling replicants, then unpickling:"
print "----------------------------------------"

# another variation - SEARCH_NO_IMPORT means to trust any classes already imported, i.e. Foo
# in this case
obj2 = xml_loads(xml, SEARCH_NO_IMPORT, allow_replicants=0)

# Now I have real Foo objects again
print obj2['aaa']
print obj2['bbb'][2]

