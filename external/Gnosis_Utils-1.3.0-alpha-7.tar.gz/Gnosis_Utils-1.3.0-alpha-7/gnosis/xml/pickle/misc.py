"""
Some convenient/miscellaneous bits that didn't fit elsewhere.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

# public API
__all__ = ['pprint_obj','pprint_replicant']

from gnosis.xml.pickle.objmodel import decompose
from gnosis.xml.pickle import is_replicant, replicant_info
                   
def pprint_obj( obj, allow_replicants=0, allow_rawpickles=0, header=None ):
    """
    Pretty-print an object using the pieces from decompose().
    
    obj *can* be a replicant, but in that case, it would make
    more sense to call pprint_replicant() instead.

    For safety, it takes the (allow_replicants, allow_rawpickles) parameters,
    like decompose(), and both default to off. You'll get an exception if you
    try to pprint a replicant or something that requires cPickling. In that
    case, just turn on the appropriate flag.
    """
    if header is None:
        header = '[ %s ]' % repr(obj)

    print header + '\n----------------------------'	
    typestr, classtag, coredata, attrs = decompose(obj,allow_replicants,
                                                   allow_rawpickles)
    print "  It has basetype '%s'" % typestr
    if classtag is None:
        print "  It is a baseclass (no classtag)"
    else:
        print "  It is of class '%s'" % classtag

    if coredata is None:
        print "  It has NO coredata."
    else:
        print "  It has coredata: %s (%s)" % (repr(coredata),type(coredata))
        
    print "  Its attributes are:"
    for k,v in attrs.items():
        print "    name=%s, val=%s" % (k,repr(v))
    
def pprint_replicant(obj, header=None):
    "Pretty-print a replicant object."
    if not is_replicant(obj):
        raise Exception("ERROR")

    if header is None:
        header = '[ %s ]' % repr(obj)
        
    # get the (typestring, module, class) that was SUPPOSED to be
    # loaded (all 3 a strings)
    inf = replicant_info(obj)
    print header + '\n----------------------------'
    print "  It has basetype '%s'" % inf[0]	
    print "  It is supposed to be class '%s' from module '%s'" % (inf[2],inf[1])
    
    if hasattr(obj,'__coredata__'):
        print "  It has coredata: %s (%s)" % \
              (repr(obj.__coredata__),type(obj.__coredata__))
    else:
        print "  It has NO coredata."

    print "  Its attributes are:"
    for k,v in obj.__dict__.items():
        if k == '__coredata__':
            continue
        
        print "    name=%s, val=%s" % (k,repr(v))

    print ""
