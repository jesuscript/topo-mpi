"""
Functions for creating/retrieving replicant classes.
Replicants are empty classes that substitute for classes
that couldn't be loaded while unpickling.

Replicants live under the 'gnosis.xml.pickle.replicants' namespace.
The 'replicant store' is a genuine module namespace, i.e. once you
create a replicant 'Foo.Bar.BazClass', the following are valid:

     gnosis.xml.pickle.replicants.Foo == module
     gnosis.xml.pickle.replicants.Foo.Bar == module
     gnosis.xml.pickle.replicants.Foo.Bar.BazClass == class

In this way, the user can easily see what module.class was *supposed*
to be loaded, but failed (using 'replicant_info()').

In the routines below, 'modname' can be None, meaning that the
class lives directly in gnosis.xml.pickle.replicants.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

import new, sys, types
from gnosis.xml.pickle.api import XMLUnpicklingError, XMLPickleOtherError
from gnosis.pyconfig import pyconfig

# single baseclass for all replicants
class ReplicantBase: pass

# now, one per type= value
class ReplicantNumeric(ReplicantBase): pass
class ReplicantString(ReplicantBase): pass
class ReplicantClass(ReplicantBase): pass
# don't need for [Function,None,True,False] - can't have replicants
# don't need for Blob - they never make it up to the user API
class ReplicantPyobj(ReplicantBase): pass
class ReplicantList(ReplicantBase): pass
class ReplicantTuple(ReplicantBase): pass
class ReplicantSet(ReplicantBase): pass
class ReplicantFrozenSet(ReplicantBase): pass
class ReplicantDict(ReplicantBase): pass

# map the classes back to their type= strings
replicant_class_to_typestr = {
    ReplicantNumeric: 'numeric',
    ReplicantString: 'string',
    ReplicantClass: 'class',
    ReplicantPyobj: 'pyobj',
    ReplicantList: 'list',
    ReplicantTuple: 'tuple',
    ReplicantSet: 'set',
    ReplicantFrozenSet: 'frozenset',
    ReplicantDict: 'dict',
    }

typestr_to_replicant_class = {
    'numeric': ReplicantNumeric,
    'string': ReplicantString,
    'class': ReplicantClass,
    'pyobj': ReplicantPyobj,
    'list': ReplicantList,
    'tuple': ReplicantTuple,
    'set': ReplicantSet,
    'frozenset': ReplicantFrozenSet,
    'dict': ReplicantDict,
    None: ReplicantBase # see below
    }

def is_replicant( klass_or_obj ):
    "Is the given object (or class) a replicant?"
    if type(klass_or_obj) in [types.ClassType,types.TypeType]:
        klass = klass_or_obj
    else:
        if not hasattr(klass_or_obj,'__class__'):
            return (1==0) # whatever 'false' is here
        
        klass = klass_or_obj.__class__
        
    return issubclass(klass, ReplicantBase)

def replicant_info( klass_or_obj ):
    """
    Given a replicant class, get:
       (typestr, modname, classname)

    Where:
       typestr is the 'type=' string of the object that was unpickled.
       modname,classname = The module & classname that the unpickler
              was unable to load.
    """
    # handle either a replicant class or a replicant object
    if type(klass_or_obj) in [types.ClassType,types.TypeType]:
        klass = klass_or_obj
    else:
        if not hasattr(klass_or_obj,'__class__'):
            raise XMLPickleOtherError("Called replicant_info on non-replicant.")
        
        klass = klass_or_obj.__class__

    # I haven't completely figured this out, but in later Pythons,
    # the module name ends up being 'gnosis.xml.pickle.replicants',
    # and the classname ends up being the full dotted name.
    #
    # In earlier Pythons, the module name is the original module
    # name, and the classname is just the final part.
    #
    # So, figure out which happened here, and split appropriately.
    
    if klass.__module__ == __name__:
        # full module path is in klass.__name__
        parts = klass.__name__.split('.')
        if len(parts) > 1:
            modname,cname = ('.'.join(parts[:-1]),parts[-1])
        else:
            modname,cname = (None,parts[0])

    else:
        # klass.__name__ is only the final part; module name is __module__
        modname = klass.__module__
        cname = klass.__name__
                
    # see which Replicant* class it is
    for r_klass,typestr in replicant_class_to_typestr.items():
        if issubclass(klass, r_klass):
            return (typestr, modname, cname)

    # else, it's ReplicantBase (can't put that in the dict, since
    # it would catch everything)
    return ('unknown', modname, cname)

def lookup_replicant_class(modname, classname):
    """
    Lookup replicant class, or return None.
    
    Inputs:
       modname = Dotted module path.
                 If 'None', looks in gnosis.xml.pickle.replicants.
       classname = Class name.
    """
    if modname is None:
        return getattr(sys.modules[__name__],classname,None)
        
    root = sys.modules[__name__]
    parts = modname.split('.')
    for p in parts:
        root = getattr(root,p,None)
        if root is None:
            return None # not found

    return getattr(root,classname,None)

def make_replicant_class(modname,classname,typestr=None):
    """
    Create a replicant class.
    Inputs:
       modname = Dotted module path where class will live
                 (under gnosis.xml.pickle.replicants).
                 If 'None', class will live in gnosis.xml.pickle.replicants.
       classname = Class name
       typestr = Used for information purposes - the type= of the
                 object that is being loaded. Can be None for compatiblity
                 with old code.
    """
    #print "MAKE REPLICANT ",repr(modname),modname is None,repr(classname),repr(typestr),typestr is None
    
    # these must be plain ASCII (per Python grammar for module/classnames), so enforce
    # (also, new.module doesn't like Unicode)
    if modname is not None:  # leave None as None, for testing below
        modname = str(modname)
        
    classname = str(classname)
    
    if typestr is not None: # None is a key in typestr_to_replicant_class
        typestr = str(typestr)
            
    if pyconfig.Have_ObjectClass():
        # aesthetics, return a newstyle object		
        baseclass = (typestr_to_replicant_class[typestr],object)
    else:	
        baseclass = (typestr_to_replicant_class[typestr],)

    #print "BASECLASS ",repr(baseclass)
    #print "MODNAME ",modname,repr(modname),modname is None
    
    if modname is None:
        mod_classname = classname
    else:
        mod_classname = modname+'.'+classname

    # create the proper (fake) module path
    submod = make_module_path(modname)

    # create fake class and place it in the module
    k = new.classobj(mod_classname, baseclass,{})
    setattr(submod,classname,k)

    #print "RETURNING ",repr(k)
    #print is_replicant(k)
    #print replicant_info(k)
    
    return k

def make_module_path(modname, root_module=None):
    """
    Given a module name (in dotted format), ensures that
    the full dotted module path exists under the given root_module.

    If root_module is None, the module path is created
    underneath gnosis.xml.pickle.replicants.

    Returns the module for modname.
    If modname is None, returns root_module.
    """
    if root_module is None:
        # by default, replicant modules live under gnosis.xml.pickle.replicants
        root_module = sys.modules[__name__]

    if modname is None:
        # no path, place in root_module
        return root_module
    
    parts = modname.split('.')
    pathname = ''
    rootname = root_module.__name__ # save since it changes below
    
    for p in parts:
        if len(pathname):
            pathname += '.'+p
        else:
            pathname += p

        # does submodule already exist?
        submod = getattr(root_module,p,None)
        if submod is None:
            # create & insert into path
            m = new.module(rootname+'.'+pathname)
            setattr(root_module,p,m)
            submod = m

        root_module = submod
        
    return root_module

    
