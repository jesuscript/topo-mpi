"""
Module for loading/creating classes & functions.

(This was originally _util.py in 1.2.0, but unneeded things
were removed for 1.3, and a few things rewritten for a better interface.)
"""

from gnosis.xml.pickle.api import XMLPicklingError, XMLUnpicklingError, XMLPickleOtherError, \
     SEARCH_NO_IMPORT, FL_SYSMODULE, FL_STORE, FL_STACK, FL_DO_IMPORT, FL_NONE
from gnosis.xml.pickle import deprecation
import gnosis.xml.pickle
import types, sys
from threading import Lock

CLASS_STORE = {}
LOCK_CLASS_STORE = Lock()

DEBUG = 0

if DEBUG:
    def dbg(*args):
        for s in args:
            sys.stdout.write(str(s)+' ')

        sys.stdout.write("\n")
else:
    def dbg(*args): pass

def unpickle_function( module,name,class_search ):
    "Load a function, given module.name as returned by get_function_info()"
    # only class_search makes sense here, not replicants
    
    # module names are required (per Python grammar, as of 2.5) to be [A-Za-z0-9_]+,
    # so force str() here. [Things like new.module() don't like unicode names which
    # can cause issues for callers that override __import__].
    module = str(module)
    
    # is CLASS_STORE my only option?
    if (class_search == FL_STORE):
        return None	 # not allowed; funcs aren't stored in CLASS_STORE

    if (class_search & FL_DO_IMPORT):
        __import__(module) # import it myself

    # otherwise, module must already be imported

    mod = sys.modules.get(module,None)
    if mod is None:
        return None

    if hasattr(mod,name):
        return getattr(mod,name)
    return None

#--- Helper functions for creating objects by name ---
# (these are pretty cool to have, even without xml_pickle)

def _get_class_from_locals(dict, modname, classname):
    for name in dict.keys():
        # class imported by caller
        if name == modname and type(dict[name]) is types.ModuleType:
            mod = dict[name]
            if hasattr(mod,classname):
                return getattr(mod,classname)
        # class defined by caller
        if name == classname and dict[name].__module__ == modname:
            return dict[name]
    return None

def get_class_from_sysmodules(modname, classname):
    "Get a class by looking in sys.modules"
    # check global modules
    try:
        return getattr(sys.modules[modname],classname)
    except (KeyError, AttributeError):
        return None

def get_class_from_stack(modname, classname):
    "Get a class ONLY IF already been imported or created by caller"
    stk = _mini_getstack()
    for frame in stk:
        k = _get_class_from_locals(frame.f_locals,modname,classname)
        if k: return k

def get_class_full_search(modname, classname):
    "Get a class, importing if necessary"
    __import__(modname)
    mod = sys.modules[modname]
    if hasattr(mod,classname):
        return getattr(mod,classname)
    return None

def get_class_from_store(modname, classname):
    "Get the class from the store, if possible"
    try:
        LOCK_CLASS_STORE.acquire()
        k = locked_get_class_from_store(modname, classname)
        LOCK_CLASS_STORE.release()
        return k
    except:
        LOCK_CLASS_STORE.release()
        raise # re-raise original exception to caller
        
def locked_get_class_from_store(modname, classname):
    "Get the class from the store, if possible"
    dbg("try from store ",classname,modname,modname is None)

    if modname is None:
        full = classname
    else:
        full = modname + '.' + classname
        
    klass = CLASS_STORE.get(full, None)
    if klass:
        dbg("GOT FROM STORE", klass)
        return klass

    # oldstyle - check xml.pickle namespace
    klass = gnosis.xml.pickle.__dict__.get(classname,None)
    if klass:
        # found deprecated usage -- warn user
        deprecation("Placing classes in the xml.pickle namespace is deprecated. Use add_class_to_store() instead.")
        return klass
    
    # ugh, 1.1 allowed matching "ANYTHING.Foo" with "Foo".
    # 1.3 is strict, but try and accept short version for now.
    for name,klass in CLASS_STORE.items():
        parts = name.split('.')
        if parts[-1] == classname:
            deprecation("Deprecated use of add_class_to_store(). Adjust your code to use fully qualified names in add_class_to_store() - you should pass classname='%s' instead of '%s'" % (full,classname))
            return klass
        
    return None # not found

def OLD_add_class_to_store(classname='', klass=None):
    if classname and klass:
        CLASS_STORE[classname] = klass
    return CLASS_STORE

def add_class_to_store(klass, classname=None):
    try:
        LOCK_CLASS_STORE.acquire()
        locked_add_class_to_store(klass, classname)
        LOCK_CLASS_STORE.release()
    except:
        LOCK_CLASS_STORE.release()
        raise # re-raise original exception to caller

def locked_add_class_to_store(klass, classname=None):
    """
    Add the class 'klass' to the store. By default, the class
    is added under its own name. However, if 'classname' is given,
    it will be stored under that name.

    Note that, when xml.pickle searches for classes in the class store,
    the names must match exactly (including module name). For example,
    if the XML contains references 'class="Foo"', but the Foo class
    actually lives in the module 'Bar', then you must do this:

        from Bar import Foo
        add_class_to_store(Foo, 'Foo')

    Without the classname parameter, it would be stored as 'Bar.Foo',
    and wouldn't match exactly when 'Foo' was requested.

    You are free to add the same class multiple times under different
    names, if desired.
    """
    from gnosis.xml.pickle.objmodel import get_classtag

    # accept reversed args from previous API
    if type(klass) in [types.NoneType,types.StringType,types.UnicodeType]:
        # swap - old usage with classname first
        t = klass
        klass = classname
        classname = t

    if klass is None:
        raise DeprecationWarning("Deprecated usage, must pass a class.")

    if type(klass) not in [types.ClassType,types.TypeType]:
        raise DeprecationWarning("klass parameter must be a class.")

    if classname is None:
        classname = get_classtag(klass)

    dbg("ADD_CLASS_TO_STORE", repr(klass), classname)

    CLASS_STORE[classname] = klass

def remove_class_from_store(klass_or_classname):
    try:
        LOCK_CLASS_STORE.acquire()
        locked_remove_class_from_store(klass_or_classname)
        LOCK_CLASS_STORE.release()
    except:
        LOCK_CLASS_STORE.release()
        raise # re-raise original exception to caller

def locked_remove_class_from_store(klass_or_classname):
    """
    Remove the class from the store, either by class or name.
    (If removing by class, will remove all names that class
    is stored under.)
    """
    if type(klass_or_classname) in [types.ClassType,types.TypeType]:
        klass = klass_or_classname
        to_remove = []		
        for key,val in CLASS_STORE.items():
            if val == klass:
                to_remove.append(key)

    else:
        if CLASS_STORE.has_key(klass_or_classname):
            to_remove = [klass_or_classname]

    for name in to_remove:
        del CLASS_STORE[name]

import new

def get_class_from_name(classname, modname=None,
                        class_search=SEARCH_NO_IMPORT,
                        allow_replicants=1, typestr=None):
    """Given a classname and optional module name, return a ClassType,
    of type module.classname, subject to class_search and allow_replicants.

    Inputs:
        classname = Class name
        modname = Module name, or None
        class_search = One of the SEARCH_.. constants from gnosis.xml.pickle
        allow_replicants = Allow replicated classes? ('Empty' classes with
                           data but no methods; created when the real class
                           cannot be loaded.)
        typestr = (Optional) The 'type=' that is being loaded. Used for
                  information if a replicant is substituted.
    Returns:
       (class, is_replicant)

    Where:
       class = The class
       is_replicant = 1 if the real module.classname couldn't be loaded
                      (due to class_search setting, etc.) and a replicant
                      class was substituted.
    """
    # sanity - things like new.module() require a bytestring and will crash if you
    # pass a Unicode name. Module & classnames are required to be plain ASCII
    # (per the Python grammar, as of 2.5), so if this fails we have bigger problems
    # (i.e. names may no longer be safe to put in XML attributes!)
    classname = str(classname)
    if modname is not None:
        modname = str(modname)
    
    # sanity - FL_NONE has to be used alone
    if class_search & FL_NONE:
        class_search = FL_NONE
    
    dbg("GET_CLASS class=",classname,"Mod=",modname,"mod is None:",modname is None,"Search=",class_search,"AllowRep=",allow_replicants)
    dbg("STORE = ",CLASS_STORE)
    
    # first, try our store										  
    #if paranoia <= 2:				  # first, try our store
    if (class_search & FL_STORE):
        klass = get_class_from_store(modname, classname)
        if klass:
            dbg("**GOT CLASS FROM STORE ", str(klass))
            return (klass,0)

    # get_class_from_stack() is more paranoid, but unless we
    # define a new paranoid level for it, there's no need
    # to try it if the sys.modules method works. this is
    # faster so try it first.
    #if paranoia <= 0 and modname:	  # try sys.modules
    # try sys.modules
    if (class_search & FL_SYSMODULE) and modname:
        klass = get_class_from_sysmodules(modname, classname)
        if klass:
            dbg("**GOT CLASS FROM sys.modules", str(klass))
            return (klass,0)

    # xxx move up one level if we define a new paranoia level for it
    #if paranoia <= 0 and modname:	  # next, try our caller's namespace
    # try our caller's namespace
    if (class_search & FL_STACK) and modname:
        klass = get_class_from_stack(modname, classname)
        if klass:
            dbg("**GOT CLASS FROM STACK", str(klass))
            return (klass,0)

    #if paranoia <= -1 and modname:	  # next, try importing the module
    # try importing the module
    if (class_search & FL_DO_IMPORT) and modname:
        klass = get_class_full_search(modname, classname)
        if klass:
            dbg("**GOT CLASS FROM CALLER", str(klass))
            return (klass,0)

    # careful -- needs to be a fallback if any of the above fail
    #if paranoia <= 1:				  # finally, create from thin air
    # create from thin air
    if allow_replicants:
        import gnosis.xml.pickle.replicants as replicants		
        klass = replicants.make_replicant_class(modname,classname,typestr)
        
        dbg("**MADE REPLICANT CLASS", str(klass))
        return (klass,1)
        
    dbg("**ERROR - couldn't get class - search=%d,repl=%d" % (class_search,allow_replicants))

    # *should* only be for paranoia == 2, but a good failsafe anyways ...
    #raise XMLUnpicklingError, \
    #	  "Cannot create class under current PARANOIA setting!"
    raise XMLUnpicklingError("Cannot create class (module=%s, class=%s) with current class_search/allow_replicants setting! (%d,%d)" % (modname,classname,class_search,allow_replicants))

#-------------------------------------------------------------------
# Python 2.0 doesn't have the inspect module, so we provide
# a "mini" implementation (also faster since it doesn't lookup
# unneeded info).
#
# This was adapted from the real inspect module, written by
# Ka-Ping Yee <ping@lfw.org>.
#--------------------------------------------------------------------
def _mini_getstack():
    try:
        raise Exception('catch me')
    except:
        etype,evalue,etrace = sys.exc_info()
        frame = etrace.tb_frame.f_back
    
    framelist = []
    while frame:
        framelist.append(frame)
        frame = frame.f_back
    return framelist

# --- End of "mini" inspect module ---

