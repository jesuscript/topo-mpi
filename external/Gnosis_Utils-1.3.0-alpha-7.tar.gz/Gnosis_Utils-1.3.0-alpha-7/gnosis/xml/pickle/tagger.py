"""
The xml.pickle 1.3 pickler.

objmodel.decompose() does the "heavy lifting", all that has
to be done here is to write the XML stream.
"""

__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

from gnosis.xml.pickle.api import XMLPicklingError, XMLPickleStats
from gnosis.xml.pickle.replicants import is_replicant
from extensions import ExtensionManager, _get_nr_extensions
from objmodel import decompose, UElement
import objmodel
from types import *
import gnosis.version
import sys
import idmaker
from xml.sax.saxutils import escape as xml_escape_body
from xml.sax.saxutils import quoteattr as xml_escape_attr
from copy import copy

import re
re_valid_classtag = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_\.]+$')

def sanitize_typestr(typestr):
    if typestr not in ['numeric','string','class', 'function',
                       'None','True','False','blob','pyobj',
                       'list','tuple','set','frozenset','dict']:
        raise XMLPicklingError("Extension module returned an illegal type= string.")
    
def sanitize_classtag(classtag):
    if classtag != None and not re_valid_classtag.match(classtag):
        raise XMLPicklingError("Extension module returned an illegal class= string.")
    
def sanitize_coredata(coredata):
    if type(coredata) not in [StringType,UnicodeType,ListType,TupleType,
                              DictType,NoneType]:
        raise XMLPicklingError("Extension module returned illegal coredata (%s)." % \
                               repr(coredata))

    if type(coredata) is UnicodeType or \
           (type(coredata) is StringType and not objmodel.is_safe_attr_ASCII(coredata)):
        # turn it into a UElement first (decompose() does this
        # for the normal case)

        # a rawpickle will never be required here, but just to be safe ...
        coredata = UElement( plain=coredata, allow_rawpickles=0 )
        coredata.encode()

    return coredata

def sanitize_attrs(attrs):
    # the extension manager sanitizes the property lists
    pass

def sanitize_rawparts(typestr, classtag, coredata, attrs):
    """
    Take the 4 'rawparts' parameters (from tagger), and ensure they
    are legal (according to what the tagger expects).
    Returns sanitized versions as a 4-tuple.
    
    Raises XMLPicklingError if not legal.
    """
    sanitize_typestr(typestr)
    sanitize_classtag(classtag)
    coredata = sanitize_coredata(coredata)
    sanitize_attrs(attrs)
    
    return (typestr, classtag, coredata, attrs)

class XMLPickleTagger:
    """
    XMLPickleTagger creates the XML tags for arbitary objects.
    You should create a new XMLPickleTagger for each (toplevel) object
    that you want to pickle.
    """
    def __init__(self, allow_replicants, allow_rawpickles,
                 deepcopy, short_ids, sorted, prefer_cdata, use_extensions,
                 break_hidden_refs, ext_basictypes):
                
        # save options
        self.opt_allow_replicants = allow_replicants
        self.opt_allow_rawpickles = allow_rawpickles
        self.opt_deepcopy = deepcopy
        self.opt_short_ids = short_ids
        self.opt_sorted = sorted		
        self.opt_prefer_cdata = prefer_cdata
        self.opt_break_hidden_refs = break_hidden_refs
        self.opt_ext_basictypes = ext_basictypes
        
        # statistics
        self.stats = XMLPickleStats()
        
        # counter for generating ids (for short_ids=1)
        self.id_counter = 0

        # remember objects I've seen, for references.
        # keyed by id(obj), each is (refid, object) where 'refid'
        # is the string to use as a refid, and object is stored
        # to keep it alive (so that ids won't be reused)
        self.refmap = {}

        # create extension manager
        # It takes a significant amount of time to run the extensions, even if
        # none are loaded. Therefore I optimize and don't bother if no extensions
        # are registered.
        if use_extensions:
            self.ext_manager = ExtensionManager()
        else:
            self.ext_manager = None
        
        # ensure idmaker is initted
        #idmaker.init()
        
    def lookup_object(self, obj):
        """
        If I've seen obj before, return the refid & info that
        was passed to remember_object().
        Else, return None.
        """
        ent = self.refmap.get(id(obj),None)
        if ent is None:
            return None
        else:
            return (ent[0],ent[2]) # return (refid,info)

    def remember_object(self, obj, info):
        """
        Add obj to the refmap, along with any arbitrary info
        the caller wants to attach. Returns the new refid.
        
        Caller must ensure it isn't already in the map by calling
        lookup_object() first.
        """
        # sanity
        if self.refmap.has_key(id(obj)):
            raise XMLPicklingError("Internal error: Duplicate key for refmap")
        
        if self.opt_short_ids:
            # create a short_id for the id=
            refid = idmaker.id_to_alpha(self.id_counter)
            self.id_counter += 1
        else:
            # just use str(id()) as the id=
            refid = str(id(obj))

        # save refid AND obj (have to keep alive, in case
        # it is a temporary object - don't want the id() to
        # be reused)
        self.refmap[id(obj)] = (refid,obj,info)
        return refid

    def indent(self, level):
        # can adjust indent policy here
        return '  '*level

    def do_decompose(self, obj, extensions, deepcopy, break_hidden_refs,
                    ext_basictypes):
        """
        Wrapper around decompose() that calls extension modules first
        and handles references.

        Returns a tuple of:
        
            obj: A possibly modified version of obj.
            my_id: id for the id= tag, if this object has not been seen before.
                   None means that refid is valid instead.
            refid: id for the refid= tag, if this object has been seen before.
                   None means that my_id is valid instead.
            typestr: type= string for object
            classtag: class= string for object
            coredata: coredata for object

        'extensions' is an optional list of extra extensions to run.
        They will be run before any registered extensions.
        
        'deepcopy' and 'break_hidden_refs' will be passed to want_deepcopy(),
        along with the typestr, to determine whether this object will be deepcopied or not.
        
        'ext_basictypes' is a flag specifying whether to pass basic types
        (int, float, dict, etc.) to extensions or not. By default it is off
        since this slows pickling down quite a bit and it likely only needed
        for specialized apps.
        """
        # run all applicable extension modules. ext_manager handles
        # references to the (original) obj
        if self.ext_manager is not None:
            obj, stackable_datalist, classext_datalist = \
                 self.ext_manager.run_pickle_extensions(obj, extensions, ext_basictypes)
        else:
            stackable_datalist = []
            classext_datalist  = None
            
        # have I seen this object before?
        refid, info = self.lookup_object(obj) or (None,None)
        if refid != None:
            # use saved information instead of decomposing again
            # (not only is this faster, but it matches the pickle
            # implementation - see test_assumptions.py:001)
            typestr, classtag, coredata, attrs = info
            my_id = None
        else:
            # split obj into pickleable parts
            typestr, classtag, coredata, attrs = decompose(obj,
                                                           allow_replicants= \
                                                           self.opt_allow_replicants,
                                                           allow_rawpickles= \
                                                           self.opt_allow_rawpickles)
            
            if classext_datalist != None:			
                # ignore classtag - ClassExtension is responsible for knowing
                # what kind of object it needs. set classtag to "*EXT_NAME".
                classtag = '*'+classext_datalist[0]

            # remember object
            # IMPORTANT: 
            #   When deepcopying, do NOT call remember_object() since that would generate an 
            #   id (when short_ids=1), even though the id will not be used. In a situation where
            #   break_hidden_refs=1 (see extras.py) this is BAD because you'll have gaps where
            #   ids were generated for objects but not used. This would cause two identical objects
            #   to generate different XML streams, and break extras.py.
            if not self.want_deepcopy(typestr, deepcopy, break_hidden_refs):
                my_id = self.remember_object(obj,
                                             (typestr, classtag, coredata, attrs))
            else:
                # won't be used, so can use anything ...
                my_id = id(obj)
                
            refid = None
        
        return (obj, my_id, refid, typestr, classtag, coredata, attrs,
                stackable_datalist, classext_datalist)

    def do_item_sort(self, desc, keys):
        "Convenience for checking errors."
        try:
            keys.sort()
        except TypeError, exc:
            raise XMLPicklingError('Unsortable %s found - you will have to use sorted=0 (Python raised error "%s")' % (desc,str(exc)))
        
    def fragment_sort_function(self, a, b):
        # compare the final objects
        return cmp(a[1],b[1])
        
    def do_sort_fragments(self, desc, fragments):
        try:
            fragments.sort(self.fragment_sort_function)		
        except TypeError, exc:
            raise XMLPicklingError('Unsortable %s found - you will have to use sorted=0 (Python raised error "%s")' % (desc,str(exc)))		
        
    def want_deepcopy(self, typestr, deepcopy, break_hidden_refs):
        # I want to perform a deepcopy either if:
        #   a. the caller has passed the 'deepcopy' flag, in which case ALL data is deepcopied
        #   b. the caller has requested I break references in situations where Python will make 
        #      references behind your back, i.e. strings and integers.
        #
        #      I probably should be more careful to only match integers instead of all numeric
        #      types, but in the very limited situations where this is useful (see extras.py),
        #      it doesn't matter much.
        return deepcopy or \
                (break_hidden_refs and typestr in ('numeric','string'))
                
    def tag_object(self, obj, start_tag, end_tag, indent, rawparts=None,
                   extensions=None):
        """
        Create an XML fragment for the given object, including all subobjects.
            
        Inputs:
           start_tag: Opening portion for tag, e.g. '<attr name='..'',
                      or '<item ..'
                      
           end_tag: Closing tag for element, e.g. </attr>, </item>.
                    Will only be used if object has subelements, else
                    it will just be closed with '/>'
                    
           indent: Indent level for my tags.
           
           rawparts: Normally, decompose(obj) is used to create the
                     taggable pieces of obj. With rawparts you can
                     provide the info yourself, and obj will be ignored.
                     If given, rawparts is:
                         (typestr, classtag, coredata, attrs)
                         
                     NOTE: There is no way to associate rawparts with
                     a refid, so this should only be used for internal
                     objects (like extension data) that the user will
                     never see.

           extensions: An optional list of extra extensions to run.
           			   They will be run before any registered extensions.
                       
        Returns:
            (xml_fragment, final_obj)
            
        Where:
            xml_fragment = The XML fragment for the object, including all subobjects.
            final_obj = The final version of the object (after processing by
                        all extensions), i.e. this is the actual object that
                        was serialized.
        
                        NOTE: If rawparts != None, final_obj will not be valid
        """
        # the XML fragment is built here
        xml_fragment = ""
        
        # stats
        self.stats.nr_objects += 1
        if rawparts is None:
            self.stats.nr_replicants += is_replicant(obj)

        # save original before it is (potentially) changed (in ext_decompose)
        orig_obj = obj

        # =========== Pickling of 'obj' ================================
        
        # NOTE: Code below is selective about when xml_escape_* needs to
        # be called. Otherwise, it's just a waste of time.

        # split obj into parts
        if rawparts != None:
            # have to sanitize rawparts - for speed, many assumptions
            # are made about the 4 values above. For extension modules
            # (ie. user-written code), those assumptions have to be checked.
            typestr, classtag, coredata, attrs = sanitize_rawparts(*rawparts)
            stackable_datalist = []
            classext_datalist = None
        else:
            obj, my_id, refid, typestr, classtag, coredata, attrs, \
                 stackable_datalist, classext_datalist = \
                 self.do_decompose(obj, extensions, self.opt_deepcopy,
                 					self.opt_break_hidden_refs,
                                    self.opt_ext_basictypes)

        # type= will always be OK; no escape needed
        xml_fragment += self.indent(indent) + start_tag + ' type="%s"' % typestr

        # have I seen the object before?
        if rawparts is None and not self.want_deepcopy(typestr, self.opt_deepcopy,
                                                        self.opt_break_hidden_refs):			
            if refid != None:
                # just make a ref and return (no escape needed)	
                xml_fragment += ' refid="%s"/>\n' % refid
                
                if rawparts != None:
                    # no final obj
                    return (xml_fragment, None)
                else:
                    return (xml_fragment, obj)

            else:
                # no escaping required for id
                xml_fragment += ' id="%s"' % my_id
                
        if classtag != None:
            # Per the Python grammar [http://docs.python.org/ref/grammar.txt] (as of Python 2.5), 
            # module names and classnames may only contain: [A-Za-z0-9_]
            # HOWEVER, by calling new.module() or new.classobj() directly, you can create modules/classes
            # with binary names. The xml.pickle format requires that module/class names are safe_attr_ASCII, so
            # check in case the caller is trying to shove in some binary names.
            # (this is also checked when registering ClassExtension names)
            if not objmodel.is_safe_attr_ASCII(classtag):
                raise XMLPicklingError("Module and class names must be simple ASCII, per Python grammar (I got '%s')" % repr(classtag))
                
            xml_fragment += ' class="%s"' % classtag

        # keep top tag open until a subitem is found
        topopen = 1

        handled_core = 0
        
        # see if core goes inside tag (decompose already made coredata
        # UElement if it must go in a <u> element)
        if type(coredata) is StringType:
            if typestr == 'string':
                # escaping needed for value= (escape adds quotes)
                xml_fragment += ' value=%s' % xml_escape_attr(coredata)
            else:
                # all other types have values that don't need escaping
                xml_fragment += ' value="%s"' % coredata

            handled_core = 1

        # Rest of coredata cases are outside of main tag.
        # If I have metadata from a ClassExtension or __getinitargs__, write it now.
        if classext_datalist != None or attrs.has_key('#newargs'):
            if topopen:
                # close toptag
                xml_fragment += '>\n'
                topopen = 0
                
            # write '#newargs' first
            if attrs.has_key('#newargs'):
                subfrag,subobj = self.tag_object(attrs['#newargs'],
                                        '<meta name="#newargs"', "</meta>", indent+1,
                                        extensions=extensions)
                xml_fragment += subfrag

                # Not allowed to change original attrs, but I need to remove
                # '#newargs' so it isn't written again, below. The copy()
                # only happens in this case, so it won't slow down the
                # general case.
                attrs = copy(attrs)
                del attrs['#newargs']

            # write any metadata from ClassExtension
            if classext_datalist != None:
                metadata = classext_datalist[1] # for clarity
            else:
                metadata = ()
                
            if len(metadata):
                keys = metadata.keys()
                if self.opt_sorted:
                    self.do_item_sort('metadata keys',keys)
                    
                for key in keys:
                    # note: keys have been checked vs safe_attr_ASCII,
                    # but might contain chars needing escaping

                    # this is just like an <attr> tag. note that meta names
                    # do NOT have a "+" prefix -- the meta *value* might be
                    # mutated though, in which case its class and/or attrs
                    # might get '*' or '+' tags.
                    subfrag,subobj = self.tag_object(metadata[key],
                                        '<meta name=%s' % xml_escape_attr(key),
                                        '</meta>', indent+1, extensions=extensions)
                    xml_fragment += subfrag										

                # the keys cannot be modified by tag_object() in the above loop,
                # so no need to sort the output fragments
                
        # tell extension manager I'm finished writing <meta> tags
        if self.ext_manager is not None:
            self.ext_manager.close_meta_tags(orig_obj)
        
        # see if coredata goes inside <u>
        if isinstance(coredata,UElement):
            if topopen:
                # close toptag
                xml_fragment += '>\n'
                topopen = 0
                
            xml_fragment += self.indent(indent+1)
            if coredata.encoding == 'unicode/plain':
                # unicode/plain is the implied encoding, so drop encoding=
                u_start = '<u>'
            else:
                # encoding names don't need escaping (sync w/xmlcoder.py)
                u_start = '<u encoding="%s">' % coredata.encoding

            # UElements are the only portion of the stream that might
            # contain actual unicode values. Therefore, the remainder
            # of the string is generated as a regular string, and the
            # UElements are encoded to UTF-8 as needed.
            if coredata.encoding[:8] == 'unicode/':
                bodytext = coredata.encoded.encode('utf-8')
            else:
                # it's already safe ASCII
                bodytext = str(coredata.encoded)
                
            # in general, have to escape body text
            t_escaped = xml_escape_body(bodytext)

            # replace \r's with character refs so XML parser won't discard them
            t_escaped = t_escaped.replace('\r','&#x0d;')
            
            # if escaping changed the text, and the user requested CDATA instead,
            # AND the text doesn't contain the CDATA-end sequence ']]>' or any
            # '\r' characters, then use a CDATA tag to preserve the original
            # text (don't automatically use CDATA w/out checking since it's a
            # waste of space if not needed)
            if not len(bodytext):
                xml_fragment += '<u/>\n'
            else:
                if self.opt_prefer_cdata and t_escaped != bodytext and \
                       bodytext.find(']]>') < 0 and bodytext.find('\r') < 0:
                    xml_fragment += '<u><![CDATA[%s]]></u>\n' % bodytext
                else:
                    xml_fragment += u_start + '%s</u>\n' % t_escaped

            handled_core = 1
            
        # see if coredata is a list/tuple
        if type(coredata) in [ListType,TupleType]:
            if len(coredata):
                if topopen:
                    # close toptag
                    topopen = 0
                    xml_fragment += '>\n'

                # set & frozenset are unordered, so should have their coredata sorted
                if self.opt_sorted and typestr in ['set','frozenset']:
                    # don't change coredata
                    sortcore = copy(coredata)
                    all_subitems = []
                    # sort items since Python ordering is indeterminate
                    self.do_item_sort('set/frozenset data',sortcore)
                    for item in sortcore:
                        subfrag,subobj = self.tag_object(item, '<item', '</item>', indent+1,
                                                        extensions=extensions)
                        all_subitems.append( (subfrag,subobj) )
                        
                    # Now, I'd like to sort the fragments again, since an extension might
                    # have changed the items enough to change their relative order. Resorting
                    # is the only way to guarantee that two non-similar objects that have been
                    # folded to identical objects will produce the same XML stream.
                    #
                    # Unfortunately, if references are being used, swapping the fragment
                    # order could break the pickle by having a refid= appear before the
                    # corresponding id= that defines the object.
                    #
                    # Therefore, the fragment sorting can only be performed safely if
                    # deepcopy=1.
                    #
                    # Before you panic, note that an unsorted output sequence is only a 
                    # cosmetic problem. The pickle is still deterministic, since Extensions
                    # are required to be immutable. Given a sorted input sequence, the same
                    # (unsorted) output sequence will always be produced. The only thing lost
                    # here is the ability to directly compare two XML streams of dissimilar
                    # objects that have been folded to identical values.
                    
                    # sort fragments, if I'm allowed ...
                    if self.opt_deepcopy:
                        self.do_sort_fragments("set/frozenset data",all_subitems)
                        
                    # write fragments to stream
                    for subfrag,subobj in all_subitems:
                        xml_fragment += subfrag
                        
                else:
                    # regular list/tuple - not sorted
                    for item in coredata:			
                        subfrag,subobj = self.tag_object(item, '<item', '</item>', indent+1,
                                                        extensions=extensions)
                        xml_fragment += subfrag														

            handled_core = 1

        # see if coredata is a dict
        if type(coredata) is DictType:
            if len(coredata.keys()):
                if topopen:
                    # close toptag			
                    topopen = 0			
                    xml_fragment += '>\n'

                keys = coredata.keys()
                if self.opt_sorted:
                    self.do_item_sort('keys',keys)
                    
                all_fragments = []
                
                for key in keys:
                    # tag key and save fragment
                    k_subfrag,k_subobj = self.tag_object(key, '<key', '</key>', indent+2,
                                                    extensions=extensions)
                    # tag value and save fragment
                    v_subfrag,v_subobj = self.tag_object(coredata[key], '<val', '</val>', indent+2,
                                                    extensions=extensions)
                    # order tuple so it works with fragment_sort_func()
                    all_fragments.append( (k_subfrag, k_subobj, v_subfrag, v_subobj))					
                                
                # see note with set/frozenset (above) for why this can only be safely
                # done when deepcopy=1
                
                # sort fragments, if I'm allowed ...
                if self.opt_deepcopy:
                    self.do_sort_fragments("keys", all_fragments)
            
                # write fragments to stream
                for k_subfrag, k_subobj, v_subfrag, v_subobj in all_fragments:
                    xml_fragment += self.indent(indent+1) + '<entry>\n'
                    xml_fragment += k_subfrag
                    xml_fragment += v_subfrag
                    xml_fragment += self.indent(indent+1) + '</entry>\n'
                    
            handled_core = 1
            
        if coredata is None:
            handled_core = 1

        if not handled_core:
            raise XMLPicklingError("Bad coredata type: %s" % str(coredata))

        # write attrs (either data attrs, or an extension proplist)		
        if type(attrs) != DictType:
            raise XMLPicklingError("attrs must be a dict: %s" % str(attrs))

        # make sure I have attrs before (potentially) closing toptag
        if len(attrs):
            # if toptag still open, close before starting <attrs>
            if topopen:
                xml_fragment += '>\n'
                topopen = 0

            keys = attrs.keys()
            if self.opt_sorted:
                self.do_item_sort('attributes',keys)
                
            for key in keys:
                if rawparts != None:
                    # attrs is a proplist from an extension; key was
                    # checked vs. safe_attr_ASCII, but could still need
                    # escaping
                    subfrag,subobj = self.tag_object(attrs[key],
                                            '<attr name=%s' % xml_escape_attr(key),
                                            '</attr>', indent+1, extensions=extensions)
                    xml_fragment += subfrag											
                else:
                    # attr is from a Python object __dict__ or __slots__.
                    # don't need to escape attr name - is either a legal
                    # Python name, or prefix is OK (see DESIGN)
                    subfrag,subobj = self.tag_object(attrs[key], '<attr name="%s"' % key,
                                            '</attr>', indent+1, extensions=extensions)
                    xml_fragment += subfrag											
        
            # the keys are not modified as part of the above loop, so no need
            # to resort the fragments
            
        # else, attrs is empty -- already sanitized types, so no
        # need for an explicit 'else' here

        # =========== Finish Extension handling ============================

        # write any extension data
        if len(stackable_datalist) or (classext_datalist is not None):
            # if toptag still open, close before starting <attrs>
            if topopen:
                xml_fragment += '>\n'
                topopen = 0

        # write StackableExtension data
        if len(stackable_datalist):
            for name, coredata, propmap in stackable_datalist:
                # tag propmap names with "+"; keys were sanitized by
                # extension manager already (but still need escaping)
                plus_propmap = {}				
                for key,val in propmap.items(): # this will be sorted in tag_object()
                    plus_propmap['+'+key] = val
                    
                # create a Blob to hold coredata+proplist
                subfrag,subobj = self.tag_object(None, # ignored; using rawparts arg
                                                # tag extension name with "*"
                                                '<attr name=%s' % xml_escape_attr('*'+name),
                                                '</attr>', indent+1,
                                                rawparts=('blob', None, coredata, plus_propmap),
                                                extensions=extensions)
                xml_fragment += subfrag												

            # stackable_datalist is ordered, so there is no need to sort the fragments
            
        # write ClassExtension data
        if classext_datalist != None:
            propmap = classext_datalist[2] # for clarity
            
            # sort propmap keys, if needed
            keys = propmap.keys()
            if self.opt_sorted:
                self.do_item_sort('keys',keys)

            for key in keys:
                val = propmap[key]
                # keys were sanitized by extension manager, but still need escaping
                subfrag,subobj = self.tag_object(val,
                                        '<attr name=%s' % xml_escape_attr('+'+key),
                                        '</attr>', indent+1, extensions=extensions)
                xml_fragment += subfrag										
                                
            # note that the keys above cannot be modified by an extension, so 
            # no need to sort the fragments like with sets & dicts
            
        # tell ExtensionManager that orig_obj (not modified obj!) is complete
        if self.ext_manager is not None:
            self.ext_manager.close_object_tag(orig_obj)

        # if toptag still open, that means there was no inner "stuff",
        # so can close with /> instead of end_tag
        if topopen:			
            xml_fragment += '/>\n'
        else:			
            xml_fragment += self.indent(indent) + end_tag + '\n'
            
        # return xml_fragment and final object (possibly != orig_obj)
        return (xml_fragment, obj)
        
def pickle_object( fileobj, obj, allow_replicants=1, allow_rawpickles=0, deepcopy=0,
                   short_ids=0, sorted=0, prefer_cdata=0, comments=None, extensions=None,
                   break_hidden_refs=0, ext_basictypes=0):
    
    from gnosis.xml.xmlcoder import is_legal_xml
    
    # If no extensions are registered, and the caller didn't pass any, tell 
    # XMLPickleTagger that it can optimize and not call the extensions module at all.
    # In a way, this is more correct since any extensions that get loaded in the
    # middle of a pickling operation shouldn't be included since that might give
    # a confusing state.
    if _get_nr_extensions() == 0 and (extensions is None or len(extensions)==0):
        use_extensions = 0
    else:
        use_extensions = 1
        
    tagger = XMLPickleTagger(allow_replicants, allow_rawpickles,
                             deepcopy, short_ids, sorted, prefer_cdata, 
                             use_extensions, break_hidden_refs, ext_basictypes)

    # xml.pickle 1.1 generated the XML stream as a bytestream, encoding
    # as needed along the way.

    # Here, the XML stream is generated as Unicode. This gives an easy option,
    # if desired, of using another encoding on the backend.
    
    #fileobj.write( '<?xml version="1.0" encoding="utf-8"?>\n' )
    
    xml = '<?xml version="1.0"?>\n'
    xml += '<!DOCTYPE PyObject SYSTEM "PyObject.dtd">\n'

    # see if caller provided comments
    if type(comments) in [StringType,UnicodeType]:
        comments = [comments]

    if type(comments) in [ListType,TupleType]:
        for c in comments:
            if not type(c) in [StringType,UnicodeType]:
                raise XMLPicklingError("comment= must be a string or a list of strings.")

            if not is_legal_xml(c):
                raise XMLPicklingError("comment= must be legal XML.")

            if c.find('-->') >= 0:
                raise XMLPicklingError("Comment cannot contain '-->'")			

            xml += '<!-- %s -->\n' % c
        
    elif comments != None:
        raise XMLPicklingError("comment= must be a string or a list of strings.")	   	
    
    inner_xml,final_obj = tagger.tag_object( obj,
                                           '<PyObject version="1.3"',
                                           '</PyObject>', 0, extensions=extensions)
                                           
    xml += inner_xml										   
    
    # write XML to fileobj now that pickling has been successful
    fileobj.write(xml)
    
    return tagger.stats

