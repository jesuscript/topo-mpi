"""

Some nice extras built on top of xml.pickle.

"""
__author__ = ['Frank McIngvale (frankm@hiwaay.net)']

# public API
__all__ = ['xmlequal', 'object_sha']

from gnosis.xml.pickle import dumps as xml_dumps, loads as xml_loads
import sha
from types import StringType

def xmlequal(objA, objB, allow_rawpickles=0, deepcopy=0, extensions=[],
                ext_basictypes=0):
    """
    Deeply compare two objects by dumping them in a deterministic manner
    and comparing their XML streams.
    
    This ensures that both the data AND datatypes match, i.e. it is a NON-coercive 
    comparsion -- 123 != 123.0
    
    Setting allow_rawpickles=1 means that xml.pickle is allowed to use cPickle if it
    cannot otherwise pickle an object. However, this makes the pickling non-deterministic
    across Python versions and even across multiple runs on the same Python version (dependent
    on the data itself), so it defaults to 0.
    
    The deepcopy flag is passed to dumps() and has the same meaning as there.
    This is useful in situations where you know the references might not be
    the same between two objects, but just want to compare content.
    
    'extensions' are any extra extensions you want to include (in addition to
    those already registered)
    """   
    return (norm_xml(objA, allow_rawpickles, deepcopy, extensions, ext_basictypes) == 
            norm_xml(objB, allow_rawpickles, deepcopy, extensions, ext_basictypes))

def object_sha(obj, allow_rawpickles=0, deepcopy=0, extensions=[], ext_basictypes=0):
    """
    Calculate the secure hash (SHA-1) of an object from its final serialized
    representation. The hash is calculated in such a way that it will be
    consistent over multiple runs and across Python versions. (This is NOT the case 
    with the standard pickle/cPickle).
    
    Note that the final SHA-1 is dependent on whatever extensions are currently
    loaded, so the same extensions must be loaded when checking the object later
    (if any of the extensions modified the object).
    
    Setting allow_rawpickles=1 means that xml.pickle is allowed to use cPickle if it
    cannot otherwise pickle an object. However, this makes the pickling non-deterministic
    across Python versions and across multiple runs (dependent on the data itself), so it 
    defaults to 0.
    
    The deepcopy flag is passed to dumps() and has the same meaning as there.
    This is useful in situations where you know the references might not be
    the same, but just want to compare content.
    
    'extensions' are any extra extensions you want to include (in addition to
    those already registered)
    """
    # note that the returned XML is a plain Python bytestring, so it can
    # be fed directly to sha.update()
    s = sha.new()
    s.update(norm_xml(obj, allow_rawpickles, deepcopy, extensions, ext_basictypes))
    return s.hexdigest()

def object_slowcmp(objA, objB, allow_rawpickles=0):
    """
    Combines xmlequal() and object_sha_core() to deeply compare two objects 
    in a non-coercive way.
    
    This is quite slow, but gives a good double-check in case something
    is getting mangled in the XML serialization. This is used frequently in
    the test suite where it's more important to ensure that two objects REALLY
    are identical (and to detect any serialization errors) than to be fast.
    
    For normal use, using object_sha() or xmlequal() alone is sufficient,
    since either will give the same ultimate (Yes/No) answer, assuming
    there are no bugs in xml.pickle.
    """
    # No need to use both object_sha() AND xmlequal() since they use the same XML streams.
    # However, using object_sha_core() and xmlequal() is a nice double-check since they
    # are summing different things.
    hA = object_sha_core(objA, allow_rawpickles)
    hB = object_sha_core(objB, allow_rawpickles)
    return (hA == hB) and xmlequal(objA, objB, allow_rawpickles)
    
def norm_xml(obj, allow_rawpickles=0, deepcopy=0, extensions=[], ext_basictypes=0):
    """
    Return a normalized XML encoding of object. "Normalized" meaning that
    the encoding will be repeatable over a series of runs, and across Python versions.
    
    Setting allow_rawpickles=1 means that xml.pickle is allowed to use cPickle if it
    cannot otherwise pickle an object. However, this makes the pickling non-deterministic
    across Python versions, so it defaults to 0.
    
    The deepcopy flag is passed to dumps() and has the same meaning as there.
    This is useful in situations where you know the references might not be
    the same, but just want to compare content.
    
    'extensions' are any extra extensions you want to include (in addition to
    those already registered)
    
    NOTE: 
        You should NOT, in general, use norm_xml() as a replacement for dumps().
        It can break references in certain situations for purposes of text
        comparison. This is really only meant to be used as part of a text comparison
        of two objects.
    """
    # dump in a deterministic way so XML streams can be compared between objects
    return xml_dumps(obj,
                    # short_ids=1 makes pickler generate a sequence number for each
                    # object id= attribute instead of using id()
                    short_ids=1,
                    # sorted=1 ensures that object are written in a fixed order that
                    # won't change when, e.g. the Python dict hashing scheme changes
                    sorted=1, 
                    # allowing rawpickles breaks deterministic behavior (since it uses cPickle,
                    # which is not deterministic), but is the only option in certain cases
                    allow_rawpickles=allow_rawpickles,
                    # Python will make "hidden" refs behind your back for e.g. small integers
                    # and strings. This is non-deterministic since it varies across Python
                    # versions as well as across multiple runs (dependent on the data itself).
                    #
                    # In normal Python code, this should never cause a problem. Only in the specific 
                    # case of comparing two serialized streams will this matter.
                    #
                    # This flag tells the pickler to ignore refs for those objects. Simply
                    # passing deepcopy=1 is no good since that would make self-referencing objects
                    # unusable here.
                    break_hidden_refs=1,
                    # pass along the deepcopy flag
                    deepcopy=deepcopy,
                    # pass along any extra extensions
                    extensions=extensions,
                    ext_basictypes=ext_basictypes)
    
def object_sha_core(obj, allow_rawpickles=0):
    """
    Calculate the secure hash (SHA-1) of an object from its "in-core" representation.
    
    The SHA-1 is calculated on the object contents BEFORE any extensions modify it,
    or any extra "stuff" is added as part of the XML tagging process.

    This is NOT as exact of a test as object_sha(), since it ignores references for
    example, but it a nice sanity check as part of the test suite to ensure that nothing
    is being messed up in the extension/tagging processes.
    
    Setting allow_rawpickles=1 means that xml.pickle is allowed to use cPickle if it
    cannot otherwise pickle an object. However, this makes the pickling non-deterministic
    across Python versions, so it defaults to 0.
    """
    ext = SHAExtension(allow_rawpickles)
    
    # when sorted=1, not only is output sorted, but the objects are
    # tagged in sorted order as well, so the SHA sum is guaranteed
    # to be generated in the same order each time, even across different
    # machines and/or Python versions.
    #
    # StackableExtensions run before ClassExtensions, and since ext is
    # being passed directly to dumps (as opposed to being registered), it
    # will run first. This ensures that SHAExtension will see all objects
    # in their original form.
    xml = xml_dumps(obj, sorted=1, extensions=[ext],
                    allow_rawpickles=allow_rawpickles)
    return ext.getsum()
    
#--------------------------------------------------------------------------------
# Implementation details.
#--------------------------------------------------------------------------------
from gnosis.xml.pickle.extensions import StackableExtension
from gnosis.xml.pickle.objmodel import decompose, UElement

class SHAExtension(StackableExtension):
    """
    A "write-only" extension used by object_sha().
    Keeps a running SHA sum of all data that passes through it.
    
    It is intended to be used once and discarded.
    """
    def __init__(self, allow_rawpickles):
        StackableExtension.__init__(self, 'SHAExtension')
        self.sha = sha.new()
        
        self.allow_rawpickles = allow_rawpickles
        
    def getsum(self):
        return self.sha.hexdigest()
        
    def pickle(self, obj):
        # not actually pickling anything here, just extracting those parts of
        # the object that are SHA-summable and adding them in to the total
        
        #print "sha-pickle: %s" % repr(obj)
        # this is a "write-only" extension so it is safe to allow rawpickles.
        # accept replicants also, to be completely generic.
        otype,classtag,coredata,attrs = decompose(obj,allow_replicants=1,
                                                    allow_rawpickles=self.allow_rawpickles)
        #print "DECOMPOSE <%s>, <%s>, <%s>, <%s>" % (otype,classtag,repr(coredata),repr(attrs))

        # add type string to sum
        self.sha.update(otype)
        
        # add classtag to sum
        if classtag != None:		
            self.sha.update(classtag)
        
        # the 'attrs' will be passed to me later, one by one, so I don't have
        # to do anything with them here
        
        # if it's an atomic type, add to sum
        if otype == 'numeric':
            # coredata is a string
            self.sha.update(coredata)
        elif otype in ['string','blob']:
            if isinstance(coredata,UElement):
                # encode Unicode to a bytestring to feed to sha.update()
                self.sha.update(coredata.encoded.encode('utf-8'))
                
                # include encoding as well
                self.sha.update(coredata.encoding)
                
            elif type(coredata) is StringType: # Python < 2.2 compatibility
                self.sha.update(coredata)				
            else:
                # should never happen
                raise Exception("???")
        elif otype == 'True':
            self.sha.update('True')
        elif otype == 'False':
            self.sha.update('False')
        elif otype == 'None':
            self.sha.update('None')
        elif otype in ['class','function','pyobj','list',
                        'tuple','set','frozenset','dict']:
            # nothing to sum here - their components parts (coredata & attrs)
            # will be passed to me later
            #
            # (in the case of 'class' and 'function', their classtag
            # has already been added to the sum)
            pass
        else:
            # sanity check, in case I add a new type ... 
            raise Exception("Unknown type: %s" % otype)
            
        # I don't actually do anything to the object
        return self.ignore(obj)

