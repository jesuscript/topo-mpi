"""
The xml.pickle 1.3 parser (SAX based).

Most of the "heavy lifting" is done in objmodel.compose_*
The parser just has to collect the pieces in the correct order 
for the compose_* routines to rebuild the object.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from xml.sax.expatreader import ExpatParser
from xml.sax.handler import ContentHandler, ErrorHandler
from xml.sax.xmlreader import InputSource
from cStringIO import StringIO
import objmodel
from gnosis.xml.pickle.api import XMLUnpicklingError, SEARCH_STORE, \
     XMLPickleStats, XMLPickleOptions
from objmodel import UElement
from extensions import run_unpickle_extensions, run_classext_begin_core, \
     run_classext_begin_nocore, run_classext_set_coredata
import re

DEBUG = 0

def ppp(s): print s

if DEBUG:
    def ddd(s): print s
else:
    def ddd(s): pass
    
# -- An XMLParsedElement will always be in one of the following states --

# temporary start state before initialization
S_START = 0

# opening tag has been parsed, partial object not set; collecting
# any <meta> tags before creating partial obj
S_COLLECT_META = 1

# <meta> is finished; partial_obj is not set; waiting on core items
# before creating partial_obj (core is immutable)
S_WAIT_CORE = 2
# <meta> is finished; partial_obj is set; collecting core items (core is mutable)
S_COLLECT_CORE = 3
# core complete; partial_obj valid; collecting attrs
S_COLLECT_ATTR = 4

# <u> tag, open & collecting body text
S_UELEMENT_OPEN = 5
# <entry> tag, waiting on key:value
S_ENTRY_OPEN = 6

# All elements end up in S_FINALIZED, with final_obj set
# to the final value (see final_obj notes below).
S_FINALIZED = 7

# for debugging only ... sync w/above
STATE_NAMES = ['blank','S_COLLECT_META','S_WAIT_CORE','S_COLLECT_CORE',
               'S_COLLECT_ATTR','S_UELEMENT_OPEN','S_ENTRY_OPEN','S_FINALIZED']

#-------------------------------------------------------------------
# State flowchart.
#
# Implicitly starts in S_START, and transitions on a startElement
# 
# on start <PyObject,attr,item,key,val>: -> S_COLLECT_META
#
# on start <entry>: -> S_ENTRY_OPEN
#
# on start <u>: -> S_UELEMENT_OPEN
#
# S_COLLECT_META:
#     on close sub <meta .. > -> add to list -> S_COLLECT_META
#     on start not <meta .. > ->
#        type= needs core before create?
#             YES ->
#                value= given?
#                   YES -> create_partial -> S_COLLECT_ATTR
#                   NO -> S_WAIT_CORE
#             NO -> S_COLLECT_CORE
#
# S_COLLECT_CORE | S_WAIT_CORE:
#     on close sub <u>:
#        create_partial -> S_COLLECT_ATTR
#     on close sub <entry>:
#        add to list -> <remain in state>
#     on close sub <item>:
#         add to list -> <remain in state>
#     on start <attr>:
#         create_partial -> S_COLLECT_ATTR
#     on close self:
#         create_partial -> complete_obj -> S_FINALIZED
#
# S_COLLECT_ATTR:
#     on close sub <attr> -> add to list -> S_COLLECT_ATTR
#     on close self -> complete_obj -> S_FINALIZED
#
# S_ENTRY_OPEN:
#     on close self -> pop key,val & complete_obj -> S_FINALIZED
#
# S_UELEMENT_OPEN:
#     on chars -> append -> S_UELEMENT_OPEN
#     on close self -> complete_obj -> S_FINALIZED
#
#-------------------------------------------------------------------

# On every startElement(), I add an XMLParsedElement to elem_stk.		
class XMLParsedElement:
    def __init__(self, parent, tag, attrs, parser_opts, refmap):
        # for efficiency, I remember my parent element
        self.parent = parent		
        # my <tagname>
        self.tag = tag
        # my attrs._attrs, from startElement()
        self.tag_attrs = attrs
        # save parser options
        self.parser_opts = parser_opts
        
        # In state S_FINALIZED, the final value is placed here.
        # If element is <u>: this is the UElement
        # If element is <entry>, this is a tuple of (key,val).
        # Else, it is an object.
        # ** IF YOU SET .final_obj, you must set .state=S_FINALIZED **
        self.final_obj = None
        self.is_replicant = 0
        
        # If state==S_UELEMENT_OPEN, body text is collected here,
        # to be finalized into .final_obj as a UElement.
        # All other body text is discarded.
        self.content = u''

        # my sub <meta> elements are placed here, as name:val
        # (metadata is defined as unordered)
        self.metadata_dict = {}
        # my sub <item> elements are placed here
        self.item_list = []
        # my sub <entry> elements are placed here (they were created
        # from a dict, so order doesn't matter)
        self.entry_dict = {}
        # my <attr> elements that don't begin with '+' or '*' are placed here.
        # (go ahead and place in dict since order not important on those attrs)
        # note that '#' attrs will be here too, since objmodel expects them.
        self.attr_dict = {}

        # any sub "+" <attrs> are placed here. these are propmap entries
        # from an extension. they are saved with the '+' stripped from
        # the key.
        self.plus_attr_dict = {}

        # any sub "*" <attrs> are placed here. they are saved
        # as (name,propmap) tuples, where name has the "*" stripped,
        # and propmap is the (key,val) dict from the plus_list.
        # these represent StackableExtensions that must be called in order,
        # so the list order is preserved.
        self.star_attr_list = []

        # initialize .state and .partial_obj
        self.state = S_START
        self.leavestate_START(refmap)

    def remember_object(self, refmap, obj, refid):
        #ddd("REMEMBER %s" % refid)
        if refid is None:
            return
        
        if refmap.has_key(refid):
            raise XMLUnpicklingError("Two objects with the same id= found.")

        refmap[refid] = obj

    def create_top_core(self, tag_attrs, coredata):
        "Create an empty object from the tag_attrs and coredata."
        # get my newargs
        if self.metadata_dict.has_key('#newargs'):
            newargs = self.metadata_dict['#newargs']
            # okay to delete in place - this is my data, not userdata
            del self.metadata_dict['#newargs']
        else:
            newargs = None
            
        # is it a regular type/class or a ClassExtension?
        if tag_attrs.get('class',' ')[0] != '*':
            # regular type/class
            partial_obj,is_replicant = objmodel.compose_top_core(
                tag_attrs.get('type'),
                tag_attrs.get('class',None),
                coredata,
                newargs,
                self.parser_opts.class_search,
                self.parser_opts.allow_replicants)
        else:
            # ClassExtension, class="*NAME"
            klass = self.tag_attrs.get('class')[1:] # skip '*'
            partial_obj = run_classext_begin_core(klass, tag_attrs.get('type'),
                                                  self.metadata_dict, coredata,
                                                  self.parser_opts.class_search,
                                                  self.parser_opts.allow_replicants,
                                                  self.parser_opts.unpickle_extensions)
            is_replicant = 0

        return (partial_obj,is_replicant)
    
    def create_top_nocore(self, tag_attrs):
        "Create an empty object without coredata, using the given tag_attrs."
        # get my newargs
        if self.metadata_dict.has_key('#newargs'):
            newargs = self.metadata_dict['#newargs']
            # okay to delete in place - this is my data, not userdata
            del self.metadata_dict['#newargs']
        else:
            newargs = None
        
        # is it a regular type/class or a ClassExtension?
        if tag_attrs.get('class',' ')[0] != '*':
            # regular type/class
            partial_obj, is_replicant = objmodel.compose_top_nocore(
                tag_attrs['type'],
                tag_attrs.get('class',None),
                newargs,
                self.parser_opts.class_search,
                self.parser_opts.allow_replicants)
        else:
            klass = tag_attrs.get('class')[1:] # skip '*'
            partial_obj = run_classext_begin_nocore(klass, tag_attrs['type'],
                                                    self.metadata_dict,
                                                    self.parser_opts.class_search,
                                                    self.parser_opts.allow_replicants,
                                                    self.parser_opts.unpickle_extensions)
            is_replicant = 0
            
        return (partial_obj,is_replicant)

    def changestate_on_CORETYPE(self, refmap):
        """
        Called from S_COLLECT_META when it is time to transition to
        either S_WAIT_CORE, S_COLLECT_CORE or S_COLLECT_ATTR,
        depending on the coretype defined by my type=
        """
        if self.state != S_COLLECT_META:
            raise XMLUnpicklingError("Bad state transition.")
        
        # does this type use coredata?
        if objmodel.type_wants_core(self.tag_attrs['type']):
            # decide whether to create .partial_obj now				
            if objmodel.compose_needs_coredata(self.tag_attrs['type']):
                # have to have core before creating .partial_obj.
                # If I have a value= then my coredata is there;
                # else go into a waiting state
                val = self.tag_attrs.get('value',None)
                if val is not None:
                    # complete coredata is value=, create obj now (note this
                    # means that is an immutable core)
                    self.partial_obj,self.is_replicant = self.create_top_core(
                        self.tag_attrs,
                        # due to pickler rules, this must be ASCII; enforce
                        str(val))

                    # add to refmap
                    self.remember_object(refmap, self.partial_obj,
                                         self.tag_attrs.get('id',None))

                    # ready for <attr> list now
                    self.state = S_COLLECT_ATTR
                else:
                    # core is in <u>, <item> list, or <entry> list; wait
                    self.state = S_WAIT_CORE
                    self.partial_obj = None
            else:
                # core can self-reference (mutable core), so create
                # partial_obj now from type & class
                self.state = S_COLLECT_CORE

                self.partial_obj, self.is_replicant = self.create_top_nocore(
                    self.tag_attrs)

                # add to refmap
                self.remember_object(refmap, self.partial_obj,
                                     self.tag_attrs.get('id',None))

        else:
            # this type doesn't use coredata; create now, and
            # transition immediately to S_COLLECT_ATTR
            self.state = S_COLLECT_ATTR

            self.partial_obj,self.is_replicant = self.create_top_nocore(
                self.tag_attrs)

            # add to refmap
            self.remember_object(refmap, self.partial_obj,
                                 self.tag_attrs.get('id',None))
        
    def leavestate_START(self, refmap):
        """
        Transition out of S_START, based on .tag and .tag_attrs.
        Initializes .partial_obj
        """
        # for semantic clarity, .partial_obj is used while the
        # element tag is open, and .final_obj is used thereafter

        # if my tag has a refid=, I'm done! :-)
        refid = self.tag_attrs.get('refid',None)
        if refid != None:
            try:
                #ddd("GOT REF %s" % refid)
                self.final_obj = refmap[refid]
            except KeyError:
                print "DUMPING REFMAP ",refmap
                raise XMLUnpicklingError("INTERNAL ERROR - No refid '%s'" % refid)
            
            self.state = S_FINALIZED
            return
        
        if self.tag in ['PyObject','attr','item','key','val','meta']:
            # collect any <meta> elements first
            self.state = S_COLLECT_META
            self.partial_obj = None

        elif self.tag == 'u':
            # move -> U_ELEMENT_OPEN
            self.state = S_UELEMENT_OPEN
            self.partial_obj = None

        elif self.tag == 'entry':
            # move -> S_ENTRY_OPEN
            self.state = S_ENTRY_OPEN
            self.partial_obj = None

        else:
            raise XMLUnpicklingError("Unknown tag <%s>" % self.tag)

    def leavestate_CORE(self, coredata, refmap):
        """
        Coredata has been completed, and is passed as 'coredata'.
        Transition from either S_WAIT_CORE or S_COLLECT_CORE
        to S_COLLECT_ATTR. Finishes .partial_obj before entering S_COLLECT_ATTR.
        """
        # can only have one coredata value; make sure I'm in an allowed state.
        if self.state == S_WAIT_CORE:
            # immutable core; create partial_obj now
            newargs = self.metadata_dict.get('#newargs',None)			
            self.partial_obj,self.is_replicant = self.create_top_core(
                self.tag_attrs, coredata)

            # add to refmap
            self.remember_object(refmap, self.partial_obj,
                                 self.tag_attrs.get('id',None))

            # ready for <attr> list now
            self.state = S_COLLECT_ATTR

        elif self.state == S_COLLECT_CORE:
            # mutable core; partial_obj valid; set core now
            
            # is it a regular type/class or a ClassExtension?
            if self.tag_attrs.get('class',' ')[0] != '*':
                # regular type/class
                objmodel.compose_setcore(
                    self.tag_attrs.get('type'),
                    self.partial_obj,
                    coredata)
            else:
                klass = self.tag_attrs.get('class')[1:] # skip '*'
                run_classext_set_coredata(klass, 
                                        self.tag_attrs.get('type'),
                                        self.partial_obj, coredata,
                                        self.parser_opts.unpickle_extensions)
            
            # ready for <attr> list now
            self.state = S_COLLECT_ATTR

        else:
            raise XMLUnpicklingError("Validity error: Multiple coredata objects not allowed.")

    def ensure_core_complete(self, refmap):
        """
        This is called when there is no more coredata to collect.
        Closeout my coredata, if it isn't already (if I have
        no <attrs>, there will be no tag that results in
        subelement_complete() being called.)
        """
        # if I had no coredata or attrs, I could still be in
        # S_COLLECT_META; change to S_WAIT_CORE|S_COLLECT_CORE|S_COLLECT_ATTR
        if self.state == S_COLLECT_META:
            self.changestate_on_CORETYPE(refmap)
            # and keep going ...
            
        #ddd("ENSURE CORE %s" % self)
        if self.state not in (S_WAIT_CORE, S_COLLECT_CORE):
            return	# my core is already complete & partial_obj exists

        # Note that the only possible locations for my coredata at
        # this point are item_list & entry_dict. If coredata was in
        # value= or <u>, it was handled at the time those elements
        # were seen.
        #if len(self.item_list) == 0 and len(self.entry_dict.keys()) == 0:
        if len(self.item_list) == 0 and len(self.entry_dict) == 0:					
            coredata = objmodel.get_default_coredata(self.tag_attrs['type'])
            if coredata is None:
                raise XMLUnpicklingError("Validity error: coredata cannot be omitted here (type=%s)." % (self.tag_attrs['type']))
        #elif len(self.item_list) and len(self.entry_dict.keys()):
        elif len(self.item_list) and len(self.entry_dict):
                raise XMLUnpicklingError("Validity error: Cannot have both <item> and <entry> lists.")					
        elif len(self.item_list):
            coredata = self.item_list
        else:
            coredata = self.entry_dict

        #ddd("COREDATA %s"%coredata)
        
        # save a little memory by getting rid of coredata now
        self.item_list = None
        self.entry_dict = None

        # complete partial_obj & set state to S_COLLECT_ATTR
        self.leavestate_CORE( coredata, refmap )
        
    def subelement_start(self, name, refmap):
        """
        Notifies me when a subelement tag is first opened
        (and before the subelement exists at all).
        """
        if self.state == S_COLLECT_META and name != 'meta':
            # Any non-<meta> subelement that starts while in S_COLLECT_META
            # means that it's time to move to (S_WAIT_CORE|S_COLLECT_CORE|S_COLLECT_ATTR)
            self.changestate_on_CORETYPE(refmap)
            # now, keep going in case it's an <attr>
            
        if name == 'attr':
            # Critical - this <attr> is allowed to reference me, so I have
            # to make sure my .partial_obj has been created (at least with
            # coredata) before this subelement can even be parsed.
            
            # If I'm currently collecting coredata, then the first <attr>
            # marks the end of it, so finish up the core handling.
            if self.state in [S_WAIT_CORE, S_COLLECT_CORE]:
                # sets .state to S_COLLECT_ATTR
                self.ensure_core_complete(refmap)

        # for all others, I don't have to see the element until
        # subelement_complete()
        
    def subelement_complete(self, subelem, refmap):
        """
        Every time a subelement is finalized, the parent element is
        notified via subelement_complete(). The finalized
        subelement is passed as an argument.

        This serves a few purposes:
           - Parent elements need to know when subelements
             are complete in order to do state transitions.
           - Validity checking can mostly be done here, instead
             of scattered all over.
           - No need to keep finalized subelements on elem_stk;
             just pass here & discard. Parent will put it wherever
             it's needed for the eventual parent finalization.
        """
        #ddd("SUBELEM COMPLETE %s" % subelem)

        if subelem.tag == 'u':
            # can only have one <u> tag, so it's my complete coredata.
            self.leavestate_CORE( subelem.final_obj, refmap )

        elif subelem.tag == 'item':
            # received part of my coredata in an <item>; add it
            # to item_list, assuming I'm in an allowed state
            if self.state in [S_WAIT_CORE, S_COLLECT_CORE]:
                self.item_list.append( subelem.final_obj )
            else:
                raise XMLUnpicklingError("Validity error: <item> not allowed here.")

        elif subelem.tag == 'entry':
            # received part of my coredata in an <entry; add it
            # to entry_dict, assuming I'm in an allowed state
            if self.state in [S_WAIT_CORE, S_COLLECT_CORE]:
                self.entry_dict[subelem.final_obj[0]] = subelem.final_obj[1]
            else:
                raise XMLUnpicklingError("Validity error: <item> not allowed here.")

        elif subelem.tag == 'meta':
            if self.state != S_COLLECT_META:
                raise XMLUnpicklingError("Validity error: <attr> not allowed here.")

            # name might have a '#' prefix, but will NOT have a '+' or '*' prefix.
            # see tagger for details.
            name = subelem.tag_attrs['name']
            self.metadata_dict[name] = subelem.final_obj
            
        elif subelem.tag == 'attr':
            if self.state != S_COLLECT_ATTR:
                raise XMLUnpicklingError("Validity error: <attr> not allowed here.")
            
            # Check if it is a special (+, *) attr or a normal
            # data attribute (including '#' attrs)

            name = subelem.tag_attrs['name']

            if name[0] == '+':
                # collect my "+" items
                self.plus_attr_dict[name[1:]] = subelem.final_obj

            elif name[0] == '*':
                # it's a "*", so it has a "+" list. roll subelement "+" list
                # along with subelem coredata into my "*" list, stripping
                # "*" (tuple order is same as expected by run_unpickle_extensions)
                self.star_attr_list.append( (name[1:], subelem.final_obj,
                                             subelem.plus_attr_dict) )

            else:
                # else, it's a regular (unordered) data attribute
                self.attr_dict[name] = subelem.final_obj
                    
        else:
            raise XMLUnpicklingError("Validity error: <%s> not allowed here." % subelem.tag)

    def __str__(self):
        if not DEBUG:
            return ''
        else:
            s = '<%s> state=%s\n' % (self.tag,STATE_NAMES[self.state])
            s += '  tag_attrs = %s\n' % repr(self.tag_attrs)
            s += '  attr_list = %s\n' % str(self.attr_dict)		
            s += '  item_list = %s\n' % str(self.item_list)
            s += '  entry_dict = %s\n' % str(self.entry_dict)		
            if self.state == S_FINALIZED:
                s += '  final = %s\n' % repr(self.final_obj)
            else:
                s += '  partial = %s\n' % repr(self.partial_obj)
            
            return s
    
class xmlpickle_handler(ContentHandler):
    def __init__(self, class_search, allow_replicants, allow_rawpickles, unpickle_extensions):
        ContentHandler.__init__(self)
        self.elem_stk = []
        self.refmap = {}
        self.parser_opts = XMLPickleOptions(class_search,allow_replicants,
                                            allow_rawpickles, unpickle_extensions)
        self.stats = XMLPickleStats()

    def get_object(self):
        return self.the_object

    def get_stats(self):
        return self.stats
    
    def printstk(self):
        if not DEBUG:
            return
        
        ddd("--------STACK DUMP START------------------")
        for ent in self.elem_stk:
            ddd(ent)

        ddd("--------STACK DUMP END------------------")
        
    def startDocument(self):
        #ddd("START DOC")
        pass
    
    def endDocument(self):
        #ddd("END DOC")
        #self.printstk()
        #ddd(self.the_object)
        pass
    
    def startElement(self, name, attrs):
        # if previous element has been finalized, then it
        # is my sibling, and its parent is my parent.
        # else, it is my parent. if stack empty, I have no parent.
        #ddd("START %s,%s" % (name,str(attrs._attrs)))
        
        if not len(self.elem_stk):
            my_parent = None
        elif self.elem_stk[-1].state == S_FINALIZED:
            my_parent = self.elem_stk[-1].parent
        else:
            my_parent = self.elem_stk[-1]

        # parent needs to be notified *before* parsing of the
        # element begins in certain cases (see above) to get refs correct
        if my_parent != None:
            my_parent.subelement_start( name, self.refmap )
        
        element = XMLParsedElement( my_parent, name, attrs._attrs,
                                    self.parser_opts, self.refmap )

        self.elem_stk.append( element )

        #ddd("-------STACK AFTER START---------")
        #self.printstk()
        
    def endElement(self, name):
        #ddd("---- ENTER <end> %s" % name)
        #self.printstk()		
        
        if name == 'entry':
            # I know the top two items on the stack
            # are my <key>:<val> pair
            e1 = self.elem_stk.pop()
            e2 = self.elem_stk.pop()

            # pop <entry> element
            elem = self.elem_stk.pop()

            # place key:val in final_obj as (key,val) 
            # (don't assume an ordering of key/val)
            if e1.tag == 'key':
                elem.final_obj = (e1.final_obj,e2.final_obj)
            else:
                elem.final_obj = (e2.final_obj,e1.final_obj)				

            elem.state = S_FINALIZED

        elif name == 'u':
            # get <u> element
            elem = self.elem_stk.pop()

            # decode .content
            ue = UElement( encoded=elem.content,
                           # unicode/plain is the default encoding
                           encoding=elem.tag_attrs.get('encoding','unicode/plain'),
                           allow_rawpickles=self.parser_opts.allow_rawpickles)
            ue.decode()
            
            # save decoded to final_obj
            elem.final_obj = ue.plain
            elem.state = S_FINALIZED
            
        else: # <PyObject>, <attr>, <item>, <key>, <val>
        
            # pop element
            elem = self.elem_stk.pop()
            
            if elem.state != S_FINALIZED:
                # At this point, we know for sure that there can be no
                # more coredata, so close out elem coredata, if it isn't
                # already closed. (If elem has no <attrs>, there will
                # be no other trigger than endElement to say "coredata
                # is finished").
                elem.ensure_core_complete(self.refmap)

                # finalize object

                # do normal finalization first

                if objmodel.type_needs_finalization(elem.tag_attrs['type']):
                    elem.final_obj = objmodel.finalize_object(elem.partial_obj,
                                                              elem.attr_dict)
                else:
                    elem.final_obj = elem.partial_obj

                # now do Extension finalization
                
                # if it is a ClassExtension, have it finalize itself now
                if elem.tag_attrs.get('class',' ')[0] == '*':
                    # metadata has been used already, this is just the
                    # finalization step
                    classext_datalist = (elem.tag_attrs.get('class')[1:], # skip '*'
                                         {}, elem.plus_attr_dict)
                    
                    #klass = elem.tag_attrs.get('class')[1:] # skip '*'
                    #elem.final_obj = run_unpickle_extensions(elem.partial_obj,
                    #										 EXT_TYPE_CLASSEXT,
                    #										 # metadata not needed here
                    #										 (klass,(),elem.plus_attr_list))				
                else:
                    classext_datalist = None
                    
                #ddd("AFTER FINAL %s" % elem)
                
                #if len(elem.star_attr_list):
                    # if there are one or more sub "*" attrs, then those are
                    # StackableExtensions that need finalization now
                    #elem.final_obj = run_unpickle_extensions( elem.final_obj,
                    #									  EXT_TYPE_STACKABLE,
                    #										  elem.star_attr_list )

                elem.final_obj = run_unpickle_extensions( elem.final_obj,
                                                          elem.star_attr_list,
                                                          classext_datalist,
                                                          self.parser_opts.unpickle_extensions)
                                                          
                elem.state = S_FINALIZED				
            
            # Update stats
            #
            # Notes: 
            #    Only 5 tags for this block (<PyObject>, <attr>, <item>, <key>, <val>)
            #    represent user-level objects; the others are internal pieces that
            #    shouldn't be counted in the stats.
            #
            #    Note that 'is_replicants' isn't complete until above code block is finished,
            #    so can't do stats till here.
            self.stats.nr_objects += 1
            self.stats.nr_replicants += elem.is_replicant
                            
        # - decide what to do with finished element -
        
        # <key>, <val> are just pushed back on  stack - <entry> will
        # pop them off (see above)
        if elem.tag in ['key','val']:
            self.elem_stk.append( elem )

        elif elem.parent is None:
            # this is the root object (PyObject); save it
            #ddd("GOT FINAL OBJ %s, %s" % (elem, elem.final_obj))
            self.the_object = elem.final_obj
            
        # all others: notify my parent that I'm complete; parent will
        # save info it needs from elem, and elem can be discarded
        else:
            elem.parent.subelement_complete( elem, self.refmap )
            
        #ddd("--- EXIT <end>")
        self.printstk()
        
    def characters(self, content):
        # characters belong to currently opened tag,
        # but don't bother saving unless it's a <u>
        if self.elem_stk[-1].state == S_UELEMENT_OPEN:
            self.elem_stk[-1].content += content

    # implement the ErrorHandler interface here as well
    def error(self, exception):
        print "** ERROR - dumping stacks"
        self.printstk()
        # re-raise exception		
        raise

    def fatalError(self, exception):
        print "** FATAL ERROR - dumping stacks"
        self.printstk()
        print "SYS ID",exception.getSystemId()
        # re-raise exception
        raise

    def warning(self, exception):
        print "WARNING"
        # re-raise exception		
        raise

    # Implement EntityResolver interface (called when the parser runs
    # across external entities - in our case, PyObjects.dtd).
    # For now we just ignore - we're using expat which is a non-validating
    # parser anyways (apparently xmlproc will validate, but expat is
    # chosen for speed). If we want to do validation in the future, we
    # can update this.
    def resolveEntity(self, publicId, systemId):
       inp = InputSource()
       inp.setByteStream(StringIO(""))
       return inp

