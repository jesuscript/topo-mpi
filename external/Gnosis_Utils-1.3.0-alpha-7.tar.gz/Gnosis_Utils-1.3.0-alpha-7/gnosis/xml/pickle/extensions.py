"""
xml.pickle Extension objects

There are three types of Extension objects:
    StackableExtension
    ClassExtension
    LoadOnlyExtension

Each has a different purpose, and different pros/cons to their usage.
Refer to their definitions below, but briefly:

    StackableExtension:
        Pros:
           Simple API - 'object in/object out'
           Stackable - makes it easy to write modular extensions that
           			   operate in a pipelined way 
        Cons:
           Cannot hold self-referencing data.

    ClassExtension:
        Pros:
           Can hold self-referencing data.
        Cons:
           Cannot 'stack' - only one can operate on any object.
           Complex API - depends on type returned by the extension.

    LoadOnlyExtension:
        Pros:
           Can be called for any object, even if it wasn't previously
           'tagged' during pickling.
           Easy API - 'object-in/object-out'.
        Cons:
           Only of use while unpickling (not really a con - that's what
           it is designed for.)

GENERAL NOTE/CAUTION:

The pickler assumes the following about *both* StackableExtensions and
ClassExtensions:

    a. They are stateless/invariant: If F(x) is an extension, then
       F(x) will *always* return the same value for a given value of x.

       [This assumption is used to maintain self-references across
       extensions. Although it would be possible to add a flag on a
       per-extension basis to turn off this assumption, it is not currently
       seen as needed, so isn't implemented.]

       [The standard pickle module doesn't seem to recognize 'stateful'
       pickling, e.g. a __getstate__ that returns different values each
       time you call it, so xml.pickle shouldn't worry about it either.]

    b. They *must not* alter the original object they are passed
       in pickle(). There are two reasons for this: First, in general,
       the act of pickling should not change the data being pickled;
       changing the original object in an extension would be bad form.
       Secondly, this assumption is used in order to guard against a
       StackableExtension altering a self-referencing object. (See docs
       for StackableExtension & ExtensionManager, for details).

       Passing a deepcopy() of the object to the extension, then doing
       a deep cmp() afterwards would be prohibitively slow (and wouldn't
       work with self-referencing objects), so it is up to the Extension 
       to ensure that it follows this rule.
       
    c. If F(objA) and F(objB) both return the same object (even if they have
       different metadata/coredata/propmap) the pickler will see them as being
       the same object and create a reference. If you need to return a 'dummy'
       object (i.e. all your real data is in the metadata/coredata/propmap) then
       I suggest returning something like '%x' % id(x) so it will be unique.
"""
__author__ = ["Frank McIngvale (frankm@hiwaay.net)"]

from gnosis.xml.pickle.api import XMLPickleOtherError, XMLPicklingError, \
     XMLUnpicklingError
import re
from types import *

class XMLPickleBaseExtension:
    """
    Base class for extensions.
    """
    def __init__(self, name):
        self.extension_name = name
    
    def get_extension_name(self):
        return self.extension_name
        
class StackableExtension(XMLPickleBaseExtension):
    """
    Base class for 'stackable' xml.pickle extensions.

    Stackable extensions use a simple 'object-in, object-out' model.
    They are not allowed to contain self-referencing data, and so are
    most appropriate for 'atomic' types. Multiple stackable extensions
    may operate on any given object, hence they can chain together as
    a pipeline.

    Stackable extensions are added to the XML stream as <attr name='*EXT_NAME' ..>
    attributes.
    """
    def __init__(self, name):
        XMLPickleBaseExtension.__init__(self, name)
        
    def ignore(self, obj):
        """
        If extension doesn't want to handle a particular object
        (in pickle()), it should do:

             return self.ignore(obj)

        Where 'obj' is the object passed to pickle().

        [In general, this approach should lead to simpler code than
        having a separate function to say 'I want to handle the object'.
        With ignore(), you can do all your handling in pickle(), falling
        through to a final 'self.ignore()' if you don't want to handle
        an object.]
        """
        # return a datalist that the extension manager recognizes
        # as meaning "I didn't do anything"
        return (obj, None, {})
    
    def pickle(self, obj):
        """
        During pickling, objects are passed here to let the 
        extension handle them, if desired. If the extension does
        not want to handle the object, it should do:
            
             return self.ignore(obj)

        Else, the extension should convert it to whatever form it
        chooses and return:
            (obj_out, coredata, propmap)

        Where:
            obj_out = The converted object.
            
            coredata = Additional 'core' data the extension wants
                       to attach. Can be: str(), unicode(), {}, [], or None.
                       (*Exact* types only, no subclasses.)

            propmap = A 'property map' (dict) the extension wants to
                      attach to the converted object. It is a dict
                      of zero or more (key,value) pairs. Each key must
                      satisfy the regex '^[\x20-\x7e]*$' (because the propmap
                      is stored in an <attr> list instead of an <entry> list).
        NOTES:
            1. As noted above, the extension *must not* alter the
               original object passed to pickle().

            2. Stackable extensions are *not* allowed to return mutated
               versions of self-referencing objects. The pickler will raise
               an exception if you try to do this. If you need to write an
               extension that modifies self-referencing objects, use a
               ClassExtension instead.

               Note the following *is* legal, since you aren't modifying
               the self-referencing object, just attaching coredata and/or
               a property map:

                     pickle( self_ref_obj ):
                        return (self_ref_obj, ..something.., ..something..)
        """
        raise XMLPicklingError("Extension object must define pickle()")

    def unpickle(self, obj, coredata, propmap):
        """
        Take the output of pickle() and recreate the original object.
        Inputs:
           obj = The 'obj_out' that pickle() returned.
           coredata = The coredata that pickle() returned.
           propmap = The property map that pickle() returned.

        Returns:
           The original object.
        """
        raise XMLUnpicklingError("Extension object must define unpickle()")
    
class ClassExtension(XMLPickleBaseExtension):
    """
    Base class for xml.pickle 'class extensions'.

    ClassExtensions have the most complex API, but are the only
    extensions that are able to handle self-referencing data.
    Unlike stackable extensions, only one ClassExtension may operate
    on any given object.
    
    The 'Class' name derives from the fact that the extension is
    added to the XML stream via the class='*EXT_NAME' attribute (i.e.
    they are in the top tag for an object, instead of a subitem like
    stackable extensions). Because of this, if a ClassExtension mutates
    its data to a non-exact type (i.e. where a class= tag would normally
    be used), it must remember the real class itself, via its metadata.

    The API that a ClassExtension must implement depends on the type
    of object that it mutates to. There are three basic kinds of objects
    to mutate to: Those with mutable coredata (e.g. a list), those with
    immutable coredata (e.g. a tuple), and those with no coredata (e.g. None,
    or a regular user-defined instance). Here is the API that must be
    implemented in each case:

    If immutable core, the extension must implement:
        pickle( .. )
        unpickle_begin_core( .. )
        unpickle_finalize( .. )

    If mutable core, the extension must implement:
        pickle( .. )
        unpickle_begin_nocore( .. )
        unpickle_set_coredata( .. )
        unpickle_finalize( .. )

    If no coredata, the extension must implement:
        pickle( .. )
        unpickle_begin_nocore( .. )
        unpickle_finalize( .. )

        [i.e. the same as the mutable case, without a 'set_coredata' step.]

    An exception will be raised if you implement the wrong API.
    
    The ClassExtension is free to decide what form to mutate to. There is no restriction
    on mutating to a single type - e.g. given three objects A,B,C, pickle() can mutate 
    to a tuple for object 'A', a list for 'B', a dict for 'C', etc.
    """
    def __init__(self, name):
        XMLPickleBaseExtension.__init__(self, name)
        
    def ignore(self, obj):
        """
        If extension doesn't want to handle a particular object
        (in pickle()), it should do:

             return self.ignore(obj)

        Where 'obj' is the object passed to pickle().
        """
        # return a datalist that the extension manager recognizes
        # as meaning "I didn't do anything"
        return (obj, {}, {})
    
    def pickle(self, obj):
        """
        During pickling, objects are passed here to let the
        extension handle them, if desired. If the extension does
        not want to handle the object, it should do:
            
             return self.ignore(obj)

        Else, the extension should convert it to whatever form it
        chooses and return:
            (obj_out, metadata, propmap)

        Where:
            obj_out = The converted object. If obj_out is not an *exact* type, 
                      the extension must remember the real class itself via metadata so
                      that it can recreate it later.
                      
            metadata = A dict of data the extension needs to recreate the
                       bare object (i.e. without coredata or attributes).
                       Each dict key must match the regex '^[\x20-\x7e]+$'.
                       val is any arbitrary object, subject to the restriction
                       that it CANNOT reference 'obj'. (pickler will raise an
                       exception if you try to reference 'obj' in the metadata)

                       'metadata' should only include the bare information
                       needed to recreate the empty object, not any coredata/attributes.
                       
            propmap = A 'property map' (dict) the extension wants to
                      attach to the converted object. It is a dict holding
                      zero or more (key,value) pairs. Each key must satisfy
                      the regex '^[\x20-\x7e]*$' (because the propmap is stored
                      in an <attr> list instead of an <entry> list).

        NOTES:
            1. As noted above, the extension *must not* alter the original object!
        """
        raise XMLPicklingError("Extension object must define pickle()")

    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        """
        If this extension mutates its object to a type with mutable coredata
        (or a type that doesn't use coredata), then this will be called immediately
        after the unpickler parses the opening element.

        This function must create and return a new empty object
        of the proper (i.e. final) type. After the unpickler has
        collected the coredata, it will call unpickle_set_coredata().

        Inputs:
           typestr: The 'type=' string from the XML tag.
           metadata: The metadata that pickle() returned.
           class_search, allow_replicants: The same as in load()
        """
        raise XMLUnpicklingError("Extension object must define unpickle_begin_nocore()")

    def unpickle_set_coredata(self, typestr, obj, coredata):
        """
        If this extension mutates its object to a type with mutable coredata,
        then this will be called after the unpickler has collected
        the coredata from the XML stream. 'typestr' is the 'type=' attribute
        from the XML tag. 'obj' is the object that was previously returned from 
        unpickle_begin_core(). 'coredata' is the coredata that pickle() returned 
        during pickling.

        This function must set the coredata into 'obj'. There is no return value.
        """
        raise XMLUnpicklingError("Extension object must define unpickle_set_coredata()")
    
    def unpickle_begin_core(self, typestr, metadata, coredata,
                            class_search, allow_replicants):
        """
        If this extension mutates its object to a type with immutable coredata,
        then the unpickler first collects the coredata, then passes it here.

        This function must create a new object of the proper (i.e. final) type,
        setting its coredata, and returning the new object.

        Inputs:
           typestr: The 'type=' string from the XML tag.
           metadata: The metadata that pickle() returned.
           coredata: The coredata that is to be placed in the new object.
           class_search, allow_replicants: The same as in load()
        """
        raise XMLUnpicklingError("Extension object must define unpickle_begin_core()")

    def unpickle_finalize(self, obj, propmap):
        """
        Take the propmap returned by pickle() and finalize 'obj'.
        This is the final step: 'obj' will already have its coredata
        set (from above), and all attributes will have been set.

        This function *must* modify 'obj' itself. There is no return value.
        """
        raise XMLUnpicklingError("Extension object must define unpickle_finalize()")

class LoadOnlyExtension(XMLPickleBaseExtension):
    """
    Base class for a 'load-only' xml.pickle.extension.

    A 'load-only' extension is inserted into the unpickling
    chain and is called once for *every* unpickled object.
    """
    def __init__(self):
        # LoadOnlyExtensions don't have a name
        XMLPickleBaseExtension.__init__(self, None)
        
    def loader(self, obj):
        """
        If extension doesn't want to handle obj, it should
        return obj untouched. Else, return the modified obj.
        """
        raise XMLUnpicklingError("Load-only Extension object must define loader()")
    
# StackableExtensions are added to the head of this list,
# i.e. they are called before older entries.
STACKABLE_EXTENSION_LIST = []

# Mapping of extension name->StackableExtension object.
NAME_TO_STACKABLE_EXTENSION = {}

# ClassExtensions are added to the head of this list,
# i.e. newer additions called first
CLASS_EXTENSION_LIST = []

# Mapping of extension name->ClassExtension object.
NAME_TO_CLASS_EXTENSION = {}

# "load-only" extensions are added to the tail of this list,
# i.e. they are called after older entries
LOAD_ONLY_LIST = []

# thread sanity for the above globals
from threading import Lock
Extensions_Lock = Lock()

def register_extension(extension):
    """
    Register an xml.pickle extension.

    Inputs:
       extension: XMLPickleBaseExtension-subclass instance.
    """
    Extensions_Lock.acquire()
    try:
        _register_extension(extension)
        Extensions_Lock.release()				
    except:
        Extensions_Lock.release()		
        raise # re-raise initial exception

def _register_extension(extension):
    
    global STACKABLE_EXTENSION_LIST, NAME_TO_STACKABLE_EXTENSION, \
           CLASS_EXTENSION_LIST, NAME_TO_CLASS_EXTENSION, \
           LOAD_ONLY_LIST

    name = extension.get_extension_name()
    
    if isinstance(extension, StackableExtension):
        #from objmodel import re_safe_attr_ASCII
        from objmodel import is_safe_attr_ASCII

        # name goes into <attr name=>, so has to be safe_attr_ASCII
        #if not re_safe_attr_ASCII.match(name):
        if not is_safe_attr_ASCII(name):
            raise XMLPickleOtherError("StackableExtension names must be safe_attr_ASCII (see DESIGN) (name=%s)" % name)
        
        if NAME_TO_STACKABLE_EXTENSION.has_key(name):
            raise XMLPickleOtherError("A StackableExtension named '%s' is already registered." % name)

        STACKABLE_EXTENSION_LIST.insert( 0, extension )
        NAME_TO_STACKABLE_EXTENSION[name] = extension

    elif isinstance(extension, ClassExtension):
        # must be a legal classname, so no escaping will be required
        from gnosis.xml.pickle.tagger import re_valid_classtag
        
        if not re_valid_classtag.match(name):
            raise XMLPickleOtherError("ClassExtensions names must be legal Python names (name=%s)" % name)
        
        if NAME_TO_CLASS_EXTENSION.has_key(name):
            raise XMLPickleOtherError("A ClassExtension named '%s' is already registered." % name)

        CLASS_EXTENSION_LIST.insert( 0, extension )
        NAME_TO_CLASS_EXTENSION[name] = extension

    elif isinstance(extension, LoadOnlyExtension):
        LOAD_ONLY_LIST.append( extension )

    else:
        raise XMLPickleOtherError("Unknown Extension object passed.")

def unregister_extension(extension):
    """
    Unregister a previously registered xml.pickle extension.

    Inputs:
       extension: The *same* extension object passed to register_extension
                  (requiring the same object provides a little safety against
                  accidentally unregistering extensions, plus simplifies the
                  implementation).
    """
    Extensions_Lock.acquire()
    try:
        _unregister_extension(extension)
        Extensions_Lock.release()				
    except:
        Extensions_Lock.release()		
        raise # re-raise initial exception
    
def _unregister_extension(extension):
    
    global STACKABLE_EXTENSION_LIST, NAME_TO_STACKABLE_EXTENSION, \
           CLASS_EXTENSION_LIST, NAME_TO_CLASS_EXTENSION, \
           LOAD_ONLY_LIST

    name = extension.get_extension_name()
    
    if isinstance(extension, StackableExtension):
        if not NAME_TO_STACKABLE_EXTENSION.has_key(name):
            raise XMLPickleOtherError("Trying to unregister nonexistant StackableExtension '%s'." % name)

        try:
            i = STACKABLE_EXTENSION_LIST.index( extension )
        except ValueError:
            raise XMLPickleOtherError("Trying to unregister nonexistant StackableExtension '%s' (passed the wrong extension instance object?)." % name)

        del STACKABLE_EXTENSION_LIST[i]
        del NAME_TO_STACKABLE_EXTENSION[name]

    elif isinstance(extension, ClassExtension):
        if not NAME_TO_CLASS_EXTENSION.has_key(name):
            raise XMLPickleOtherError("Trying to unregister nonexistant ClassExtension '%s'." % name)

        try:
            i = CLASS_EXTENSION_LIST.index( extension )
        except ValueError:
            raise XMLPickleOtherError("Trying to unregister nonexistant ClassExtension '%s' (passed the wrong extension instance object?)." % name)
        
        del CLASS_EXTENSION_LIST[i]
        del NAME_TO_CLASS_EXTENSION[name]

    elif isinstance(extension, LoadOnlyExtension):
        try:
            i = LOAD_ONLY_LIST.index( extension )
        except ValueError:
            raise XMLPickleOtherError("Trying to unregister nonexistant LoadOnlyExtension '%s' (passed the wrong extension instance object?)" % str(extension))
        
        del LOAD_ONLY_LIST[i]

    else:
        raise XMLPickleOtherError("Unknown Extension object passed.")	

def lookup_classext(name, extra_extensions):
    """
    Lookup a ClassExtension, which should exist.
    Only hold lock long enough to do lookup.
    """
    extra_extensions = extra_extensions or []
    
    # look in extra_extensions before registered extensions
    for ext in extra_extensions:
        if ext.get_extension_name() == name:
            return ext

    Extensions_Lock.acquire()	
                
    # now check registered extensions
    try:
        ext = NAME_TO_CLASS_EXTENSION[name]
        Extensions_Lock.release()
        return ext
    except:
        Extensions_Lock.release()
        raise # re-raise initial exception

def lookup_stackable(name, extra_extensions):
    """
    Lookup a StackableExtension, which should exist.
    Only hold lock long enough to do lookup.
    """
    extra_extensions = extra_extensions or []

    # look in extra_extensions before registered extensions
    for ext in extra_extensions:
        if ext.get_extension_name() == name:
            return ext

    Extensions_Lock.acquire()			

    # now check registered extensions
    try:
        ext = NAME_TO_STACKABLE_EXTENSION[name]
        Extensions_Lock.release()
        return ext
    except:
        Extensions_Lock.release()
        raise # re-raise initial exception	
    
def run_classext_begin_core(name, typestr, metadata, coredata,
                            class_search, allow_replicants, extra_extensions):
    """
    If a ClassExtension mutated to a type with an immutable core,
    this will be called to have the extension create the object
    with its coredata.
    
    Inputs:
       name: The name the extension is registered under.
       typestr: The 'type=' string from the XML tag.
       metadata: The metadata that pickle() returned.
       coredata: The coredata for the object.
       class_search, allow_replicants: The same as in load()
    """
    ext = lookup_classext(name, extra_extensions)	
    obj = ext.unpickle_begin_core(typestr, metadata, coredata,
                                  class_search, allow_replicants)
    return obj
    
def run_classext_begin_nocore(name, typestr, metadata,
                              class_search, allow_replicants, extra_extensions):
    """
    If a ClassExtension mutated to a type with a mutable core,
    this will be called to have the extension create the empty
    object.
    
    Inputs:
       name: The name the extension is registered under.
       typestr: The 'type=' string from the XML tag.
       metadata: The metadata that pickle() returned.
       class_search, allow_replicants: The same as in load()	
    """
    ext = lookup_classext(name, extra_extensions)
    obj = ext.unpickle_begin_nocore(typestr, metadata,
                                    class_search, allow_replicants)
    return obj

def run_classext_set_coredata(name, typestr, obj, coredata, extra_extensions):
    """
    If a ClassExtension mutated to a type with a mutable core,
    this will be called to have the extension insert the
    coredata into 'obj'.

    No return value (obj is modified).
    """
    ext = lookup_classext(name, extra_extensions)	
    ext.unpickle_set_coredata(typestr, obj, coredata)

def run_unpickle_extensions( obj, stackable_datalist, classext_datalist, extra_extensions=None ):
    """
    Takes the objects returned from run_pickle_extensions() and returns
    the original object.

    extra_extensions = Any extra LoadOnlyExtensions the caller wants to run.
                       Will run AFTER any registered extensions.

                       Can be NO_EXTENSIONS, in which case no extension are run
                       (will NOT raise an error, will just return raw data).
                       
    NOTE: For ClassExtensions, this only performs the finalization step.
    The initial creation is handled by the run_classext_* functions.
    """
    global LOAD_ONLY_LIST

    if extra_extensions == NO_EXTENSIONS:
        return obj
        
    extra_stackable, extra_classext, extra_loadonly = split_extra_extensions(extra_extensions or [])
    
    # run ClassExtension first, if applicable
    if classext_datalist != None:
        # only finalize() here; object created already with earlier
        # run_classext_* steps
        name, metadata, propmap = classext_datalist
        ext = lookup_classext(name, extra_classext)
        ext.unpickle_finalize(obj, propmap)

    # now run StackableExtensions

    # need to call in reverse order
    stackable_datalist.reverse()

    for name, coredata, propmap in stackable_datalist:
        ext = lookup_stackable(name, extra_stackable)
        obj = ext.unpickle(obj, coredata, propmap)

    # in case caller cares ...
    stackable_datalist.reverse()

    # finally run any LoadOnlyExtensions
    Extensions_Lock.acquire()
    load_exts = LOAD_ONLY_LIST + extra_loadonly
    try:
        for ext in load_exts:
            obj = ext.loader(obj)
    except:
        # an error occurred in a loader - release lock first
        Extensions_Lock.release()
        # re-raise error for caller to see
        raise
        
    Extensions_Lock.release()
    
    return obj

def test_attr_dict_legality( d, msg1, msg2 ):
    """
    Check that a dict d is legal as either metadata or a propmap.
    """
    #from objmodel import re_safe_attr_ASCII
    from objmodel import is_safe_attr_ASCII
    
    if type(d) is not DictType:
        raise XMLPicklingError(msg1)
        
    for key in d.keys():
        # tagger will still escape the key, but I have to make sure
        # it is a legal attr name
        #if not re_safe_attr_ASCII.match(key):
        if not is_safe_attr_ASCII(key):
            raise XMLPicklingError(msg2 % key)

def _get_nr_extensions():
    "Returns the number of extensions currently registered."
    global STACKABLE_EXTENSION_LIST, CLASS_EXTENSION_LIST

    Extensions_Lock.acquire()
    nr = len(STACKABLE_EXTENSION_LIST)+len(CLASS_EXTENSION_LIST)
    Extensions_Lock.release()
    
    return nr

def split_extra_extensions(extra_extensions):
    """
    Splt extra extensions into stackable, classext and loadonly lists.
    Returns:
        (extra_stackable, extra_classext, extra_loadonly)
    """
    extra_stackable = []
    extra_classext = []
    extra_loadonly = []
    
    for ext in extra_extensions:
        if isinstance(ext, ClassExtension):
            extra_classext.append( ext )
        elif isinstance(ext, StackableExtension):
            extra_stackable.append( ext )
        elif isinstance(ext, LoadOnlyExtension):
            extra_loadonly.append( ext )
        else:
            raise XMLPicklingError("Bad extension - expecting (extension,name), but got: %s" % repr((ext,name)))
    
    return (extra_stackable, extra_classext, extra_loadonly)
    
from types import *
    
# special value you can pass to run_pickle_extensions to say "run NO extensions",
# even those already registered
NO_EXTENSIONS = 1

def run_pickle_extensions( obj, extensions=None, ext_basictypes=0 ):
    """
    Called during pickling. Takes obj, runs it through all
    applicable extensions, and return the results as:

        (final_obj, stackable_modified, stackable_datalist, classext_datalist)

    Where:
       final_obj = final converted object, ready for pickling

       stackable_modified:
           Did a StackableExtension *modify* the object? (Merely
           attaching coredata/propmap doesn't count as modifying it.)
           
       stackable_datalist:
           A list of data returned from any StackableExtensions
           that touched the object. It is a list of tuples:

             (name, coredata, propmap)

             Giving the name and return values for each
             StackableExtension that modified obj. List will be
             in the order in which extensions were called, first-called
             at the head of the list.

           Will be [] if no StackableExtensions handled obj.
           
       classext_datalist:
           If a ClassExtension handled the object, then this will
           be a tuple:

 			 (name, metadata, propmap)

             Giving the name and return values from the ClassExtension
             that handled it (only one ClassExtension can handle an
             object.)

           Will be None if no ClassExtensions handled obj.

    A return value of (final_obj, 0, [], None) means that no extensions
    handled the object.

    You can pass a list of extra extensions to run. They are run
    before any registered extensions.
    
    'ext_basetypes' is a flag specifying whether to pass basic types
    (int, float, dict, etc.) to extensions or not. By default it is off
    since this slows pickling down quite a bit and it likely only needed
    for specialized apps.
    """		
    from copy import copy	
    if ext_basictypes==0 and type(obj) in (BooleanType, DictType, FloatType, IntType, ListType, \
                LongType, NoneType, StringType, TupleType, UnicodeType):
        return (obj, 0, [], None)
        
    if extensions == NO_EXTENSIONS:
        return (obj, 0, [], None)
        
    global STACKABLE_EXTENSION_LIST, CLASS_EXTENSION_LIST

    # sort extra extensions into stackable & classext lists
    #extra_stackable = []
    #extra_classext = []
    #for ext in (extensions or []):
    #	if isinstance(ext, ClassExtension):
    #		extra_classext.append( ext )
    #	elif isinstance(ext, StackableExtension):
    #		extra_stackable.append( ext )
    #	else:
    #		raise XMLPicklingError("Bad extension - expecting (extension,name), but got: %s" % repr((ext,name)))
    
    extra_stackable, extra_classext, extra_loadonly = split_extra_extensions(extensions or [])
    
    stackable_datalist = []
    classext_datalist = None

    # have to remember if a StackableExtension changed the object
    # (see ExtensionManager for details on why)
    id0 = id(obj)
    
    # Run StackableExtensions first (see DESIGN for why)
    Extensions_Lock.acquire()
    # this is fast and avoids any chance of the list being modified while
    # the loop is running
    extlist = extra_stackable + copy(STACKABLE_EXTENSION_LIST)
    Extensions_Lock.release()
    
    for ext in extlist:
        mobj, coredata, propmap = ext.pickle(obj)

        # tagger sanitizes coredata, since it might want to wrap in UElement
        
        # test legality of propmap
        test_attr_dict_legality(propmap,
                                "StackableExtension propmap must be a dict (%s returned %s)" % \
                                (str(ext),str(propmap)),
                                "StackableExtension returned bad key %s in propmap.")
        
        # only add to datalist if extension did something
        if (id(mobj) != id(obj)) or (coredata != None) or \
           len(propmap):
            stackable_datalist.append( (ext.get_extension_name(), coredata, propmap) )
            obj = mobj
                
    stackable_modified = (id(obj) != id0)
    
    # Run any applicable ClassExtension
    Extensions_Lock.acquire()
    extlist = extra_classext + copy(CLASS_EXTENSION_LIST)
    Extensions_Lock.release()
    
    for ext in extlist:
        from objmodel import base_atoms, base_containers

        # pass object to extension for (possible) handling
        mobj, metadata, propmap = ext.pickle(obj)

        # legality check of metadata (see above)
        test_attr_dict_legality(metadata,
                                "ClassExtension metadata must be a dict (%s returned %s)" % \
                                (str(ext),str(metadata)),
                                "ClassExtension returned bad key %s in metadata.")

        # test legality of propmap
        test_attr_dict_legality(propmap,
                                "ClassExtension propmap must be a dict (%s returned %s)" % \
                                (str(ext),str(propmap)),
                                "ClassExtension returned bad key %s in propmap.")
        
        # did extension do anything? if so, we're done (only once ClassExtension
        # can handle an object)
        if id(mobj) != id(obj) or len(metadata) or len(propmap):
            obj = mobj
            classext_datalist = (ext.get_extension_name(), metadata, propmap)
            break

    # ignore any LoadOnlyExtensions during pickling (user may have included them
    # in the list for convenience)
    
    return (obj, stackable_modified, stackable_datalist, classext_datalist)

class ExtensionManager:
    """
    Each XMLPickleTagger will have an instance of this. It handles
    the details of self-references for extension modules.
    """	
    def __init__(self):
        # Map objects -> run_pickle_extensions() return values.
        # This is needed so that multiple identical objects going through
        # extensions will maintain their referential integrity.
        self.mutated_map = {}

        # Whenever a StackableExtension module mutates an object,
        # the *original* object is placed in obj_norecurse until all
        # tags for the mutated object are written. This is done
        # in order to catch StackableExtensions that try to mutate
        # self-referencing objects (not allowed per API, see DESIGN).
        # [If this is not caught during pickling, it would lead to silent
        # errors during unpickling, since refs to the *mutated* object
        # would be placed in the object, which be wrong after the
        # extension unmutates the object.]
        self.obj_norecurse = {}

        # Like above, but makes sure that ClassExtensions don't return
        # metadata that references the original object. Unlike above, this *would*
        # cause an error during unpickling, since the referenced obj
        # wouldn't exist until after (at least) all <meta> tags were read,
        # but it is better to catch it during pickling and tell the user
        # what happened.
        self.meta_norecurse = {}

    def close_meta_tags(self, obj):
        """
        Tagger lets me know when it has finished writing all
        of the <meta> tags for the given object (obj is the original
        object, not the one that run_pickle_extensions() returned)
        [Tagger calls this even if NO <meta> tags were written.]
        """
        if self.meta_norecurse.has_key(id(obj)):
            del self.meta_norecurse[id(obj)]
        
    def close_object_tag(self, obj):
        """
        Tagger lets me know when it has finished writing all of the tags
        for the given object (obj is the original object, not the one
        that run_pickle_extensions() returned)
        """
        if self.obj_norecurse.has_key(id(obj)):
            del self.obj_norecurse[id(obj)]

    def run_pickle_extensions(self, obj, extensions=None, ext_basictypes=0):
        """
        Run all applicable extensions on 'obj' and return:
        
            (final_obj, stackable_datalist, classext_datalist)

        Where:
           final_obj = final converted object, ready for pickling

           stackable_datalist:
               A list of data returned from any StackableExtensions
               that touched the object. It is a list of tuples:

                 (name, coredata, propmap)

                 Giving the name and return values for each
                 StackableExtension that modified obj. List will be
                 in the order in which extensions were called, first-called
                 at the head of the list.

               Will be [] if no StackableExtensions handled obj.

           classext_datalist:
               If a ClassExtension handled the object, then this will
               be a tuple:

                 (name, metadata, propmap)

                 Giving the name and return values from the ClassExtension
                 that handled it (only one ClassExtension can handle an
                 object.)

               Will be None if no ClassExtensions handled obj.

        A return value of (final_obj, [], None) means that no extensions
        handled the object.
        
        You can pass a list of extra extensions to run. They are run
        before any registered extensions.
        
        'ext_basictypes' is a flag specifying whether to pass basic types
        (int, float, dict, etc.) to extensions or not. By default it is off
        since this slows pickling down quite a bit and it likely only needed
        for specialized apps.
        """
        # see if obj is in the meta-norecurse map
        if self.meta_norecurse.has_key(id(obj)):
            # unable to maintain referential integrity
            raise XMLPicklingError("ClassExtension metadata may not reference the original object. See DESIGN. (Extension module trace: obj=%s, stack='%s', allstack='%s')" % \
                                   (str(self.meta_norecurse[id(obj)][0]),
                                    str(self.meta_norecurse[id(obj)][1]),
                                    str(self.meta_norecurse)))

        # see if obj is in the 'no-recurse' map
        if self.obj_norecurse.has_key(id(obj)):
            # unable to maintain referential integrity
            raise XMLPicklingError("StackableExtensions may not modify self-referencing objects. See DESIGN. (Extension module trace: obj=%s, stack='%s')" % \
                                   (str(self.obj_norecurse[id(obj)][0]),
                                    str(self.obj_norecurse[id(obj)][1])))

        # have I seen this object before?
        if self.mutated_map.has_key(id(obj)):
            # retrieve previous return values from run_pickle_extensions()
            obj, stackable_datalist, classext_datalist = \
                 self.mutated_map[id(obj)]

            # no need to store/retrieve 'stackable_modified' - it is only
            # needed below. code above would have caught illegal usage, so
            # making it here means I'm OK
        else:
            # see if any extension modules want to mutate obj
            mobj, stackable_modified, stackable_datalist, classext_datalist = \
                  run_pickle_extensions(obj, extensions, ext_basictypes)

            # did anything modify it or attach data?
            if id(obj) != id(mobj) or len(stackable_datalist) or \
                   classext_datalist != None:

                if classext_datalist != None:
                    # watch for self-referencing metadata from ClassExtension
                    self.meta_norecurse[id(obj)] = (obj, classext_datalist)		

                # did a stackable modify it?
                if stackable_modified:
                    # keep obj alive so id won't be reused
                    self.obj_norecurse[id(obj)] = (obj, stackable_datalist)

                # save return values (no need to save 'stackable_modified',
                # it is only needed in above check)				
                self.mutated_map[id(obj)] = (mobj, stackable_datalist,
                                             classext_datalist)
                
                # set obj to mutated version
                obj = mobj

        return (obj, stackable_datalist, classext_datalist)
    
    
