#-------------------------------------------------------------------
# xmlcoder.py
#
# frankm@hiwaay.net
#
# Idea:
#    This module provides a set of encoders/decoders for
#    preparing data to be put into an XML stream.
#
#    This can be used to prepare three types of data:
#
#       * strings (arbitrary Python bytestrings)
#         [*Exact* strings, no subclasses!]
#
#       * unicode objects that might contain unsafe values
#         [*Exact* unicode objects, no subclasses!]
#
#       * objects that need to be cPickled first (you pass the
#         object, and the codec does the pickling for you)
#         [Anything that is not *exactly* a string/unicode 
#          will be cPickled]
#
# API:
#    The encoders take string/unicode/"cPickleable"
#    values and return safe unicode objects.
#
#    The decoders will take the safe unicode objects and
#    return the original values.
#
#    Unicode is passed since that is the native type you'll
#    get back from an XML parser. Also, passing Unicode prevents
#    the caller from being locked into a specific encoding type.
#
# Usage Notes:
#    It is up to external code to decide which codec is
#    appropriate for a given object.
#
#    "string/plain" is *ONLY* for strings that match the
#    regexp: "^[\0x09\0xa0\0x0d\0x20-\0x7e]*$"
#
#    "unicode/plain" is *ONLY* for unicode strings where
#    gnosis.xml.xmlmap.is_legal_xml() is true.
#
#    If you don't pass the tests to use 'plain', you can use any
#    other codec matching the data type (string/unicode/pickle)
#    and get a correct result. The only difference is that some
#    codecs are more appropriate for large blocks of data vs.
#    small blocks. It's just a matter of preference/readability.
#
#    You can use encode() as a helper function to choose the
#    proper codec.
#
#    It is up to the caller to encode the returned value into
#    a bytestream, and to call xml.sax.saxutils.escape/quoteattr,
#    depending on whether the value is going to be XML content or
#    an attribute. 
#
# Codecs:
#   (Codec naming follows the pattern: "input-type/processing-pipeline")
#   NOTE: Codec names must be safe to put in XML without escaping
#         (assumption is made in pickle.tagger)
#
#   string:
#      String matching regex "^[\0x09\0x0a\0x0d\0x20-\0x7e]*$", no compression 
#           "string/plain"
#
#      Small amounts of binary, no compression.
#           "string/url"
#
#      Large amounts of binary, no compression.
#           "string/base64"
#
#      Large amounts of binary, with zlib compression.
#           "string/z-base64"
#
#   unicode:
#      Passes is_legal_xml() test, no compression.
#           "unicode/plain"
#
#      Small amounts of non-legal values, no compression.
#           "unicode/utf8-url"
#
#      Optimized (in terms of size/readability), but slower,
#      coding for small amounts of non-legal values, no compression:
#           "unicode/xml-escape"
#
#      Large amounts of non-legal values, no compression.
#           "unicode/utf8-base64"
#
#      Large amounts of non-legal values, with zlib compression.
#           "unicode/utf8-z-base64"
#
#   types that require (Python) pickling:
#      cPickle object, no compression.
#           "pickle/c-base64"
#
#      cPickle object, with zlib compression.
#           "pickle/c-z-base64"
#
#----------------------------------------------------------------------
# This module is really part of xml.pickle, but can also be generally
# useful for XML work, so is placed here.
#----------------------------------------------------------------------

# public interface
__all__ = ['encode','encode_as','decode_as']

class XMLCoderError(Exception):
    def __init__(self,msg):
        Exception.__init__(self,msg)
        
try:
    import zlib
    HAVE_ZLIB = 1
except:
    HAVE_ZLIB = 0
    
import cPickle, urllib
from gnosis.xml.xmlmap import *
from types import *
import binascii

def encode( obj, binary, compress, fast=1 ):
    """
    Helper layer on encode_as(). You tell it the characteristics
    of your object, and it picks the best encoder.

    Inputs:
       obj: Object to be encoded.
       
       binary: How much "bad" data does object hold?
               (ie. values that aren't allowed to be placed
               in an XML file)
            0: None
            1: A little (and/or small data block).
            2: A lot (and/or large data block).
            
       compress: Should encoder try to compress object data?

       fast:
          If 1, will choose a faster, but larger, coding, if available.
          If 0, will choose a smaller, but slower, coding, if available.

    Note:
       For strings:
          If string doesn't match ^[\x09\x0a\x0d\0x20-\0x7e]*$ you must
          pass binary >= 1, else you'll get a bad encoding.

       For Unicode:
          If is_legal_xml() is NOT true for the unicode value,
          you must pass binary >= 1, else you'll get a bad encoding.

       For others (picklable objects):
          binary flag is ignore (always uses a binary encoding)
          
       Note that binary >= 1 will ALWAYS succeed, but binary=2 is
       better for large blocks of data.

    Returns (encoded_value, encoder_string), which you can pass
    to decode_as() to retrieve the original value.
    """

    if is_string_exactly(obj):
        if binary == 0 and compress == 0:
            coding = 'string/plain'
        elif binary == 1 and compress == 0:
            coding = 'string/url'
        elif binary == 2 and compress == 0:
            coding = 'string/base64'
        else:
            coding = 'string/z-base64'
        
    elif is_unicode_exactly(obj):
        if binary == 0 and compress == 0:
            coding = 'unicode/plain'
        elif binary == 1 and compress == 0:
            if fast:
                coding = 'unicode/utf8-url'
            else:
                # better (size), but slower
                coding = 'unicode/xml-escape'
        elif binary == 2 and compress == 0:
            coding = 'unicode/utf8-base64'
        else:
            coding = 'unicode/utf8-z-base64'
            
    else: 		# anything other than string/unicode gets cPickled
        if compress:
            coding = 'pickle/c-z-base64'
        else:
            coding = 'pickle/c-base64'

    return (encode_as(obj, coding), coding)

def encode_as( obj, encoding ):
    """
    Encode object using the given encoding.

    Inputs:
        obj: A string, unicode object, or (C)pickleable object.
        encoding: One of the encoding types. It is up to the caller
                  to ensure the coding is appropriate for the object!

    Returns:
        Unicode object that is safe to place in an XML file.
    """
    if not CODECS.has_key(encoding):
        raise XMLCoderError("No such encoding '%s'" % encoding)
    
    return CODECS[encoding][0](obj)

def decode_as( ucoded, encoding ):
    """
    Decode unicode value returned from encode_as() and
    return the original value.

    Inputs:
        ucoded: Unicode object returned from encode_as().
        encoding: The encoding that was passed to encode_as().

    Returns:
        Decoded value.
    """
    if not CODECS.has_key(encoding):
        raise XMLCoderError("No such encoding '%s'" % encoding)
    
    return CODECS[encoding][1](ucoded)

#-------------------------------------------------------------------
# End of public interface
#-------------------------------------------------------------------

def enc_base64( s ):
    """
    Encode a bytestring to base64.
    
    Input: bytestring, any value
    Output: bytestring; base64 encoded version of input
    """
    # enforce normalized usage to avoid any weird bugs
    if not is_string_exactly(s):
        raise XMLCoderError("API error, a string (exactly) is required.")
    
    # Recent Pythons let you do 'string'.encode('base64'). Earlier versions
    # require you to use binascii.b2a_base64(). Since the coding must be
    # exactly the same between versions (to guarantee consistency of pickled
    # streams), it is done manually here.
        
    # have to split s into chunks of 57 bytes each for base64 encoder
    enc = ''
    while len(s):
        enc += binascii.b2a_base64(s[:57])
        s = s[57:]
        
    # don't need newline, remove (base64 contains no other spaces)
    return enc.rstrip()

def dec_base64( s ):
    """
    Decode output from enc_base64 back to bytestring.
    Input: Bytestring returned from enc_base64.
    Output: Python bytestring.
    """
    # enforce normalized usage to avoid any weird bugs
    if not is_string_exactly(s):
        raise XMLCoderError("API error, a string (exact) is required.")
    
    # Later Pythons can use s.decode(), but stick with binascii just
    # to make sure it is consistent between versions.
    return binascii.a2b_base64( s )	
    
def is_string_exactly( obj ):
    "Is object exactly a bytestring (no subclasses)?"
    
    try:
        # Python >= 2.2
        return obj.__class__ == str
    except AttributeError:
        # Python < 2.2, can't subclass string, so can
        # simply check type
        return (type(obj) is StringType)

def is_unicode_exactly( obj ):
    "Is obj exactly a unicode value (no subclasses)?"
    
    try:
        # Python 2.2+
        return obj.__class__ == unicode
    except AttributeError:
        # Python < 2.2, can't subclass unicode, so can
        # simply check type
        return (type(obj) is UnicodeType)	
    
#-----------------------------------------------------------
# Codec implementations.
#
# Note: These should NEVER be changed, except to fix
#       bugs. Any new features require a new codec.
#-----------------------------------------------------------

# name: "string/text"
# input: string
#
# purpose:
#   Transform a small string containing no binary.

def enc_string_plain( s ):
    return unicode(s,'ascii')

def dec_string_plain( ucoded ):
    return str(ucoded)

# name: "string/plain"
# input: string
#
# purpose:
#    Transform a string containing a small amount of binary.

def enc_string_url( s ):
    # normal URL encoding, except I allow spaces (for readability)	
    s = urllib.quote(s).replace('%20',' ')
    return unicode(s,'ascii')

def dec_string_url( ucoded ):
    return urllib.unquote( str(ucoded) )

# name: "string/base64"
# input: string
#
# purpose:
#    Transform string w/large amounts of binary
#    to base64.

def enc_string_base64( s ):
    b64 = enc_base64( s )
    return unicode(b64,'ascii')

def dec_string_base64( ucoded ):
    # all-ASCII unicode -> base64 bytestring
    s = str( ucoded )

    # base64 -> string
    return dec_base64( s )

# name: "string/z-base64"
# input: string
#
# purpose:
#    Transform string w/large amounts of binary
#    to base64, with zlib compression.

def enc_string_z_base64( s ):
    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to use string/z-base64")
    
    z = zlib.compress(s)
    b64 = enc_base64( z )
    return unicode(b64, 'ascii')

def dec_string_z_base64( ucoded ):
    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to decode string/z-base64")

    # all-ASCII unicode -> base64 bytestring
    s = str( ucoded )

    # base64 -> compressed binary
    z = dec_base64( s )

    # compressed -> string
    return zlib.decompress(z)

# name = "unicode/plain"
# input: unicode
#
# purpose:
#    Transform unicode w/no bad values.

def enc_unicode_plain( uval ):
    return uval

def dec_unicode_plain( ucoded ):
    return ucoded

# name = "unicode/utf8-url"
# input: unicode
#
# purpose:
#    Transform unicode w/small amount of "bad" values
#    using URL coding for readability

def enc_unicode_utf8_url( uval ):
    # unicode to binary (utf8)
    u8 = uval.encode('utf-8')

    # binary -> safe ASCII
    # (normal URL quoting, except I allow spaces for readability)
    s = urllib.quote(u8).replace('%20',' ')

    # safe ASCII -> unicode
    return unicode(s,'ascii')

def dec_unicode_utf8_url( ucoded ):
    # unicode -> safe ASCII
    s = str(ucoded)

    # ASCII -> binary (utf-8 coded)
    s = urllib.unquote(s)

    # utf-8 -> unicode
    return unicode( s, 'utf-8' )

# name = "unicode/xml-escape"
# input: unicode
#
# purpose:
#    Transform unicode w/small amount of "bad" values
#    using "optimal" (but slow) URL-type coding
#

def enc_unicode_xml_escape( uval ):

    # pseudo-URL encoding, but without converting to utf-8 first.
    # replaces non-XML legal chars with %HHHH (4-digit hex),
    # and replaces '%' with '%%'.
    
    u_out = u''
    
    for c in usplit(uval): # I need \U's as single chars!
        if not is_legal_xml_char(c):
            # do this first, since e.g. \ud900 *CAN BE* > \U0001000,
            # depending on how Python was compiled
            u_out += u'%%%04X' % ord(c)			
        elif c >= u'\U00010000':
            # 2-char sequences are always legal in XML
            u_out += c			
        elif c == u'%':
            u_out += u'%%'			
        else:
            u_out += c

    return u_out

def dec_unicode_xml_escape( ucoded ):

    u_out = u''

    i = 0
    while i < len(ucoded):
        if ucoded[i] == u'%': # '%%' or '%HHHH' hex
            if ucoded[i+1] == u'%': # '%%'
                u_out += u'%'
                i += 2
            else:
                u_out += unichr( int(ucoded[i+1:i+5],16) )
                i += 5
        else:
            u_out += ucoded[i]
            i += 1
        
    return u_out

# name = "unicode/utf8-base64"
# input: unicode
#
# purpose:
#    Transform unicode w/large amount of "bad" values to base64

def enc_unicode_utf8_base64( uval ):
    # unicode to binary (utf8)
    u8 = uval.encode('utf-8')

    # binary -> safe ASCII
    s = enc_base64( u8 )

    # safe ASCII -> unicode
    return unicode(s,'ascii')

def dec_unicode_utf8_base64( ucoded ):
    # ASCII unicode -> base64 bytestring
    s = str(ucoded)

    # base64 -> binary (utf-8 coded)
    s = dec_base64( s )

    # utf-8 -> unicode
    return unicode( s, 'utf-8' )

# name = "unicode/utf8-z-base64"
# input: unicode
#
# purpose:
#    Transform unicode w/large amount of "bad" values
#    to base64, compression with zlib as well.

def enc_unicode_utf8_z_base64( uval ):
    
    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to encode unicode/utf8-z-base64")
    
    # unicode to binary (utf8)
    u8 = uval.encode('utf-8')

    # compress to binary
    z = zlib.compress(u8)

    # compressed -> base64
    s = enc_base64( z )

    # safe ASCII -> unicode
    return unicode(s,'ascii')

def dec_unicode_utf8_z_base64( ucoded ):
    
    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to decode unicode/utf8-z-base64")
    
    # ASCII unicode -> base64 bytestring
    s = str(ucoded)

    # base64 -> binary (zlib)
    z = dec_base64( s )

    # zlib -> utf-8
    s = zlib.decompress(z)

    # utf-8 -> unicode
    return unicode( s, 'utf-8' )

# name = "pickle/c-base64"
# input: arbitrary object
#
# purpose:
#    Transform arbitrary object to base64 using cPickle
#

def enc_pickle_c_base64( obj ):
    # pickle -> binary
    p = cPickle.dumps( obj, 1 )

    # binary -> base64
    s = enc_base64( p )

    # base64 -> unicode
    return unicode( s,'ascii' )

def dec_pickle_c_base64( ucoded ):
    # ASCII unicode -> base64 bytestring
    s = str( ucoded )

    # base64 -> binary
    p = dec_base64( s )

    # unpickle
    return cPickle.loads( p )

# name = "pickle/c-z-base64"
# input: arbitrary object
#
# purpose:
#    Transform arbitrary object to base64 using compressed cPickle
#

def enc_pickle_c_z_base64( obj ):

    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to encode pickle/c-z-base64")
    
    # pickle -> binary
    p = cPickle.dumps( obj, 1 )

    # binary -> compressed
    z = zlib.compress( p )
    
    # compressed -> base64
    s = enc_base64( z )

    # base64 -> unicode
    return unicode( s,'ascii' )

def dec_pickle_c_z_base64( ucoded ):
    
    if not HAVE_ZLIB:
        raise XMLCoderError("Need a newer version of Python to decode pickle/c-z-base64")
    
    # ASCII unicode -> base64 bytestring
    s = str( ucoded )

    # base64 -> compressed
    z = dec_base64( s )

    # compressed -> pickled
    p = zlib.decompress( z )
    
    # unpickle
    return cPickle.loads( p )

#
# map coder name to (encoder, decoder) pairs
#
CODECS = {
    'string/plain': (enc_string_plain, dec_string_plain),
    'string/url' : (enc_string_url, dec_string_url),
    'string/base64': (enc_string_base64, dec_string_base64),
    'string/z-base64': (enc_string_z_base64, dec_string_z_base64),
    'unicode/plain': (enc_unicode_plain, dec_unicode_plain),
    'unicode/utf8-url': (enc_unicode_utf8_url, dec_unicode_utf8_url),
    'unicode/utf8-base64': (enc_unicode_utf8_base64,
                            dec_unicode_utf8_base64),
    'unicode/utf8-z-base64': (enc_unicode_utf8_z_base64,
                              dec_unicode_utf8_z_base64),
    'unicode/xml-escape': (enc_unicode_xml_escape, dec_unicode_xml_escape),
    'pickle/c-base64': (enc_pickle_c_base64, dec_pickle_c_base64),
    'pickle/c-z-base64': (enc_pickle_c_z_base64,
                          dec_pickle_c_z_base64)
    }
