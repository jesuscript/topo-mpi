from disthelper.treeops import TreeOps, TreeOptParser
import re

class RGrep(TreeOps):
    def __init__(self, grep_patt):
        TreeOps.__init__(self)
        self.re_grep = re.compile(grep_patt, re.I)
        
    def process_one_file(self, name, opts):
        buf = open(name, 'rb').read()
        if self.re_grep.search(buf):
            print "MATCHED",name
        
def find_files(path, grep_patt, extlist=[], exclude_patt=[]):
    """
    Recursively find files under 'path' that match 'grep_patt'.
    Inputs:
        path = Path to search
        grep_patt = regex (string) to match inside file
        extlist = List of file extensions to match (ie. ['py', 'c'])
        exclude_patt = Regexes to exclude in search.
    """
    args = ['rgrep', '-r']
    if len(extlist):
        args += ['--extension='+','.join(extlist)]
        
    if len(exclude_patt):
        args += ['--exclude-re='+','.join(exclude_patt)]
        
    args += [path]
    
    p = TreeOptParser('rgrep', 'rgrep')
    opts,args = p.parse_argv(args)
    
    t = RGrep(grep_patt)
    t.runtree(opts,args)
    
find_files('/home/frankm', 'tar_bz2_current_dir', ['py'], ['_darcs','disthelper'])

    
