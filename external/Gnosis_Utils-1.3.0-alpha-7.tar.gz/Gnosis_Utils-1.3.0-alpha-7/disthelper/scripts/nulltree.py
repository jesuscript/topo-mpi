
#
# A 'null' TreeOp, useful for testing basic speed.
#
# frankm@hiwaay.net
#

# make sure I can import disthelper
import sys
sys.path.insert(0,'.')
import grab_disthelper
    
# now the real code begins ...

from disthelper.treeops.treeops import *

class NullTreeOp(TreeOps):
    "A TreeOp that does nothing."
    
    def __init__(self):
        TreeOps.__init__(self)
        self.nr_files = 0
        
    def run(self, argv):
        # parse standard tree options (-r, -R, -x, etc.)
        p = TreeOptParser('nulltree.py','Null tree walker.')		
        opts,args = p.parse_argv(argv)

        if len(args) == 0:
            print "** Must give a directory to walk."
            p.show_usage()
            sys.exit(1)
            
        # remember which files/dirs we couldn't access
        self.nofile = []
        self.nodir = []

        # walk the tree with globbing, etc.
        self.runtree(opts,args)

        # tell user which files/dirs I couldn't access
        if len(self.nofile):
            print "I could not access these files:"
            for f in self.nofile:
                print "  %s" % f

        if len(self.nodir):
            print "I could not access these directories:"
            for d in self.nodir:
                print "  %s" % d
    
    # - internal API - called as the tree is walked -
    def process_one_file(self,fullname,opts):
        self.nr_files += 1
        pass

    def process_one_dir(self,fullname):
        pass

    def dir_noaccess(self,fullname):
        self.nodir.append(fullname)
        
t = NullTreeOp()
t.run(sys.argv)
print "Listed %d files." % t.nr_files



