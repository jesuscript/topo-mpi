//
// Minimal C++ demo: Take a string from Python and print it.
//

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "cpp_minimal.h"

Foo::Foo(char *msg)
{
	printf("Hello from Foo constructor!\n");
	my_msg = strdup(msg);
}

Foo::~Foo()
{
	printf("Hello from Foo destructor!\n");
	free(my_msg);
}

void Foo::say()
{
	printf("Foo says: %s\n", my_msg);
}
