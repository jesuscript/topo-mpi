//
// Mixed C/C++ module, C++ side
//

#include <Python.h>

class Mix1 {
 public:
	Mix1();
	~Mix1();

	// Note that %newobject is not needed in the SWIG file -
	// PyObjects have refcounting already, so it is handled
	// just like any other PyObject
	PyObject *make_list4(float a, float b, float c, float d);
};


