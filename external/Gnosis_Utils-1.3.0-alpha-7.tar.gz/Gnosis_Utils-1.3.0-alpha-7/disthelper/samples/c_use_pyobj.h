/*
  Handle a passed Python object
*/

#include <Python.h>

void print_pyseq_floats(PyObject *list);
