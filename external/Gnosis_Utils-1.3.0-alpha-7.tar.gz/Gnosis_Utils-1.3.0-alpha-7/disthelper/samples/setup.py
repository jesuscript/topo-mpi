#
# A setup.py that builds all the sample modules.
#
# This makes a good starting point to create your own setup.py.
#

import os, sys
from distutils.core import setup, Extension

# add disthelper to Python path
sys.path.insert(0,os.path.abspath(os.path.join('..','..')))

# grab disthelper stuff I need
from disthelper.setuplib import *
from disthelper.misc import *

#--------------------------------------------------------------
# Even though all sources live in '.', I want the package to
# be installed in "site-packages/DEST_PREFIX". (If you really
# do want them to be installed directly in "site-packages",
# delete all references to DEST_PREFIX below.)
#--------------------------------------------------------------
DEST_PREFIX = 'disthelper_samples'

#
# Figure out where SWIG lives
#

# For win32, directory where you unpacked swigwin
SWIG_DIR = "c:\\frank\\swig"

if os.name == 'posix':
    SWIG_PROG = "swig"
else:
    SWIG_PROG = os.path.join(SWIG_DIR,'swig.exe')

#
# Create a list of C and C++ extension modules.
#
ext_list = []

ext_list.append(C_SWIG('c_minimal',[],prefix=DEST_PREFIX))
ext_list.append(C_SWIG('c_use_pyobj',[],prefix=DEST_PREFIX))
ext_list.append(CPP_SWIG('cpp_minimal',[],prefix=DEST_PREFIX))
ext_list.append(CPP_SWIG('cpp_newobject',[],prefix=DEST_PREFIX))
ext_list.append(CPP_SWIG('mixed_cpp_part',['mixed_c_part.c'],prefix=DEST_PREFIX))

# demonstrate how to compile in sub-packages as well
ext_list.append(C_SWIG('subpkg.c_sub',[],prefix=DEST_PREFIX))

#
# Wrapper around setup() to report errors.
#
def do_setup():
    try:
        setup ( name		= 'disthelper samples',
                version		= '1.0',
                description = 'disthelper samples',
                author		= 'Frank McIngvale',
                author_email= 'frankm at hiwaay . net',
                url			= 'http://boodebr.org',
                package_dir = {DEST_PREFIX:''},
                packages = [DEST_PREFIX],
                ext_modules = ext_list,
                license		= "GPL",
                )
        return 0
    
    except Exception, exc:
        print "*** FAILED ON ERROR: %s" % str(exc)
        return -1

#---------------------------------------------------------------
# I prefer to define explicit setup targets rather that just
# calling "setup()". This ensures that I've tested all paths,
# since I may need to do prep or cleanup work on each step.
#---------------------------------------------------------------

if 'build' in sys.argv:
    # run swig on all modules
    gen_all_swigs(SWIG_PROG, ext_list)

    # build modules
    if do_setup() < 0:
        print "*** ERROR RUNNING SETUP"
        sys.exit(1)

    # copy all built modules to their package directories
    # so they can be used in-place if desired
    copy_extmods_to_pkgdir(ext_list)

if 'install' in sys.argv:
    # ensure a clean build
    os.system('%s setup.py build' % sys.executable)
    
    if do_setup() < 0:
        print "*** ERROR RUNNING SETUP"
        sys.exit(1)
    
if 'bdist_wininst' in sys.argv:
    # ensure a clean build
    os.system('%s setup.py build' % sys.executable)
    
    if do_setup() < 0:
        print "*** ERROR RUNNING SETUP"
        sys.exit(1)
    
if 'clean' in sys.argv:
    # remove all built/generated files
    #
    # if you need to delete other files, you can pass a list of 
    # glob patterns, i.e. to delete all ".obj" and ".exe" files
    # (any place they are found), you would pass extra_patt=['*.obj', '*.exe']
    #
    # Here, I'm removing my snapshot files (see below). In real usage, I'm sure
    # you'd want to move the snapshots somewhere safe :-)
    clean_all(ext_list, extra_patt=['*-snapshot-*.tar.gz',
                                    '*-snapshot-*.tar.bz2',
                                    '*-snapshot-*.zip'])
    
# for making snapshots of the source tree
if 'snap' in sys.argv:
    # -- make all three kinds, for demo purposes --
    from time import time, localtime
    
    # append a datestamp to filename
    year,month,day = localtime(time())[:3]
    ds = '%04d-%02d-%02d' % (year,month,day)
    
    # make a .ZIP
    name = 'samples-snapshot-%s.zip' % ds
    print "Making %s" % name
    zip_current_dir(name)
    
    # make a .TAR.GZ
    name = 'samples-snapshot-%s.tar.gz' % ds
    print "Making %s" % name
    tar_gz_current_dir(name)
    
    # make a .TAR.BZ2
    name = 'samples-snapshot-%s.tar.bz2' % ds
    print "Making %s" % name
    tar_bz2_current_dir(name)
    
