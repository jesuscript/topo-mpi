//
// Return new non-Python objects and show that SWIG deletes
// them when they are no longer referenced.
//

#include "cpp_newobject.h"

#include <stdio.h>

Bonk::Bonk(int a)
{
	printf("Bonk constructor (%d)\n", a);
	val = a;
}

Bonk::~Bonk()
{
	printf("Bonk destructor (%d)\n", val);
}

void Bonk::say()
{
	printf("Hello from Bonk %d\n", val);
}

Bar::Bar()
{
	printf("Bar constructor.\n");
}

Bar::~Bar()
{
	printf("Bar destructor.\n");
}

// A member function to make a Bonk
Bonk* Bar::make_bonk(int a)
{
	return new Bonk(a);
}

// A factory function to make a Bonk
Bonk* make_bonk_factory(int a )
{
	return new Bonk(a);
}
