/*
  Handle a passed Python object
*/

#include "c_use_pyobj.h"

void print_pyseq_floats(PyObject *list)
{
	int i;
	PyObject *f, *o;

	printf("PyList addr=%X:\n", list);

	/* use PySequence_ to handle list or tuple */
	for(i=0; i<PySequence_Size(list); ++i) {
		o = PySequence_GetItem(list, i);
		// coerce to float
		f = PyNumber_Float(o);
		printf("  %d: %f\n", i, PyFloat_AsDouble(f));
		Py_DECREF(f);
	}
}
