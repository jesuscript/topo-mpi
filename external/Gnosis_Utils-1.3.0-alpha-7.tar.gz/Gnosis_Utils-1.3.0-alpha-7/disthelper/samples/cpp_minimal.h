//
// Minimal C++ demo: Take a string from Python and print it.
//

class Foo {
 public:
	Foo(char *msg);
	~Foo();

	void say();
	
 protected:
	char *my_msg;
};

