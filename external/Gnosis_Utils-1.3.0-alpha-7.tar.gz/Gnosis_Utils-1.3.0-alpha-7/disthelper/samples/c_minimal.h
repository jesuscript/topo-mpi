/*
  Add three numbers passed from Python, returning sum.
*/

float add3(float a, float b, float c);

