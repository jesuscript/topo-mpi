//
// Return new non-Python objects and show that SWIG deletes
// them when they are no longer referenced.
//

class Bonk {
 public:
	Bonk(int a);
	~Bonk();

	void say();
	
 protected:
	int val;
};

class Bar {
 public:
	Bar();
	~Bar();

	// A member function to make a Bonk	
	Bonk *make_bonk(int a);
};

// A factory function to make a Bonk
Bonk* make_bonk_factory(int a );
