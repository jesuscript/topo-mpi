/*
  Mixed C/C++ module, C side
*/

/*
  Boilerplate to add when a C module might/will be called from C++
*/
#if defined(__cplusplus)
extern "C" {
#endif

#include <Python.h>
	
/* To be called from C++ side */
PyObject *c_make_list4(float a, float b, float c, float d);
	
/*
  Boilerplate to add when a C module will be called from C++
*/
#if defined(__cplusplus)
};
#endif	
	
