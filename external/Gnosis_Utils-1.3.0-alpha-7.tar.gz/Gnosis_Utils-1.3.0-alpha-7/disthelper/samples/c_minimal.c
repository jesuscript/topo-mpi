/*
  Add three numbers passed from Python, returning sum.
*/

#include "c_minimal.h"

float add3(float a, float b, float c)
{
	return (a+b+c);
}
