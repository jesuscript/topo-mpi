#
# Run the samples.
#

from c_minimal import add3
from subpkg.c_sub import add3 as subadd3

a = 1.11
b = 2.22
c = 3.33

print "ADD 3",a,b,c,add3(a,b,c)
print "SUB ADD 3",a,b,c,subadd3(a,b,c)

from c_use_pyobj import print_pyseq_floats

# show that ints are coerced correctly
print_pyseq_floats([1.23, 2.34, 3.45, 4.56, 7, 8, 9])

# ... and that it handles list or tuple
print_pyseq_floats((1.23, 2.34, 3.45, 4.56, 7, 8, 9))

import cpp_minimal

f = cpp_minimal.Foo("Foo is here!")
f.say()

from cpp_newobject import Bar, make_bonk_factory

bar = Bar()
bonk1 = bar.make_bonk(10)
bonk2 = make_bonk_factory(20)
bonk1.say()
bonk2.say()

import mixed_cpp_part
m = mixed_cpp_part.Mix1()
l = m.make_list4(1.2,2.3,3.4,4.5)
print "Mix1 list",l

