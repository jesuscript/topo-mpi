/*
  Mixed C/C++ module, C side
*/

#include "mixed_c_part.h"

PyObject *c_make_list4(float a, float b, float c, float d)
{
	PyObject *list, *f;

	list = PyList_New(0);
	PyList_Append(list, PyFloat_FromDouble(a));
	PyList_Append(list, PyFloat_FromDouble(b));
	PyList_Append(list, PyFloat_FromDouble(c));
	PyList_Append(list, PyFloat_FromDouble(d));

	return list;
}
