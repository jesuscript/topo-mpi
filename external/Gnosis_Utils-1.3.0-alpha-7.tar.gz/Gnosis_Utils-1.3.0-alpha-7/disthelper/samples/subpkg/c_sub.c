/*
  Add three numbers passed from Python, returning sum.
*/

#include "c_sub.h"

float add3(float a, float b, float c)
{
	return (a+b+c);
}
