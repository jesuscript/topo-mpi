//
// Mixed C/C++ module, C++ side
//

#include "mixed_cpp_part.h"
#include "mixed_c_part.h"

Mix1::Mix1()
{
	printf("Mix1 constructor\n");
}

Mix1::~Mix1()
{
	printf("Mix1 constructor\n");
}

PyObject *Mix1::make_list4(float a, float b, float c, float d)
{
	// Call C function
	return c_make_list4(a, b, c, d);
}
