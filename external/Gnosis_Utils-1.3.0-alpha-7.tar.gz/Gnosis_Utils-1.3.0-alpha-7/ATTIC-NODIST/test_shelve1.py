
from gnosis.xml.pickle.extensions import ClassExtension, register_extension
from gnosis.xml.pickle import loads, dumps, dump, load, add_class_to_store, SEARCH_STORE, \
     dump_stats, load_stats
from randstuff import rand_ascii_word, rand_ascii_block
from random import randint
from time import time
import pickle, cPickle

class Client:

    def __init__(self, first, middle, last, addr1, addr2, city, state, zipcode, notes):
        self.first = first
        self.middle = middle
        self.last = last
        self.addr1 = addr1
        self.addr2 = addr2
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.notes = notes

def rand_client():

    c = Client(rand_ascii_word(5, 10), rand_ascii_word(5, 10), rand_ascii_word(5, 10),
               rand_ascii_block(1, 1, 20, 30), rand_ascii_block(1, 1, 20, 30),
               rand_ascii_word(5, 10), rand_ascii_word(2, 2), randint(10000,99999),
               rand_ascii_block(10, 20, 55, 72))
    return c

class XMLPickleShelfExt(ClassExtension):

    def __init__(self):
        ClassExtension.__init__(self, "PickleShelfExt")
        
    def pickle(self, obj):
        if not isinstance(obj, XMLPickleShelfEntry):
            return self.ignore(obj)

        if obj.state == S_PICKLED:
            return (obj.obj, (), ())
        else:
            return (dumps(obj.obj,short_ids=1), (), ())

    def unpickle_begin_core(self, typestr, metadata, coredata,
                            class_search, allow_replicants):
        return XMLPickleShelfEntry(coredata, S_PICKLED)

    def unpickle_finalize(self, obj, propmap):
        pass

S_PICKLED = 0
S_READ = 1
S_WRITTEN = 2

class XMLPickleShelfEntry:

    def __init__(self, obj, state):
        self.obj = obj
        self.state = state

    def get(self):
        if self.state in [S_READ,S_WRITTEN]:
            return self.obj
        else:
            self.obj = loads(self.obj)
            self.state = S_READ
            return self.obj
        
    def set(self, obj):
        self.obj = obj
        self.state = S_WRITTEN
        
class XMLPickleShelf:

    def __init__(self):
        self.dict = {}

    def __del__(self):
        pass
        
    def __setitem__(self, key, val):
        if self.dict.has_key(key):
            self.dict[key].set(val)
        else:
            self.dict[key] = XMLPickleShelfEntry(val, S_WRITTEN)

    def __getitem__(self, key):
        return self.dict[key].get()

    def __delitem__(self, key):
        del self.dict[key]

    def keys(self):
        return self.dict.keys()

register_extension(XMLPickleShelfExt())

print 'CREATE'

# make a regular dict of Clients
orig = {}
orig['ABC'] = Client('Joe','P.','Smith','111 Main Street','Apt. C','Plainville',
                  'ZA', 12345, 'A sample client.\nHere is line two.\nBlah.')
    
for i in range(4000):
    orig[i] = rand_client()

import profile

t1 = time()
f = open('clients_normal.xml','w')
st = dump_stats(f, orig, short_ids=1, prefer_cdata=1)
print "DUMP time, normal = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

t1 = time()
f = open('clients_normal_11.xml','w')
st = dump_stats(f, orig, short_ids=1, prefer_cdata=1, version="1.1")
print "DUMP time, normal (1.1) = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

# now put same data in an XMLPickleShelf
shelf = XMLPickleShelf()
for k,v in orig.items():
    shelf[k] = v

# dump as shelf
t1 = time()
f = open('clients_shelf.xml','w')
st = dump_stats(f, shelf, short_ids=1, prefer_cdata=1)
print "DUMP time, shelf = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

# allow loads() to find Client
add_class_to_store(Client)
add_class_to_store(XMLPickleShelf)

t1 = time()
f = open('clients_normal.xml','r')
p,st = load_stats(f,SEARCH_STORE)
print "LOAD normal = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

t1 = time()
f = open('clients_normal_11.xml','r')
p,st = load_stats(f,SEARCH_STORE)
print "LOAD normal (1.1) = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

t1 = time()
f = open('clients_shelf.xml','r')
p,st = load_stats(f,SEARCH_STORE)
print "LOAD shelf = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))
#print p, p.keys(), p['ABC'].__dict__

t1 = time()
f = open('clients_shelf.xml','w')
st = dump_stats(f, p, short_ids=1, prefer_cdata=1)
print "RE-write shelf (no changes) = ",time()-t1
print "(%d objects, %.1f objs/sec)" % (st.nr_objects,st.nr_objects/(time()-t1))

#t1 = time()
#cPickle.dump(orig, open('aaa.pck','w'),1)
#print time()-t1
