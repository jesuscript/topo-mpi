
from gnosis.xml.pickle.misc import pprint_obj
from gnosis.xml.pickle import dumps, loads, SEARCH_NO_IMPORT
from gnosis.xml.pickle.extensions import ClassExtension, register_extension
from gnosis.xml.pickle.objmodel import compose_top_nocore, get_classtag, compose_setcore

class MetaclassExt(ClassExtension):

    def pickle(self, obj):
        if hasattr(obj, '__metaclass__'):
            return (obj, {'metaclass': obj.__metaclass__,
                        'classtag': get_classtag(obj)}, {})
        else:
            return self.ignore(obj)

    def unpickle_begin_nocore(self, typestr, metadata,
                                class_search, allow_replicants):
        o,is_replicant = compose_top_nocore(typestr, metadata['classtag'], None,
                                            class_search, allow_replicants)
        return o
                                                        
    def unpickle_set_coredata(self, typestr, obj, coredata):
        compose_setcore(typestr, obj, coredata)
        
    def unpickle_finalize(self, obj, propmap):
        pass
        
class metaPrinter(type):
    def __init__(cls, name, bases, dict):
        from gnosis.xml.pickle.misc import pprint_obj		
        super(metaPrinter, cls).__init__(name, bases, dict)
        setattr(cls, 'pprint', pprint_obj)

def show_repr(obj):
    print "REPR = ",repr(obj)
    
class metaPrinterMore(metaPrinter):
    def __init__(cls, name, bases, dict):
        super(metaPrinterMore, cls).__init__(name, bases, dict)
        setattr(cls, 'show_repr', show_repr)
        
__metaclass__ = metaPrinter
        
class Foo:	
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

class Bar(Foo):
    def __init__(self, a, b, c):
        Foo.__init__(self,a,b,c)

class Baz(list):
    __metaclass__ = metaPrinter
    def __init__(self, items, a, b):
        list.__init__(self, items)
        self.a = a
        self.b = b

class AAA(dict):
    __metaclass__ = metaPrinterMore
    def __init__(self, d, a, b):
        dict.__init__(self, d)
        self.a = a
        self.b = b

o = compose_top_nocore('list','__main__.Baz',None,SEARCH_NO_IMPORT,0)
print o
#raise "AAA"

print dir(Foo)
f = Foo(123, 1.234, 'hello foo')
f.pprint()

ba = Bar('aaa','bbb','ccc')
ba.pprint()

bz = Baz( (1,2.34,'hello Baz'), 321, 432 )
bz.pprint()

#print "CORE ",bz[:]
#bz[:] = [1,2,3]
#print "CORE2 ",bz[:]
#raise "AAA"
#
a = AAA( {'aaa':1, 'bbb':2}, 987, 7.654 )
a.pprint()
a.show_repr()

#register_extension( MetaclassExt(), 'MetaclassExt' )

l = [f, ba, bz, a]
xml = dumps(l, deepcopy=1)
print xml

l2 = loads(xml,SEARCH_NO_IMPORT,allow_replicants=0)
l2[3].show_repr()


