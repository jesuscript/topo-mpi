from gnosis.xml.pickle.extensions import ClassExtension, register_extension
from gnosis.xml.pickle import loads, dumps, dump, load, add_class_to_store, SEARCH_STORE, \
     dump_stats, load_stats
from random import randint
from time import time
import shelve

import sys, os
sys.path.insert(0,os.path.abspath('..'))

# shared with topdir
from randstuff import rand_ascii_word, rand_ascii_block

class XMLPickleShelfStore:
    """
    Baseclass for XMLPickleShelf storage.
    """
    pass

class DirectoryStore(XMLPickleShelfStore):

    def __init__(self, dirname):
        self.dirname = dirname

    def load_index(self):
        """
        Returns the index as a dict.
        For each key 'k' in dict 'd':
            d[k] = filename

        Where filename is the filename to load the full object from.
        """
        name = os.path.join(self.dirname, 'index.xml')
        if not os.path.isfile(name):
            return {}
        else:
            return load(open(name,'r'))

    def store_index(self, d):
        name = os.path.join(self.dirname, 'index.xml')
        dump(open(name,'w'),d,deepcopy=1)

    def load_obj(self, filename):
        """
        Load one object. filename is a filename from the index.
        """
        name = os.path.join(self.dirname, filename)
        return load(open(name,'r'))

    def store_obj(self, filename, obj):
        """
        Store one object. filename is either:
           - An existing filename from the index, to be overwritten.
           - None, to create a new file.

        Returns filename (new or existing).
        """
        if filename is None:
            # pick a subdir (00..99)
            n = randint(0,100)
            subpath = '%02d' % n
            path = os.path.join(self.dirname, subpath)
            if not os.path.isdir(path):
                os.makedirs(path)
            
            i = 0
            while 1:
                relname = os.path.join(subpath, 'data-%d.xml' % i)
                filename = os.path.join(self.dirname, relname) 
                if not os.path.isfile(filename):
                    break

                i += 1

            filename = relname

        dump(open(os.path.join(self.dirname,filename),'w'), obj)
        return filename
    
STATE_NOT_LOADED = 0   # .obj exists in store, but hasn't yet been loaded
STATE_SYNCED = 1       # .obj is valid, with no reads OR writes since syncing
STATE_READ = 1         # .obj has been read since last sync
STATE_REPLACED = 2     # .obj has been replaced since last sync
STATE_NEW = 3          # .obj is new since last sync

SYNC_WRITES = 0
SYNC_ALL = 1

class XMLPickleShelfEntry:

    def __init__(self, obj, state, store, filename):
        self.obj = obj
        self.state = state
        self.store = store
        self.filename = filename
        
    def get(self):
        if self.state == STATE_NOT_LOADED:
            self.obj = self.store.load_obj(self.filename)
            self.state = STATE_SYNCED

        if self.state not in (STATE_REPLACED,STATE_NEW):
            self.state = STATE_READ
            
        return self.obj
        
    def set(self, obj, state):
        self.obj = obj
        self.state = state

    def sync(self, sync_type):
        "Returns 1 if sync was required, 0 if not."
        if self.state in (STATE_NOT_LOADED, STATE_SYNCED):
            return 0

        if sync_type == SYNC_ALL or (sync_type==SYNC_WRITES and self.state != STATE_READ):
            self.filename = self.store.store_obj(self.filename, self.obj)
            self.state = STATE_SYNCED

            return 1
        else:
            return 0
    
STORE_DIR = 0  # store is a directory
STORE_ZIP = 1  # store is a zipfile

class XMLPickleShelf:
    """
    Create a new xml.pickle 'shelf'.

    kind specifies the storage type:

       if kind==STORE_DIR:
          The store is a set of files under the directory named 'name'.
       if kind==STORE_ZIP:
          The store is a set of files inside a zipfile named 'name'.
    """
    
    def __init__(self, name, kind, sync_type=SYNC_WRITES):
        self.sync_type = sync_type
        
        if kind == STORE_DIR:
            self.objstore = DirectoryStore(name)
        else:
            raise Exception("Unknown storage type.")

        index = self.objstore.load_index()
        self.odict = {}
        
        for key,filename in index.items():
            self.odict[key] = XMLPickleShelfEntry(None, STATE_NOT_LOADED, self.objstore, filename)

    def __del__(self):
        self.sync()
        
    def __setitem__(self, key, val):
        if self.odict.has_key(key):
            # overwriting existing entry
            self.odict[key].set(val, STATE_REPLACED)
        else:
            # new entry
            self.odict[key] = XMLPickleShelfEntry(val, STATE_NEW, self.objstore, None)			

    def __getitem__(self, key):
        return self.odict[key].get()

    def keys(self):
        return self.odict.keys()

    def sync(self):
        newindex = {}
        r = 0
        
        for key, obj in self.odict.items():
            r += obj.sync(self.sync_type)
            newindex[key] = obj.filename

        if r > 0:
            # one or more objects were synced, so rewrite index
            self.objstore.store_index(newindex)
        
#--------------------------------------
# test
#--------------------------------------

class Client:

    def __init__(self, first, middle, last, addr1, addr2, city, state, zipcode, notes):
        self.first = first
        self.middle = middle
        self.last = last
        self.addr1 = addr1
        self.addr2 = addr2
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.notes = notes

def rand_client():

    c = Client(rand_ascii_word(5, 10), rand_ascii_word(5, 10), rand_ascii_word(5, 10),
               rand_ascii_block(1, 30), rand_ascii_block(1, 30),
               rand_ascii_word(5, 10), rand_ascii_word(2, 2), randint(10000,99999),
               rand_ascii_block(randint(10,20), 72))
    return c

add_class_to_store(Client)

def test1():
    import shutil
    if os.path.isdir('data'):
        print "Removing old data ..."
        shutil.rmtree('data')

    rawclients = []
    rawclients.append( ('ABC',Client('Joe','P.','Smith','111 Main Street','Apt. C','Plainville',
                              'ZA', 12345, 'A sample client.\nHere is line two.\nBlah.')))
    rawclients.append( ('DEF',Client('Louis','P.','Jones','222 S. Nowhere St.',
                                     'Apt. 11','Duskville',
                                     'YH', 43212, 'A second sample client\nHere is line two.\nWhee!')))

    clients = XMLPickleShelf('data',STORE_DIR)

    for k,c in rawclients:
        clients[k] = c

    del clients

    c2 = XMLPickleShelf('data',STORE_DIR)
    for k,c in rawclients:
        for attr in c.__dict__.keys():
            if getattr(c2[k],attr) != getattr(c,attr):
                raise "ERROR"

def open_as_xml():
    return XMLPickleShelf('data',STORE_DIR)

def open_as_shelf():
    return shelve.open('DBDATA')

def test2(openfunc):
    import shutil, profile
    if os.path.isdir('data'):
        print "Removing old data ..."
        shutil.rmtree('data')
        
    print "Creating clients ..."
    NR = 10000

    clients = openfunc()
    
    for i in range(NR):
        clients[i] = rand_client()

    print "SYNCING"
    t1 = time()
    del clients
    dt = (time() - t1) or 1e-6
    print "Wrote %d NEW clients in %f seconds (%.1f/second)" % (NR,dt,NR/dt)

    print "Reloading ..."
    t1 = time()
    clients = openfunc()
    dt = (time() - t1) or 1e-6	
    print "Reloaded index in %f seconds (%.1f items/sec)" % (dt,NR/dt)

    t1 = time()
    del clients
    dt = (time() - t1) or 1e-6	
    print "Null SYNC in %f seconds (%.1f items/sec)" % (dt,NR/dt)

    print "Reloading(2) ..."
    t1 = time()
    clients = openfunc()
    dt = (time() - t1) or 1e-6	
    print "Reloaded index in %f seconds (%.1f items/sec)" % (dt,NR/dt)

    print "Iterating over all clients ..."
    t1 = time()	
    for k in clients.keys():
        o = clients[k]
    dt = (time() - t1) or 1e-6	
    print "Iterated in %f seconds (%.1f clients/sec)" % (dt,NR/dt)

    t1 = time()
    del clients
    dt = (time() - t1) or 1e-6	
    print "Null SYNC in %f seconds (%.1f items/sec)" % (dt,NR/dt)

    print "Reloading(3) ..."
    t1 = time()
    clients = openfunc()
    dt = (time() - t1) or 1e-6	
    print "Reloaded index in %f seconds (%.1f items/sec)" % (dt,NR/dt)

    # change 10% of clients
    keys =  clients.keys()[:NR/10]
    print "Modify %d/%d" % (len(keys),NR)
    t1 = time()
    for k in keys:
        o = clients[k]
        o.zipcode += 1
        clients[k] = o

    del clients
    dt = (time() - t1) or 1e-6	
    print "Modified/wrote 10%% in %.1f seconds (%.1f items/sec)" % (dt,(NR/10)/dt)
    
test1()

test2(open_as_xml)



