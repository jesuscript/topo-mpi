
from gnosis.xml.pickle import loads, dumps

d = {'a':1,'b':2}

print dumps(d.items())
