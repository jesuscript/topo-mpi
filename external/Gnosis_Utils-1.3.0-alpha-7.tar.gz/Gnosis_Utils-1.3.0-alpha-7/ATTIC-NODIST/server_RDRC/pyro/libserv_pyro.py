import Pyro.core
from gnosis.xml.pickle import dumps
from gnosis.xml.pickle.extensions import register_extension
from ext import RemoteObjTagger

class ObjlistServer(Pyro.core.ObjBase):

    def __init__(self, objlist, proxy_server, proxy_uri,
                 export_classes, export_funcs):
        Pyro.core.ObjBase.__init__(self)
        self.objlist = objlist
        self.ext = RemoteObjTagger(proxy_uri, #'PYROLOC://127.0.0.1:8080/ObjProxyServer',
                                   proxy_server,
                                   export_classes,
                                   export_funcs)

    def getnext(self):
        print "GET NEXT FROM ",self.objlist
        
        if not len(self.objlist):
            return ''
        
        o = self.objlist[0]
        self.objlist = self.objlist[1:]
        xml = dumps(o, short_ids=1, extensions=[self.ext])
        return xml
    
class RemoteObjProxyServer(Pyro.core.ObjBase):

    def __init__(self):
        Pyro.core.ObjBase.__init__(self)
        self.objmap = {}

    def add_object(self, obj, obj_id):
        # Pyro will actually let a remote client call this routine, even
        # though it's only meant for internal use. There's probably a way
        # to turn that off, but at any rate, forcing the ids() to match
        # is good - it's improbable a remote client could send me an
        # object whose id matched on my side.
        if id(obj) != obj_id:
            raise "ERROR - trying to add invalid object"
        
        self.objmap[id(obj)] = obj

    def call_object(self, obj_id, method, *args):
        print "CALL_OBJECT ",obj_id,method,repr(args)
        print "REAL OBJ",self.objmap[obj_id]
        m = getattr(self.objmap[obj_id],method)
        return m(*args)

    def del_object(self, obj_id):
        print "DEL_OBJECT",obj_id
        del self.objmap[obj_id]

