"""
The ClassExtensions that do the work of transforming
the object to be sent over the network.
"""

from gnosis.xml.pickle.extensions import ClassExtension
from gnosis.xml.pickle.objmodel import get_classtag
import inspect
        
class RemoteObjTagger(ClassExtension):

    def __init__(self, remote_server, server, export_classes, export_funcs):
        """
        With a RemoteObjTagger, neither code nor data is sent to
        the client. Instead, the object is saved here, and client
        can make calls to it. The only thing sent is a description
        of the class methods (the first time it is sent).
        """
        self.remote_server = remote_server
        self.server = server
        self.export_classes = export_classes
        self.export_funcs = export_funcs
        # client only needs to see a class/function definition once.
        # after that, a ref_id can be sent instead.
        self.have_sent_defs = {}

        # I keep pickled objects here, keyed by id()
        self.kept_objs = {}
        
    def pickle(self, obj):
        self.server.add_object(obj)
        
        # metadata will contain the server address, etc.
        # The client side will use this in order to talk
        # to remote objects on the remote_server
        metadata = {}

        # attach server address
        metadata['server_addr'] = self.remote_server

        matched = 0
        
        # is it a class I want to handle?
        if obj in self.export_classes:
            ref_obj = obj
            mtype = 'class'
            matched = 1
            
        # is it an instance of a class I want to handle?
        for k in self.export_classes:
            if not matched and isinstance(obj,k):
                # keep a reference to the *CLASS*, not the object,
                # since it the source code for CLASSES that is
                # being sent to the client
                ref_obj = k	 
                mtype = 'instance'
                matched = 1
                break

        # is it a function I want to handle?
        for f in self.export_funcs:
            if not matched and obj == f:
                ref_obj = f
                mtype = 'function'
                matched = 1
                
        if matched:
            metadata['type'] = mtype
            metadata['name'] = get_classtag(ref_obj)

            if mtype == 'instance':
                # also send id(), and keep instance for client to call later.
                # (this appears redundant, but id doesn't get passed down
                # to Extensions, and also this make us immune to the server
                # setting deepcopy=1 (where ids would be omitted)
                metadata['obj_id'] = id(obj)
                self.kept_objs[id(obj)] = obj
                
            if mtype in ['class','instance']:
                # For classes/instances, send a list of legal
                # method names (so a sensible error can be given
                # on the client side). Remember which I've sent
                # so they only need to be sent once.
                
                if self.have_sent_defs.has_key(id(ref_obj)):
                    # Have sent - just pass ref
                    metadata['class_refid'] = '%s' % id(ref_obj)
                else:
                    # Haven't sent yet.
                    metadata['class_id'] = '%s' % id(ref_obj)

                    # tell client the legal method names for the class/instance
                    methods = []
                    for name,val in inspect.getmembers(ref_obj):
                        if inspect.ismethod(val):
                            methods.append(name)

                    metadata['methods'] = methods
                    
                    # remember I've sent the defs ...
                    self.have_sent_defs[id(ref_obj)] = ref_obj				

            # note the object is returned *as-is*; only some metadata
            # has been attached
            return (obj, metadata, {})
        else:
            # not a class/function I'm supposed to handle
            return self.ignore(obj)	
