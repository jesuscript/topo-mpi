
import os,sys
sys.path.insert(0,os.path.abspath('..'))

import Pyro.core
from libserv_pyro import RemoteObjProxyServer, ObjlistServer

class Foo:
    def hello(self):
        pass

    def say(self,msg):
        print "FOO SAYS: ",msg
        return None

class Bar:
    def say(self,msg):
        print "BAR SAYS: ",msg

f = Foo()
f.b = Bar()
g = Foo()

objlist = [f, g]
export_classes = [Foo,Bar]
export_funcs = []

Pyro.core.initServer()

daemon = Pyro.core.Daemon(host='127.0.0.1', port=8080)

p_serv = RemoteObjProxyServer()
p_uri = daemon.connect(p_serv, 'ObjProxyServer')

print "RUNNING ",p_uri

o_serv = ObjlistServer(objlist, str(p_uri), p_serv, export_classes, export_funcs)
o_uri = daemon.connect(o_serv, 'ObjlistServer')

print "RUNNING ",o_uri

#register_extension(ext,'RDRC')
#xml = dumps( objlist, short_ids=1, extensions=[ext] )
#print xml

#open('fff.xml','w').write(xml)

#unregister_extension(ext,'RRR')

daemon.requestLoop()
