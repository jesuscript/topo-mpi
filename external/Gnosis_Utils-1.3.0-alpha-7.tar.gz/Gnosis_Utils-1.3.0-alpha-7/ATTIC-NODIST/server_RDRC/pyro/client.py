
from gnosis.xml.pickle.extensions import ClassExtension
from gnosis.xml.pickle import loads
from gnosis.xml.pickle.extensions import register_extension
import Pyro.core

class RemoteInstanceMethodProxy:
    def __init__(self, remote_server, remote_obj_id, method):
        self.remote_server = remote_server
        self.remote_obj_id = remote_obj_id
        self.method = method

    def __str__(self):
        return repr(self)
    
    def __repr__(self):
        return "RemoteInstanceMethodProxy, method=%s" % self.method
    
    def __call__(self, *args):
        print "CALL method '%s' of objid '%s' with args '%s', server %s" % \
              (self.method, self.remote_obj_id, repr(args),
               self.remote_server)
        oserv = Pyro.core.getProxyForURI(self.remote_server)		
        oserv.call_object(self.remote_obj_id, self.method, *args)
        
class RemoteInstanceProxy:
    def __init__(self, remote_server, remote_obj_id, methods):
        self.remote_server = remote_server
        self.remote_obj_id = remote_obj_id
        self.methods = methods

    def __del__(self):
        oserv = Pyro.core.getProxyForURI(self.remote_server)		
        oserv.del_object(self.remote_obj_id)
        
    def __str__(self):
        return repr(self)
    
    def __repr__(self):
        return 'RemoteInstanceProxy, server=%s, methods=%s' % \
               (self.remote_server, self.methods)
    
    def __getattr__(self, name):
        if name not in self.methods:
            raise "ERROR: '%s' not a valid method name." % name

        return RemoteInstanceMethodProxy(self.remote_server,
                                         self.remote_obj_id,
                                         name)

class RemoteFuncProxy:
    def __init__(self, remote_server, function):
        self.server = remote_server
        self.function = function

    def __call__(self, *args):
        print "CALLED %s %s" % (self.server, self.function)
        print "ARGS %s" % repr(args)
        return 'aaa'

class RemoteClassProxy:
    def __init__(self, remote_server, function):
        self.server = remote_server
        self.function = function

    def __call__(self, *args):
        print "CALLED %s %s" % (self.server, self.function)
        print "ARGS %s" % repr(args)
        return 'aaa'

class RemoteObjUnpickler(ClassExtension):

    def __init__(self):
        # set my extension name
        ClassExtension.__init__(self, 'RDRC')
        
        # list of instance methods I've seen, keyed by
        # the class_id that I'm sent
        self.known_methods = {}
        
    def unpickle_begin_nocore(self, typestr, metadata, *unused):
        print "UNPICKLE BEGIN", metadata

        if metadata.has_key('class_id'):
            # I haven't seen this class before
            methods = metadata['methods']
            self.known_methods[metadata['class_id']] = methods
        else:
            # I've seen this class, so they methods weren't sent again
            methods = self.known_methods[metadata['class_refid']]
            
        if metadata['type'] == 'instance':
            obj = RemoteInstanceProxy(metadata['server_addr'],
                                      metadata['obj_id'],
                                      methods)
            return obj

        elif metadata['type'] == 'function':
            obj = RemoteFuncProxy(metadata['server_addr'],
                                  metadata['name'])

        else:
            raise "NOT IMPLEMENTED"

    def unpickle_set_coredata(self, *unused):
        # I don't store data locally, so ignore
        pass

    def unpickle_begin_core(self, typestr, metadata, *unused):
        # I don't store coredata locally, so this is the
        # same as the nocore case
        return self.unpickle_begin_nocore(typestr, metadata)

    def unpickle_finalize(self, *unused):
        # nothing to do
        return

def test():

    oserv = Pyro.core.getProxyForURI('PYROLOC://127.0.0.1:8080/ObjlistServer')
    print oserv
    print oserv.getnext()
    return

    xml = open('fff.xml','r').read()

    ext = RemoteObjUnpickler()
    register_extension(ext)
    olist = loads(xml)

    print repr(olist)

    o = olist[0]
    print o
    print o.say("Hello world?")

    b = o.b
    print b.say("Hello?")
    
test()
