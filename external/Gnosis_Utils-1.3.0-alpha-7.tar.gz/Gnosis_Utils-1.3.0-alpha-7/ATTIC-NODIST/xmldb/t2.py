
from store import IndexItem, XmlDb, XmlDbObj

class Person(XmlDbObj):

    def __init__(self, nr, first, last, state):
        self.nr = nr
        self.first = first
        self.last = last
        self.state = state

    def __str__(self):
        return "Person: [%d] %s %s, %s" % \
               (self.nr, self.first, self.last, self.state)

i_first = IndexItem(Person, 'first')
i_last = IndexItem(Person, 'last')

db = XmlDb('data', [i_first, i_last])

people = [
    Person(0,'John','Smith','AZ'),
    Person(1,'John','Doe','MI'),
    Person(2,'Martha','Smith','MI'),
    Person(3,'John','Apple','CT'),
    Person(4,'Sue','Smith','WA'),
    Person(5,'Jane','Doe','MA')
    ]

for p in people:
    db.store(p)

for k in db.keysets():
    print k

print "-- First=John --"
for obj in db.lookup(0, 'John'):
    print obj

print "-- Last=John --"
for obj in db.lookup(1, 'Smith'):
    print obj	

print "--First=Jane--"
for obj in db.lookup(0,'Jane'):
    print obj
    obj.state = 'NM'
    db.store(obj)

print "-- Change state to NM --"

print "--First=Jane--"
for obj in db.lookup(0,'Jane'):
    print obj

print "--Last=Smith--"
for obj in db.lookup(1,'Smith'):
    print obj
    
print "-- Change Jane to Smith--"
for obj in db.lookup(0,'Jane'):
    obj.last = 'Smith'
    db.store(obj)

print "--Last=Smith--"
for obj in db.lookup(1,'Smith'):
    print obj

    


    
    
