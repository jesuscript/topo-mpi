
from keylist import DbKeySet
from gnosis.xml.pickle.objmodel import get_classtag
from gnosis.xml.pickle import dump, load
from random import randint
import os
from copy import copy

class IndexItem:
    def __init__(self, klass, attr):
        self.klass = klass
        self.attr = attr
        self.dbname = '%s_%s.db' % \
                      (get_classtag(klass).replace('.','_'), attr)

class XmlDbObj:
    _db_relname = None
    _db_keyvals = None

    def __getstate__(self):
        d = copy(self.__dict__)
        del d['_db_relname']
        del d['_db_keyvals']
        return d
    
class XmlDb:
    def __init__(self, root_dir, indexes):
        self.root_dir = root_dir
        if not os.path.isdir(root_dir):
            os.makedirs(root_dir)
            
        self.indexes = indexes
        # one DbKeySet for each index in self.indexes
        self.dbfile = []
        for i, ix in enumerate(self.indexes):
            name = os.path.join(self.root_dir, ix.dbname)
            self.dbfile.append( DbKeySet(name) )

    def gen_filename(self):
        # Use a two-level directory store, like 'NN/NN/file-NNNN.xml',
        # to prevent directory lookups from slowing down too much.
        # Assuming 1000 files per directory, 100*100*1000 = 10 million records.
        n1 = randint(0,99)
        n2 = randint(0,99)
        # I want to record only the relative path in the index
        relpath = os.path.join('%02d' % n1, '%02d' % n2)
        path = os.path.join(self.root_dir, relpath)
        if not os.path.isdir(path):
            os.makedirs(path)

        # generate a unique filename within this directory
        i = randint(0,9999)
        while 1:
            relname = os.path.join(relpath, 'data-%d.xml' % i)
            filename = os.path.join(self.root_dir, relname) 
            if not os.path.isfile(filename):
                return relname

            # start with a random number, hoping it will be
            # unique, but increment from here on, to guarantee
            # a slot will eventually be found
            i += 1

    def get_index_values(self, obj):
        "Get the index values from obj."
        vals = []
        
        for idx in self.indexes:
            if isinstance(obj, idx.klass):
                val = getattr(obj, idx.attr, None)
            else:
                val = None

            vals.append(val)

        return vals
    
    def store(self, obj):
        if obj._db_relname is None:
            # first time this obj has been stored
            obj._db_relname = self.gen_filename()
            print "GEN filename",obj._db_relname
            obj._db_keyvals = self.get_index_values(obj)
            print "NEW keyvals",obj._db_keyvals
            
            # store index values
            for i,val in enumerate(obj._db_keyvals):
                print "ADD keyval",val,obj._db_relname
                self.dbfile[i].add(val, obj._db_relname)

        else:
            # obj is being updated.
            newvals = self.get_index_values(obj)
            print "NEWVALS ",newvals
            print "OLDVALS ",obj._db_keyvals
            
            for i, val in enumerate(obj._db_keyvals):
                if val != newvals[i]:
                    # remove my filename indexed under my previous value
                    print "DEL keyval",val,obj._db_relname
                    self.dbfile[i].remove(val, obj._db_relname)
                    # add new value as index to my filename
                    print "ADD keyval",newvals[i], obj._db_relname
                    self.dbfile[i].add(newvals[i], obj._db_relname)
                    
            # save newvals
            obj._db_keyvals = newvals

        name = os.path.join(self.root_dir,obj._db_relname)
        dump(open(name,'w'), obj)

    def keysets(self):
        sets = []
        for i, db in enumerate(self.dbfile):
            sets.append(db.keys())

        return sets
    
    def lookup(self, i, val):
        "Look up value 'val' in the i'th index."
        db = self.dbfile[i]
        objs = []
        for name in db.get(val):
            fullname = os.path.join(self.root_dir, name)
            obj = load(open(fullname,'r'), 0)
            obj._db_relname = name
            obj._db_keyvals = self.get_index_values(obj)
            objs.append(obj)

        return objs
    
        
