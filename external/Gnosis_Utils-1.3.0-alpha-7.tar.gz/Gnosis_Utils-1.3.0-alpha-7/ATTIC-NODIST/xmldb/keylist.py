"""

Requires Python 2.3+ (uses sets).
"""

import bsddb
from types import *
from gnosis.xml.pickle import loads, dumps, SEARCH_NONE
from gnosis.pyconfig import pyconfig

# use builtin sets if available
if pyconfig.Have_BuiltinSet():
    def new_set(items=None): return set(items or [])
else:
    import sets
    def new_set(items=None): return sets.Set(items or [])
    
class DbKeySet(object):
    """
    A persistent map where each key is associated with a set of strings.
    Each value in the set of strings can only appear once (trying to
    add() the same value again does nothing).

    The API is transactional - you make any number of changes you want
    with add()/remove(), then call sync() to write all changes at once.
    If you've made some changes, but need to bail out, you can call undo()
    to undo all changes since the last sync().

    Note that __del__ does a sync(), so you have to undo() if you don't
    want the changes to be written.
    """
    def __init__(self, dbname):
        self.db = bsddb.btopen(dbname, 'c')
        # each item in loaded is (list, modified), where list is the
        # list of strings associated with key, and modified indicates
        # if the list has been modified since it was loaded (and hasn't
        # been resynced yet)
        self.loaded = {}

    def __del__(self):
        self.sync()
        
    def assert_string(self,val):
        assert(type(val) in (StringType,UnicodeType))

    def ensure_loaded(self, key):
        """
        If not already in self.loaded, load the list list associated
        with key into self.loaded. If key doesn't exist, self.loaded[key]
        is set to [].
        """
        if not self.loaded.has_key(key):
            if self.db.has_key(key):
                # load & set not-modified
                self.loaded[key] = (loads(self.db[key],SEARCH_NONE,allow_replicants=0), 0)
            else:
                # create empty list & set not-modified (empty sets won't
                # be written to the db)
                self.loaded[key] = (new_set(), 0)
            
    def add(self, key, val):
        """
        Add val (a string) to the list of strings associated
        with key. If val is already in the list, it is not
        added again.
        """		
        self.assert_string(key)
        self.assert_string(val)

        # load self.loaded[key], or create new list
        self.ensure_loaded(key)
        sset,m = self.loaded[key]
        if val in sset:
            return
        
        sset.add(val)
        self.loaded[key] = (sset,1)

    def remove(self, key, val):
        """
        Remove val from the set of strings associated with the key.
        It is an error for val to not exist in the list.
        """
        self.assert_string(key)
        self.assert_string(val)

        self.ensure_loaded(key)
        
        sset,m = self.loaded[key]
        sset.remove(val)
        self.loaded[key] = (sset,1) # mark list as modified
                
    def get(self, key):
        """
        Get the set of strings for key.
        If the key doesn't exist, the set will be empty.

        DO NOT modify the returned set. If you need to add or
        remove an entry, call add() or remove().
        """
        self.assert_string(key)

        # load self.loaded[key], or create new list		
        self.ensure_loaded(key)
        return self.loaded[key][0]

    def undo(self):
        """
        Undo all changes since last sync().
        """
        # Assume that a large number of objects have already
        # been read into self.loaded, and discard only those
        # entries that have been modified.
        to_del = []
        for key in self.loaded.keys():
            sset,modified = self.loaded[key]
            if modified:
                to_del.append(key) # can't del while iterating

        # delete the modified entries
        for key in to_del:
            del self.loaded[key]
            
    def sync(self):
        """
        Write changes to disk.
        """
        # write modified entries back to db
        for key in self.loaded.keys():
            sset, modified = self.loaded[key]
            if not len(sset):
                # Don't write 0-length sets. If set exists on disk,
                # then that means all entries were removed (in memory).
                # Delete key.
                if db.has_key(key):
                    del db[key]
                    
            elif modified:
                # the set has unique strings, so refs aren't needed.
                # pickle is shortened by using deepcopy.
                self.db[key] = dumps(sset,deepcopy=1)

        # physically write changes
        self.db.sync()

    def keys(self):
        "Get keys as a set."		
        # union on-disk keys with in-memory keys
        keys = new_set(self.db.keys())
        keys.update(self.loaded.keys())

        return keys

import os

if __name__ == '__main__':
    # make sure to start with a fresh db
    if os.path.isfile('aaa.db'):
        os.unlink('aaa.db')
        
    db = DbKeySet('aaa.db')

    # add some key/values
    db.add('aaa','a_01')
    db.add('bbb','b_01')
    db.add('aaa','a_02')
    db.add('aaa','a_03')
    db.add('bbb','b_02')

    # sync
    db.sync()

    # print
    print "--- Now ---"
    for k in db.keys():
        print k, db.get(k)
        
    # do a few add() and remove()
    db.add('ccc','c_00')
    db.add('aaa','a_04')
    db.add('ccc','c_01')
    db.remove('aaa','a_02')
    db.add('bbb','b_03')
    db.add('ccc','c_02')
    db.remove('bbb','b_01')
    db.remove('ccc','c_00')
    
    # print
    print "--- With temp changes ---"
    for k in db.keys():
        print k, db.get(k)

    # undo changes since sync()
    db.undo()

    # print
    print "--- After undo() ---"
    for k in db.keys():
        print k, db.get(k)
    
    # del will sync()
    del db

    # reload & print
    db = DbKeySet('aaa')
    print "-- Reloaded --"
    for k in db.keys():
        print k, db.get(k)		

    
