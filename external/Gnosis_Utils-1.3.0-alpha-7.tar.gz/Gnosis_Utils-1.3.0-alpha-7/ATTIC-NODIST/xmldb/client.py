
from CensusData import NamesMale, NamesFemale, NamesLast, \
     CityStates, AreaCodes
from random import random, randint, choice
from store import XmlDbObj

class Client(XmlDbObj):
    def __init__(self, first, last, male, addr, city, state, phone):
        self.first = first
        self.last = last
        self.male = male
        self.addr = addr
        self.city = city
        self.state = state
        self.phone = phone

    def __str__(self):
        s = "Client:\n"
        s += 'Name: %s %s (male=%d)\n' % (self.first,self.last,self.male)
        s += 'Address: %s\n' % self.addr
        s += 'City, State: %s, %s\n' % (self.city,self.state)
        s += 'Phone: %s' % self.phone
        return s
    
def random_client():
    if randint(0,1) == 0:
        male = 1
        first = choice(NamesMale)
    else:
        male = 0
        first = choice(NamesFemale)

    last = choice(NamesLast)

    addr = '%d %s ' % (randint(100,900), choice(NamesLast))
    r = randint(0,3)
    if r == 0:
        addr += 'Drive'
    elif r == 1:
        addr += 'Avenue'
    elif r == 2:
        addr += 'Street'
    elif r == 3:
        addr += 'Road'
        
    if random() > 0.3:
        addr += ', Apt %d%s' % (randint(1,60),choice('ABCDEFGHJIK'))

    city,state = choice(CityStates)

    # I don't try to match area code to city/state. The idea is
    # to have random, yet grouped, data. Realism is secondary :-)
    phone = '%s-%03d-%04d' % (choice(AreaCodes),randint(300,888),
                              randint(1,9999))

    return Client(first, last, male, addr, city, state, phone)

if __name__ == '__main__':
    for i in range(10):
        print random_client()
        
    
        
