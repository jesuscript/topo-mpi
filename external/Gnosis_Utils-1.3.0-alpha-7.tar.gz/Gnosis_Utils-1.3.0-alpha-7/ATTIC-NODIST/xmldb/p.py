
import re

print "AreaCodes = ["

for line in open('p','r'):
    #print line
    m = re.match('[^0-9]+([0-9,\s]+)',line)
    if not m:
        raise "ERROR"

    p = m.group(1)
    p = p.split(',')
    p = [l.rstrip().lstrip() for l in p]
    for c in p:
        print '"%s",' % c

print "]"

    
    
    
