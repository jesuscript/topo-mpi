
from client import Client, random_client
from store import IndexItem, XmlDb

i0 = IndexItem(Client, 'last')
i1 = IndexItem(Client, 'city')

db = XmlDb('data',[i0,i1])

for i in range(50):
    c = random_client()
    #print c

    db.store(c)

print db.keysets()

del db


