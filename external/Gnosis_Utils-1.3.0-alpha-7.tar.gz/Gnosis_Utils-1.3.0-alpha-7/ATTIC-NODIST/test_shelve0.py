
from gnosis.xml.pickle.extensions import ClassExtension, register_extension
from gnosis.xml.pickle import loads, dumps, dump, load, add_class_to_store, SEARCH_STORE
from randstuff import rand_ascii_word, rand_ascii_block
from random import randint
from time import time
import pickle, cPickle

class Client:

    def __init__(self, first, middle, last, addr1, addr2, city, state, zipcode, notes):
        self.first = first
        self.middle = middle
        self.last = last
        self.addr1 = addr1
        self.addr2 = addr2
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.notes = notes

def rand_client():

    c = Client(rand_ascii_word(4, 8), rand_ascii_word(4, 8), rand_ascii_word(5, 10),
               rand_ascii_block(1, 25), rand_ascii_block(1, 25),
               rand_ascii_word(5, 10), rand_ascii_word(2, 2), randint(10000,99999),
               rand_ascii_block(randint(5, 10), randint(55, 72)))
    return c

class XMLPickleShelfExt(ClassExtension):
    
    def __init__(self):
        ClassExtension.__init__(self, "PickleShelfExt")
        
    def pickle(self, obj):
        if not isinstance(obj, XMLPickleShelf):
            return self.ignore(obj)

        if not len(obj.obj_dict.keys()):
            return (obj.pickle_dict,{},{})
        
        d = {}
        d.update(obj.pickle_dict)
        
        for key,val in obj.obj_dict.items():
            d[key] = dumps(val,short_ids=1)

        return (d, {}, {})

    def unpickle_begin_nocore(self, typestr, metadata,
                              class_search, allow_replicants):
        return XMLPickleShelf()

    def unpickle_set_coredata(self, typestr, obj, coredata):
        for key,val in coredata.items():
            obj.pickle_dict[key] = val

    def unpickle_finalize(self, obj, propmap):
        pass
    
class XMLPickleShelf:

    def __init__(self):
        self.obj_dict = {}
        self.pickle_dict = {}

    def __del__(self):
        pass
        
    def __setitem__(self, key, val):
        try:
            del self.pickle_dict[key]
        except:
            pass

        self.obj_dict[key] = val

    def __getitem__(self, key):
        try:
            return self.obj_dict[key]
        except:
            o = loads(self.pickle_dict[key])
            del self.pickle_dict[key]
            self.obj_dict[key] = o
            return o

    def __delitem__(self, key):
        try:
            del self.obj_dict[key]
        except:
            del self.pickle_dict[key]

    def keys(self):
        return self.obj_dict.keys() + self.pickle_dict.keys()

register_extension(XMLPickleShelfExt())

print 'CREATE'

# make a regular dict of Clients
orig = {}
orig['ABC'] = Client('Joe','P.','Smith','111 Main Street','Apt. C','Plainville',
                  'ZA', 12345, 'A sample client.\nHere is line two.\nBlah.')
    
for i in range(5000):
    orig[i] = rand_client()

t1 = time()
f = open('clients_normal.xml','w')
dump(f, orig, short_ids=1, prefer_cdata=1)
print "DUMP time, normal = ",time()-t1

# now put same data in an XMLPickleShelf
shelf = XMLPickleShelf()
for k,v in orig.items():
    shelf[k] = v

# dump as shelf
t1 = time()
f = open('clients_shelf.xml','w')
dump(f, shelf, short_ids=1, prefer_cdata=1)
print "DUMP time, shelf = ",time()-t1

# allow loads() to find Client
add_class_to_store(Client)

t1 = time()
f = open('clients_normal.xml','r')
p = load(f,SEARCH_STORE)
print "LOAD normal = ",time()-t1

t1 = time()
f = open('clients_shelf.xml','r')
p = load(f,SEARCH_STORE)
print "LOAD shelf = ",time()-t1

t1 = time()
f = open('clients_shelf.xml','w')
dump(f, p, short_ids=1, prefer_cdata=1)
print "RE-write shelf (no changes) = ",time()-t1

#t1 = time()
#cPickle.dump(orig, open('aaa.pck','w'),1)
#print time()-t1
