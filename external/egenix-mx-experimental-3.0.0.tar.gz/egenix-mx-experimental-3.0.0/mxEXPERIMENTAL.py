#!/usr/local/bin/python2.1

""" Configuration for the eGenix mx Experimental Distribution.

    Copyright (c) 1997-2000, Marc-Andre Lemburg; mailto:mal@lemburg.com
    Copyright (c) 2000-2007, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.

"""
from mxSetup import mx_Extension, mx_version
import sys, glob, os

#
# Package version
#
version = mx_version(3, 0, 0)

#
# Setup information
#
name = "egenix-mx-experimental"

#
# Meta-Data
#
description = "eGenix mx Experimental Distribution for Python - mxNumber, mxTidy"
long_description = """\
The eGenix mx Extension Series are a collection of
Python extensions written in ANSI C and Python
which provide a large spectrum of useful additions
to everyday Python programming.

This package includes experimental subpackages of the 
series. Please understand that the software in these 
packages is still in alpha state and does not meet the 
quality standards of production quality software.

This software is brought to you by eGenix.com. The included
subpackages are either covered by the eGenix.com Public
License 1.1.0 or the eGenix.com Commercial License 1.2.0 
and/or other licenses. Please check the  subpackage 
documentation for details or contact eGenix.com for more 
license information.
"""
license = (
"eGenix.com Public License 1.1.0 and other licenses; "
"Copyright (c) 2000-2007, eGenix.com Software GmbH, All Rights Reserved"
)
author = "Marc-Andre Lemburg"
author_email = "mal@egenix.com"
url = "http://www.egenix.com/products/python/mxExperimental/"
platforms = [
    'Windows',
    'Linux',
    'FreeBSD',
    'Solaris',
    'Mac OS X',
    ]
classifiers = [
    "Development Status :: 4 - Beta",
    "Environment :: Console",
    "Environment :: No Input/Output (Daemon)",
    "Intended Audience :: Developers",
    "License :: Freely Distributable",
    "License :: Free for non-commercial use",
    "License :: Other/Proprietary License",
    "License :: OSI Approved :: GNU Library or Lesser General Public License (LGPL)",
    "Natural Language :: English",
    "Operating System :: OS Independent",
    "Operating System :: Microsoft :: Windows",
    "Operating System :: POSIX",
    "Operating System :: Unix",
    "Operating System :: BeOS",
    "Operating System :: MacOS",
    "Operating System :: OS/2",
    "Operating System :: Other OS",
    "Programming Language :: C",
    "Programming Language :: Python",
    "Topic :: Documentation",
    "Topic :: Internet",
    "Topic :: Internet :: WWW/HTTP",
    "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
    "Topic :: Internet :: WWW/HTTP :: Dynamic Content :: CGI Tools/Libraries",
    "Topic :: Scientific/Engineering",
    "Topic :: Scientific/Engineering :: Interface Engine/Protocol Translator",
    "Topic :: Scientific/Engineering :: Mathematics",
    "Topic :: Software Development",
    "Topic :: Software Development :: Libraries",
    "Topic :: Software Development :: Libraries :: Application Frameworks",
    "Topic :: Software Development :: Libraries :: Python Modules",
    "Topic :: Text Processing :: Markup",
#    "Topic :: Utilities ",
    ]
classifiers.sort()

#
# Python packages
#
packages = [
    
    'mx',

    # mxNumber
    'mx.Number',
    'mx.Number.mxNumber',

    # mxTidy
    'mx.Tidy',
    'mx.Tidy.mxTidy',
    
    ]

#
# C libraries
#

libraries = [

    # libtidy.a needed by mxTidy
    ('tidy',
     {'sources':
      glob.glob(os.path.join('mx','Tidy','mxTidy','libtidy','*.c')),
      'include_dirs':
      [os.path.join('mx','Tidy','mxTidy','libtidy')],
      'macros':
      [('COMPILING_TIDY', 1)],
      }),

    ]

#
# C Extensions
#
ext_modules = [

    # mxTidy
    mx_Extension('mx.Tidy.mxTidy.mxTidy',
                 ['mx/Tidy/mxTidy/mxTidy.c'],
                 include_dirs=['mx/Tidy/mxTidy',
                               'mx/Tidy/mxTidy/libtidy'],
                 libraries=['tidy'],
                 library_dirs=['mx/Tidy/mxTidy/libtidy']),

    ]

# mxNumber
if sys.version[:3] >= '2.1':
    if sys.platform[:3] == 'win':
        ext_modules[len(ext_modules):] = [

            mx_Extension('mx.Number.mxNumber.mxNumber',
                         ['mx/Number/mxNumber/mxNumber.c'],
                         include_dirs=['mx/Number/mxNumber',
                                       'mx/Number/mxNumber/win32'],
                         libraries=['gmp31'],
                         library_dirs=['mx/Number/mxNumber/win32'],
                         data_files=[
                             'mx/Number/Doc/mxNumber.html',
                             'mx/Number/Doc/mxLicense.html',
                             'mx/Number/COPYRIGHT',
                             'mx/Number/LICENSE',
                             'mx/Number/README',
                             'mx/Number/mxNumber/mxNumber.h',
                             'mx/Number/mxNumber/mxh.h',
                             'mx/Number/mxNumber/gmp.h',
                             'mx/Number/mxNumber/gmp31.dll',
                             ],
                         required=1),
            ]
    else:
        ext_modules[len(ext_modules):] = [

            mx_Extension('mx.Number.mxNumber.mxNumber',
                         ['mx/Number/mxNumber/mxNumber.c'],
                         include_dirs=['mx/Number/mxNumber'],
                         needed_includes=[('gmp.h',
                                           ['/usr/local/gmp/include',
                                            '/usr/local/GMP/include'],
                                           'GNU MP Library')],
                         needed_libraries=[('gmp',
                                            ['/usr/local/gmp/lib',
                                             '/usr/local/GMP/lib'],
                                            'GNU MP')],
                         optional_libraries=[('mpfr', ['gmp.h', 'mpfr.h']),
                                             ],
                         data_files=[
                             'mx/Number/Doc/mxNumber.html',
                             'mx/Number/Doc/mxLicense.html',
                             'mx/Number/COPYRIGHT',
                             'mx/Number/LICENSE',
                             'mx/Number/README',
                             'mx/Number/mxNumber/mxNumber.h',
                             'mx/Number/mxNumber/mxh.h',
                             'mx/Number/mxNumber/gmp.h',
                             ],
                         required=0),

            ]
else:
    print '*** WARNING: mxNumber needs Python 2.1 or later.',
    print '    mxNumber will not be built !'

#
# Data files
#
data_files = [

    # mxTidy
    'mx/Tidy/Doc/mxTidy.html',
    'mx/Tidy/Doc/mxLicense.html',
    'mx/Tidy/Doc/Overview.html',
    'mx/Tidy/Doc/pending.html',
    'mx/Tidy/Doc/release-notes.html',
    'mx/Tidy/Doc/tidy.gif',
    'mx/Tidy/COPYRIGHT',
    'mx/Tidy/LICENSE',
    'mx/Tidy/README',
    'mx/Tidy/mxTidy/mxTidy.h',
    'mx/Tidy/mxTidy/mxh.h',
    'mx/Tidy/mxTidy/input.html',

    ]
