""" mxTidy -- Interface to Tidy (HTML beautifier)

    Copyright (c) 2001-2007, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.
"""
from mxTidy import *
from mxTidy import __version__

