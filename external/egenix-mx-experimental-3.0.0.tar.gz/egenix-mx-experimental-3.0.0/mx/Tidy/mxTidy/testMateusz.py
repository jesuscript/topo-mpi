#! /usr/bin/python
# -*- coding: latin-1 -*-
import string
import mx.Tidy

test_utf_content = "<body>Jesteś </body>"
#test_utf_content = "<body>Jeste</body>"
print 'Testing...', repr(test_utf_content)
print 'Converted to Unicode:', repr(unicode(test_utf_content, 'utf-8'))

# Its even proper utf-8 string ...

#file("test_utf_content.txt","w").write(test_utf_content)

#iconv -f utf-8 -t iso-8859-2 test_utf_content.txt
#<body>Jeste� </body>

(nerrors, nwarnings, outputdata, errordata) = \
          mx.Tidy.tidy(test_utf_content,
                       output_xml=1,
                       char_encoding='utf8',
                       quiet=1,
                       wrap=0,
                       indent='yes')

print 'Works.'
