import urllib2
from mx.Tidy import tidy

_options = dict(char_encoding="iso2022", \
                       drop_font_tags = 1, \
                       drop_proprietary_attributes = 1, \
                       hide_comments = 1, \
                       language = "kr",\
                       fix_bad_comments = 1,\
                       output_xhtml=1,\
                       tidy_mark=0,\
                       fix_uri=1
                       )
                       
#when i parse first url, error is occur
#but second url or almost other url is well work

url = "http://gangdong.go.kr/pub/jpn/jpn02040101.html"
#url = "http://www.python.org"

response = urllib2.urlopen(url)
listofpage = response.readlines()
html = "".join(listofpage)
nerrors, nwarnings, outputdata, errordata = tidy(html, output=None, errors=None, **_options)
print outputdata