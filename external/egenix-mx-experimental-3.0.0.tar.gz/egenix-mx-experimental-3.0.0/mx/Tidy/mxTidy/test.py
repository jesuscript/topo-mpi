import mxTidy

def tidy(input, output=None, errors=None, **kws):
    return mxTidy.tidy(input, output, errors, kws)

print 'Testing mxTidy version %s ...' % mxTidy.__version__

data = open('input.html').read()

tries = 100

for i in range(tries / 10):
    print 'Pass',i
    input = open('input.html')
    output = open('output.html', 'wb')
    errors = open('errors.log', 'wb+')
    result = tidy(input, output, errors,
                  indent='auto',
                  uppercase_tags=1, uppercase_attributes=1,
                  #output_xhtml=1,
                  wrap=80,
                  output_errors=0,
                  output_markup=1,
                  )
    print '  Result =',result[:2]

for i in range(tries):
    print 'Pass',i
    result = tidy(data, #output, errors,
                  indent='auto',
                  uppercase_tags=1, uppercase_attributes=1,
                  #output_xhtml=1,
                  wrap=80,
                  output_errors=0,
                  output_markup=1,
                  )
    print '  Result =',result[:2]

print 'Works.'
print

