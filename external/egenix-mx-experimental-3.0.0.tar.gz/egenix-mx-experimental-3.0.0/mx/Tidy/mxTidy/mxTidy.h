#ifndef MXTidy_H
#define MXTidy_H
/* 
  mxTidy -- Interface to Tidy (HTML beautifier)

  Copyright (c) 2001-2007, eGenix.com Software GmbH; mailto:info@egenix.com
  See the documentation for further copyright information or contact
  the author (mailto:mal@lemburg.com).
  
*/

/* The extension's name; must be the same as the init function's suffix */
#define MXTIDY_MODULE "mxTidy"

/* Name of the package or module that provides the extensions C API.
   If the extension is used inside a package, provide the complete
   import path. */
#define MXTIDY_API_MODULE "mx.Tidy"

/* --- No servicable parts below this line ----------------------*/

/* Include generic mx extension header file */
#include "mxh.h"

#ifdef MX_BUILDING_MXTIDY
# define MXTIDY_EXTERNALIZE MX_EXPORT
#else
# define MXTIDY_EXTERNALIZE MX_IMPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* EOF */
#ifdef __cplusplus
}
#endif
#endif
