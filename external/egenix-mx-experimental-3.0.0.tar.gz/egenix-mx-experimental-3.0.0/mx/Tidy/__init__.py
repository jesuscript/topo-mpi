""" mxTidy -- Interface to Tidy (HTML beautifier)

    Copyright (c) 2001-2007, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.
"""
from Tidy import *
from Tidy import __version__

if 0:

    ### Lazy import submodules
    from mx.Misc import LazyModule

    #ISO = LazyModule.LazyModule('ISO',locals(),globals())

    del LazyModule

    ### Make the types pickleable:

    # Shortcuts for pickle (reduces the pickle's length)
    def _DT(absdate,abstime,

            DateTimeFromAbsDateTime=DateTimeFromAbsDateTime):

        return DateTimeFromAbsDateTime(absdate,abstime)

    def _DTD(seconds,

             DateTimeDeltaFromSeconds=DateTimeDeltaFromSeconds):

        return DateTimeDeltaFromSeconds(seconds)

    # Module init
    class modinit:

        ### Register the two types
        import copy_reg
        def pickle_DateTime(d):
            return _DT,(d.absdate,d.abstime)
        def pickle_DateTimeDelta(d):
            return _DTD,(d.seconds,)
        copy_reg.pickle(DateTimeType,
                        pickle_DateTime,
                        _DT)
        copy_reg.pickle(DateTimeDeltaType,
                        pickle_DateTimeDelta,
                        _DTD)

    del modinit
