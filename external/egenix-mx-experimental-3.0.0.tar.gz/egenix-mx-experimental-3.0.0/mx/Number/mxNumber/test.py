#!/usr/local/bin/python2.1
#
# mx.Number needs Python 2.1's new coercion features.
#

from mxNumber import *

i = Integer(123)
j = Integer("123")
assert i == j

r = Rational(123, 56)
assert r/i == Rational(1, 56)
assert i/r == Rational(56, 1)

print FareyRational("2.7", 10)
print FareyRational("1.7", 10)
print FareyRational("1.33333", 100)
print FareyRational("0.33333", 10)
print FareyRational("0.33333", 100)
print FareyRational("0.33333", 1000)
print FareyRational("0.33333", 10000)
print FareyRational("0.75", 100)

assert r.format(16) == '7b/38'
assert r.format(32) == '3r/1o'
assert r.format(10) == '123/56'
assert r.format(10, 10) == '2.196428571'

f = Float(r)
print f
print repr(f)
assert f.format(16) == '2.196428571428572'
assert f.format(10) == '2.196428571'
assert f.format(0) == '2.19642857142857142856e+0'

a = Rational(1, 2)
b = Rational(2, 3)
assert a != b
assert a < b
assert b > a

print 'Works.'
