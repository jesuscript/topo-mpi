""" mxNumber - Arbitrary precision numbers provided by GNU MP 2.x

    Python part of the implementation.

    Copyright (c) 2001-2007, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.

"""
from mxNumber import *
from mxNumber import __version__
