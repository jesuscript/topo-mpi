#!/usr/bin/env python

""" Distutils Setup File for the mx Extensions EXPERIMENTAL distribution.

"""
#
# Load configuration(s)
#
import mxEXPERIMENTAL
configurations = (mxEXPERIMENTAL,)

#
# Run distutils setup...
#
import mxSetup
mxSetup.run_setup(configurations)
