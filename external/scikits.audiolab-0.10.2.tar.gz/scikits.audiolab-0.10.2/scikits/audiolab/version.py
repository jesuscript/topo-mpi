
short_version='0.10.2'
version=short_version
dev=False
if dev:
    version += '.dev'
