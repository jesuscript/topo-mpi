__revision__="$Id: __init__.py,v 1.1 2005-06-13 20:55:20 syt Exp $"
