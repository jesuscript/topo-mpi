# -*- coding: utf-8 -*-
#._cv_part guppy.doc

class _GLUECLAMP_:
    """"""

