#._cv_part guppy.etc

class _GLUECLAMP_:
    def _get_iterpermute(self): return self.IterPermute.iterpermute
    def _get_unpack(self):	return self.Unpack.unpack

