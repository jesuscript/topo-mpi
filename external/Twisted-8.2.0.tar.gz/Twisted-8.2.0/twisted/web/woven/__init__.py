# __init__.py

"""Woven, the Web Object Visualization Environment."""
