from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.http', 'twisted.web.http',
                         'HTTP protocol support', 'Web',
                         'http://twistedmatrix.com/projects/web',
                         globals())

