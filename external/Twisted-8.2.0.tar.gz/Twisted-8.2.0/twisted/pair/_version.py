# This is an auto-generated file. Do not edit it.
from twisted.python import versions
version = versions.Version('twisted.pair', 8, 2, 0)
