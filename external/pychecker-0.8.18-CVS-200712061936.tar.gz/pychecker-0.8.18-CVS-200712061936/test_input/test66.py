'd'

from time import time, sleep

def x():
    print time, sleep

