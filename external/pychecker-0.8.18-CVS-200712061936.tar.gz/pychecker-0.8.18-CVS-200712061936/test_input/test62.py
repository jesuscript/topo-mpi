'bug found by Joe VanAndel'

isintorlong = lambda x: type(x) == type(0) or type(x) == type(0L)

