"doc"

import re
import sys
import glob

class X:
    'doc'
    global_var = re.compile('a')
    def m(self, j = re.match):
        print X.global_var

    def xxx(self, j = glob.glob):
      print j

def xxx(j = sys.path):
  print j


