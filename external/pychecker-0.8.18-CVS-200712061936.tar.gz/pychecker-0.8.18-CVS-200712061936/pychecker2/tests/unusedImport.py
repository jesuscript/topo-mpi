import sys

def f(x):
    return f(x)
