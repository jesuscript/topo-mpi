
try:
    pass
except AttributeError:
    pass

try:
    pass
except:
    pass

