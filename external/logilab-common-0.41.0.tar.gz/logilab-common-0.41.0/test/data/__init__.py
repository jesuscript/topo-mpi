__revision__="$Id: __init__.py,v 1.1 2003-10-20 06:39:32 syt Exp $"
