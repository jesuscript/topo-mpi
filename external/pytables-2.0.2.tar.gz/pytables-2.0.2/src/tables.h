typedef enum
{
  Table,
  Array,
  EArray,
  VLArray,
  CArray
} TablesType;
