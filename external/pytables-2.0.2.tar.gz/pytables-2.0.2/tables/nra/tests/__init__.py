"""
Unit tests for nested record arrays
===================================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivilata@carabos.com
:Created:  2007-01-12
:License:  BSD
:Revision: $Id: __init__.py 2426 2007-02-23 12:37:49Z ivilata $
"""
