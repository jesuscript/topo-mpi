"""
Unit tests for PyTables
=======================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivilata@carabos.com
:Created:  2005-12-02
:License:  BSD
:Revision: $Id: __init__.py 2419 2007-02-22 19:19:33Z faltet $

This package contains some modules which provide a ``suite()``
function (with no arguments) which returns a test suite for some
PyTables functionality.
"""

from tables.tests.test_all import print_versions, test, suite
