#
#  Pyrex - Compilation-wide options
#

intern_names = 1   #  Intern global variable and attribute names
