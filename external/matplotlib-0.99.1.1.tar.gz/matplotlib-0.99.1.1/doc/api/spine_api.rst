*****************
matplotlib spine
*****************


:mod:`matplotlib.spine`
========================

.. automodule:: matplotlib.spines
   :members:
   :undoc-members:
   :show-inheritance:
