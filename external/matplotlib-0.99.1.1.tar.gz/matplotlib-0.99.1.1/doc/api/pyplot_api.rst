*****************
matplotlib pyplot
*****************
 

:mod:`matplotlib.pyplot`
========================

.. automodule:: matplotlib.pyplot
   :members:
   :undoc-members:
   :show-inheritance:
