 /***************************************************************/
/***            Psyco equivalent of descrobject.h              ***/
 /***************************************************************/

#ifndef _PSY_DESCROBJECT_H
#define _PSY_DESCROBJECT_H


#include "pobject.h"
#include "pabstract.h"


#endif /* _PSY_DESCROBJECT_H */
